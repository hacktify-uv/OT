# Scenario 04 — Red Module

This directory is a complete, independently installable Scenario 04 package for the **Red Module** exercise role. It retains the full native IEC-104 runtime so the module can be deployed and validated without depending on sibling directories.
