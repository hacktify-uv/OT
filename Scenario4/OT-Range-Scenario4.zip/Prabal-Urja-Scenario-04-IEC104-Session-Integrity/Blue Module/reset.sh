#!/usr/bin/env bash
set -Eeuo pipefail
[[ $EUID -eq 0 ]] || { echo 'RUN_AS_ROOT';exit 1; }
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
if [[ "${1:-}" == '--preserve-evidence' ]]; then
 bash /opt/prabal-urja/scenario4/tools/collect_evidence.sh
fi
systemctl stop prabal-iec104-master.service prabal-s04-process.service prabal-s04-console.service prabal-iec104-outstation.service
bash /opt/prabal-urja/scenario4/tools/remove_hardening.sh
install -m 0660 -o prabal-rtu -g prabal-ot "$ROOT/Challenge-Files/config/initial-state.json" /var/lib/prabal-urja/scenario4/rtu-state.json
rm -f /var/lib/prabal-urja/scenario4/latest-state.json /run/prabal-s04/master-heartbeat.json
systemctl start prabal-s04-network.service prabal-iec104-outstation.service prabal-iec104-master.service prabal-s04-process.service prabal-s04-console.service
sleep 5
bash "$ROOT/validate.sh" --installed
printf 'S04_RESET:COMPLETE\n'
