# Scenario 04: IEC-104 Telecontrol Session Integrity
A research-documented IEC-104 APCI session-integrity attack can disrupt telecontrol communications while the local station remains operational. This build uses a native master/outstation path through an isolated Linux transit position and detects stale dispatch telemetry; successful packet poisoning must still be tested on a live Ubuntu VM.

The IEC-104 station explicitly rejects the old control-command route; command manipulation is not the expected objective.
