#!/usr/bin/env bash
set -Eeuo pipefail
trap 'echo "[!] Scenario 04 setup failed at line $LINENO" >&2' ERR
[[ $EUID -eq 0 ]] || { echo 'Run as root: sudo bash setup.sh' >&2; exit 1; }
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source /etc/os-release
[[ ${ID:-} == ubuntu && ( ${VERSION_ID:-} == 22.04 || ${VERSION_ID:-} == 24.04 ) ]] || { echo 'WARNING: Supported OS: Ubuntu 22.04 or 24.04. Detected: ID='${ID:-unknown}' VERSION_ID='${VERSION_ID:-unknown} >&2; }

bash "$ROOT/deps.sh"
command -v ip >/dev/null || { echo "iproute2 required" >&2; exit 1; }
getent group prabal-ot >/dev/null || groupadd --system prabal-ot
for u in prabal-rtu prabal-scada prabal-process prabal-console prabal-monitor; do
 id "$u" >/dev/null 2>&1 || useradd --system --no-create-home --shell /usr/sbin/nologin -g prabal-ot "$u"
done

install -d -m 0750 /opt/prabal-urja/scenario4
cp -a "$ROOT/Challenge-Files/." /opt/prabal-urja/scenario4/
# S04_MAC_PARTICIPANT_V1
install -m 0644 "$ROOT/Challenge-Files/attack/prabal-s04-participant-gateway.service" /etc/systemd/system/prabal-s04-participant-gateway.service
systemctl daemon-reload
systemctl enable --now prabal-s04-participant-gateway.service
# S04_DISCOVERY_V2_BEGIN
# Remove legacy S03-like static discovery after copy; old installations may retain stale files.
rm -f /opt/prabal-urja/scenario4/hmi/static/robots.txt /opt/prabal-urja/scenario4/hmi/static/engineering/station-register.json
# The incident HMI now gates SCL project access on actual native telemetry loss.
# Optional lab APCI test: bash /opt/prabal-urja/scenario4/attack/prepare-lab-deps.sh
# S04_DISCOVERY_V2_END
# ZIP extraction may not preserve executable bits. Normalise all runtime helpers.
find /opt/prabal-urja/scenario4/vendor /opt/prabal-urja/scenario4/tools /opt/prabal-urja/scenario4/network /opt/prabal-urja/scenario4/attack \
  -type f -name '*.sh' -exec chmod 0750 {} +
chown root:prabal-ot /opt/prabal-urja/scenario4
chmod 0750 /opt/prabal-urja/scenario4
install -d -m 0770 -o prabal-rtu -g prabal-ot /var/lib/prabal-urja/scenario4 /var/log/prabal-urja/scenario4
install -m 0644 /opt/prabal-urja/scenario4/tmpfiles/prabal-s04.conf /etc/tmpfiles.d/prabal-s04.conf
systemd-tmpfiles --create /etc/tmpfiles.d/prabal-s04.conf
install -d -m 0770 -o root -g prabal-ot /var/log/prabal-urja/scenario4/pcap
cp "$ROOT/Challenge-Files/config/initial-state.json" /var/lib/prabal-urja/scenario4/rtu-state.json
chown prabal-rtu:prabal-ot /var/lib/prabal-urja/scenario4/rtu-state.json
chmod 0660 /var/lib/prabal-urja/scenario4/rtu-state.json

bash /opt/prabal-urja/scenario4/vendor/prepare-lib60870.sh /opt/prabal-urja/scenario4/vendor-cache /usr/local/src/prabal-lib60870
INC=$(find /usr/local/include /usr/include /usr/local/src/prabal-lib60870 -name cs104_slave.h -printf '%h\n' 2>/dev/null | head -n1 || true)
HALINC=$(find /usr/local/include /usr/include /usr/local/src/prabal-lib60870 -name hal_thread.h -printf '%h\n' 2>/dev/null | head -n1 || true)
HALTIMEINC=$(find /usr/local/include /usr/include /usr/local/src/prabal-lib60870 -name hal_time.h -printf '%h\n' 2>/dev/null | head -n1 || true)
LIB=$(find -L /usr/local/lib /usr/local/lib64 /usr/lib /usr/local/src/prabal-lib60870 -type f \( -name 'lib60870.so' -o -name 'lib60870.so.*' -o -name 'lib60870.a' -o -name 'liblib60870.so' -o -name 'liblib60870.so.*' -o -name 'liblib60870.a' \) 2>/dev/null | head -n1 || true)
[[ -n $INC && -n $LIB && -n $HALINC && -n $HALTIMEINC ]] || { echo 'Unable to locate installed lib60870 headers/library' >&2; exit 1; }
LIBDIR=$(dirname "$LIB")
ln -sf "$LIBDIR/liblib60870.so" "$LIBDIR/lib60870.so" 2>/dev/null || true
ln -sf "$LIBDIR/liblib60870.a" "$LIBDIR/lib60870.a" 2>/dev/null || true
install -d -m 0755 /opt/prabal-urja/scenario4/bin
for src in prabal_iec104_outstation prabal_iec104_master prabal_iec104_tool; do
 gcc -std=c99 -O2 -Wall -Wextra \
   -I"$INC" -I"$HALINC" -I"$HALTIMEINC" "/opt/prabal-urja/scenario4/lib60870/source/${src}.c" \
   -L"$LIBDIR" -Wl,-rpath,"$LIBDIR" -l60870 -lpthread -o "/opt/prabal-urja/scenario4/bin/${src}"
done
chown root:prabal-ot /opt/prabal-urja/scenario4/bin/*
chmod 0750 /opt/prabal-urja/scenario4/bin/*

python3 -m venv /opt/prabal-urja/scenario4/venv
if compgen -G "/opt/prabal-urja/scenario4/wheelhouse/*.whl" >/dev/null; then
 /opt/prabal-urja/scenario4/venv/bin/pip install --no-index --find-links=/opt/prabal-urja/scenario4/wheelhouse -r /opt/prabal-urja/scenario4/process/requirements.txt
else
 /opt/prabal-urja/scenario4/venv/bin/pip install --upgrade pip
 /opt/prabal-urja/scenario4/venv/bin/pip install -r /opt/prabal-urja/scenario4/process/requirements.txt
fi

install -m 0640 /opt/prabal-urja/scenario4/audit/prabal-s04.rules /etc/audit/rules.d/prabal-s04.rules
augenrules --load || systemctl restart auditd
install -d -m 0755 /etc/nftables.d
bash /opt/prabal-urja/scenario4/tools/remove_hardening.sh

for f in /opt/prabal-urja/scenario4/systemd/*.service; do install -m 0644 "$f" "/etc/systemd/system/$(basename "$f")"; done
systemctl daemon-reload
systemctl enable --now prabal-s04-network.service prabal-iec104-outstation.service
systemctl enable --now prabal-iec104-master.service prabal-s04-process.service prabal-s04-console.service prabal-s04-command-monitor.service prabal-s04-capture.service

# S04_CLEAN_INSTALL_READINESS_V3_BEGIN
# Pandapower initialization and the first real IEC-104 master sample may take
# longer than 8 seconds on a newly provisioned Ubuntu VM. Check *actual*
# service availability instead of failing a healthy install during startup.
READY=0
for attempt in $(seq 1 60); do
  if bash /opt/prabal-urja/scenario4/tools/service_availability.sh >/dev/null 2>&1; then
    READY=1
    break
  fi
  sleep 2
done
if [[ "$READY" != 1 ]]; then
  echo '[!] Scenario 04 never reached healthy native IEC-104 telemetry state.' >&2
  systemctl --no-pager --full status prabal-s04-network.service prabal-iec104-outstation.service prabal-iec104-master.service prabal-s04-process.service prabal-s04-console.service || true
  journalctl -u prabal-iec104-outstation.service -u prabal-iec104-master.service -u prabal-s04-process.service -u prabal-s04-console.service --no-pager -n 80 || true
  exit 1
fi
bash "$ROOT/validate.sh" --installed
# S04_CLEAN_INSTALL_READINESS_V3_END
cat <<EOF
[+] Prabal Urja Scenario 04 installed successfully.
[+] Operator console: http://<THIS_VM_IP>:8095
[+] IEC-104 controlled station: <THIS_VM_IP>:2404
[+] Isolated on-path transit namespace: pu-s04-transit (instructor controlled)
EOF
