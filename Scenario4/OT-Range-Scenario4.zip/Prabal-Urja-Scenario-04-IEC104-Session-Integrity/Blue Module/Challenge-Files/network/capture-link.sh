#!/usr/bin/env bash
set -euo pipefail
exec ip netns exec pu-s04-transit tcpdump -ni pu04-tm -s 0 -w "${1:-/var/log/prabal-urja/scenario4/pcap/master-station.pcap}" 'tcp port 2404'
