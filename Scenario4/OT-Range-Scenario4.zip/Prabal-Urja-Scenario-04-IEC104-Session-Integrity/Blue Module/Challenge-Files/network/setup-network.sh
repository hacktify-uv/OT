#!/usr/bin/env bash
set -Eeuo pipefail
# All addresses are internal to this one lab VM. No scenario3 routes or interfaces.
for ns in pu-s04-master pu-s04-transit; do ip netns list | awk '{print $1}' | grep -Fxq "$ns" || ip netns add "$ns"; done
ip netns exec pu-s04-master ip link set lo up
ip netns exec pu-s04-transit ip link set lo up
if ! ip -o link show pu04-out >/dev/null 2>&1; then
 ip link add pu04-out type veth peer name pu04-tout
 ip link set pu04-tout netns pu-s04-transit
fi
if ! ip netns exec pu-s04-master ip -o link show pu04-m >/dev/null 2>&1; then
 ip link add pu04-m type veth peer name pu04-tm
 ip link set pu04-m netns pu-s04-master
 ip link set pu04-tm netns pu-s04-transit
fi
ip addr replace 10.104.2.2/24 dev pu04-out
ip link set pu04-out up
ip netns exec pu-s04-transit ip addr replace 10.104.2.1/24 dev pu04-tout
ip netns exec pu-s04-transit ip link set pu04-tout up
ip netns exec pu-s04-transit ip addr replace 10.104.1.1/24 dev pu04-tm
ip netns exec pu-s04-transit ip link set pu04-tm up
ip netns exec pu-s04-master ip addr replace 10.104.1.2/24 dev pu04-m
ip netns exec pu-s04-master ip link set pu04-m up
ip netns exec pu-s04-master ip route replace 10.104.2.0/24 via 10.104.1.1
ip netns exec pu-s04-transit sysctl -qw net.ipv4.ip_forward=1
ip route replace 10.104.1.0/24 via 10.104.2.1 dev pu04-out
# Do not enable route to any external/private infrastructure.
echo 'S04_PATH_READY: master=10.104.1.2 transit=10.104.1.1/10.104.2.1 station=10.104.2.2'
