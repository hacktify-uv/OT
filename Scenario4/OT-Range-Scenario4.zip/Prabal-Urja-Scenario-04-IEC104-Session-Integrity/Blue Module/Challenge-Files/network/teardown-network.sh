#!/usr/bin/env bash
set -euo pipefail
ip route del 10.104.1.0/24 via 10.104.2.1 dev pu04-out 2>/dev/null || true
ip link del pu04-out 2>/dev/null || true
ip netns del pu-s04-master 2>/dev/null || true
ip netns del pu-s04-transit 2>/dev/null || true
