#!/usr/bin/env python3
"""Dispatch HMI. Exposes incident correlation only after telemetry failure."""
import json
import mimetypes
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

BASE = Path('/opt/prabal-urja/scenario4/hmi/static')
STATE = Path('/var/lib/prabal-urja/scenario4/latest-state.json')
EVENTS = Path('/var/log/prabal-urja/scenario4/iec104-commands.jsonl')
SCD = BASE / 'engineering' / 'PU-DSS-IED-01.scd'


def current_state():
    try:
        return json.loads(STATE.read_text())
    except (OSError, ValueError):
        return {}


def incident_state(state):
    # Avoid pretending that a missing initial connection is a completed attack.
    lost = (state.get('telecontrol_online') is False
            and int(state.get('master_rx_count') or 0) > 0
            and state.get('scenario_state') == 'IEC104_TELECONTROL_LOST')
    if not lost:
        return {'status': 'MONITORING', 'observation': 'No established-link loss recorded'}
    return {
        'status': 'ACTIVE',
        'incident_type': 'DISPATCH_TELEMETRY_LOSS',
        'last_master_event': state.get('master_event'),
        'last_rx_count': state.get('master_rx_count'),
        'telemetry_age_seconds': state.get('master_data_age_seconds'),
        'location': 'Northern strategic corridor',
        'investigation': 'Correlate the last valid IEC-104 master data with the station engineering project',
        'engineering_record': '/api/incident/station-project.scd',
        'handoff_scope': 'asset discovery only; no route or credentials',
        'continuity': 'Separate scenarios; live plant state not shared'
    }



# S04_VERIFIED_INCIDENT_RETENTION_V1
# Retain a factual record of a genuine observed incident for 24 hours.
# When SCADA recovers, report RECORDED rather than falsely claiming ACTIVE.
from pathlib import Path as _S04Path
import time as _s04time
import json as _s04json
import os as _s04os

_s04_original_incident_state = incident_state
_s04_incident_archive = _S04Path('/var/lib/prabal-urja/scenario4/incidents/last-confirmed.json')
_s04_retention_seconds = 86400

def incident_state(state):
    current = _s04_original_incident_state(state)
    if current.get('status') == 'ACTIVE':
        record = dict(current)
        record['recorded_at_epoch'] = _s04time.time()
        record['record_type'] = 'observed_live_telemetry_loss'
        record['observed_master_rx_count'] = state.get('master_rx_count')
        record['observed_scenario_state'] = state.get('scenario_state')
        try:
            _s04_incident_archive.parent.mkdir(parents=True,exist_ok=True)
            tmp = _s04_incident_archive.with_suffix('.json.tmp')
            tmp.write_text(_s04json.dumps(record,sort_keys=True))
            _s04os.chmod(tmp,0o600)
            tmp.replace(_s04_incident_archive)
        except OSError as e:
            print('S04_INCIDENT_ARCHIVE_FAILED',str(e),flush=True)
        return current
    try:
        prior = _s04json.loads(_s04_incident_archive.read_text())
        stamp=float(prior.get('recorded_at_epoch',0))
        if 0 <= _s04time.time()-stamp <= _s04_retention_seconds and prior.get('status') == 'ACTIVE':
            return {'status':'RECORDED',
                    'observation':'Previously confirmed IEC-104 telemetry loss; current master recovered',
                    'current_telecontrol_online':state.get('telecontrol_online'),
                    'recorded_at_epoch':stamp,
                    'record_type':prior.get('record_type'),
                    'incident_type':prior.get('incident_type','DISPATCH_TELEMETRY_LOSS'),
                    'last_master_event':prior.get('last_master_event'),
                    'last_rx_count':prior.get('last_rx_count'),
                    'telemetry_age_seconds':prior.get('telemetry_age_seconds'),
                    'engineering_record':'/api/incident/station-project.scd',
                    'handoff_scope':'asset discovery only; no route or credentials'}
    except (OSError,ValueError,TypeError):
        pass
    return current

class H(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        import sys
        print('HMI_ACCESS source=' + self.client_address[0] + ' ' + (fmt % args),
              file=sys.stderr, flush=True)

    def sendb(self, body, content_type='application/json', code=200):
        self.send_response(code)
        self.send_header('Content-Type', content_type)
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    # S04_MAC_PARTICIPANT_V1
    def do_POST(self):
        import json as _json
        import urllib.request as _url
        from urllib.parse import urlsplit as _urlsplit
        if _urlsplit(self.path).path != '/api/participant/apci':
            return self.sendb(b'not found', 'text/plain', 404)
        if self.client_address[0] != '10.200.0.8':
            return self.sendb(b'forbidden: exercise VPN address only', 'text/plain', 403)
        try:
            n = int(self.headers.get('Content-Length', '-1'))
            if n < 0 or n > 128:
                return self.sendb(b'invalid body size', 'text/plain', 400)
            body = _json.loads(self.rfile.read(n))
            if body != {'exercise':'SCENARIO04_APCI'}:
                return self.sendb(b'unsupported exercise', 'text/plain', 400)
            data = _json.dumps({'exercise':'SCENARIO04_APCI','duration':95}).encode()
            req = _url.Request('http://127.0.0.1:18095/run', data=data,
                               headers={'Content-Type':'application/json'}, method='POST')
            with _url.urlopen(req, timeout=3) as response:
                return self.sendb(response.read(), 'application/json', response.status)
        except Exception as exc:
            return self.sendb(_json.dumps({'error':str(exc)}).encode(), 'application/json', 503)

    def do_GET(self):
        # S04_MAC_PARTICIPANT_V1 GET
        if self.path == '/api/participant/apci/status':
            import urllib.request as _url
            if self.client_address[0] != '10.200.0.8':
                return self.sendb(b'forbidden', 'text/plain', 403)
            try:
                with _url.urlopen('http://127.0.0.1:18095/status', timeout=2) as response:
                    return self.sendb(response.read(), 'application/json', response.status)
            except Exception as exc:
                return self.sendb(str(exc).encode(), 'text/plain', 503)
        path = urlsplit(self.path).path
        state = current_state()
        if path == '/api/health':
            try:
                age = max(0.0, time.time() - STATE.stat().st_mtime)
                ok = age <= 8.0
            except OSError:
                age, ok = None, False
            result = {'status': 'UP' if ok else 'DOWN',
                      'process_current': ok, 'state_age_seconds': round(age, 3) if age is not None else None,
                      'scenario_state': state.get('scenario_state')}
            return self.sendb(json.dumps(result).encode(), code=200 if ok else 503)
        if path == '/api/state':
            return self.sendb(json.dumps(state).encode(), code=200 if state else 503)
        if path == '/api/events':
            result = []
            if EVENTS.is_file():
                for line in EVENTS.read_text().splitlines()[-30:]:
                    try:
                        result.append(json.loads(line))
                    except ValueError:
                        continue
            return self.sendb(json.dumps(result).encode())
        if path == '/api/incident':
            return self.sendb(json.dumps(incident_state(state)).encode())
        if path == '/api/incident/station-project.scd':
            if incident_state(state)['status'] not in ('ACTIVE','RECORDED'):
                return self.sendb(b'No dispatch telemetry-loss incident is active', 'text/plain', 404)
            if not SCD.is_file():
                return self.sendb(b'Engineering project unavailable', 'text/plain', 404)
            return self.sendb(SCD.read_bytes(), 'application/xml')
        # Old routes are deliberately closed even when leftovers exist on disk.
        if path == '/robots.txt' or path.startswith('/engineering/') or path == '/engineering':
            return self.sendb(b'not found', 'text/plain', 404)
        rel = 'index.html' if path == '/' else path.lstrip('/')
        p = (BASE / rel).resolve()
        if BASE.resolve() not in p.parents and p != BASE.resolve():
            return self.sendb(b'forbidden', 'text/plain', 403)
        if not p.is_file():
            return self.sendb(b'not found', 'text/plain', 404)
        return self.sendb(p.read_bytes(), mimetypes.guess_type(p.name)[0] or 'application/octet-stream')


if __name__ == '__main__':
    ThreadingHTTPServer(('0.0.0.0', 8095), H).serve_forever()
