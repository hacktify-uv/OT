#!/usr/bin/env python3
import json,os,time,threading
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
LOG=Path('/var/log/prabal-urja/scenario4/iec104-commands.jsonl');STATE=Path('/var/lib/prabal-urja/scenario4/latest-state.json');lock=threading.Lock();latest={'status':'starting','events':[],'last_update':None}
def follow():
 pos=0
 while True:
  if LOG.exists():
   with LOG.open() as f:
    f.seek(pos)
    for line in f:
     try:e=json.loads(line); latest['events']=(latest['events']+[e])[-100:];latest['last_update']=e.get('timestamp')
     except:pass
    pos=f.tell()
  latest['status']='up';time.sleep(.5)
class H(BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def do_GET(self):
  if self.path not in ('/health','/events'):self.send_response(404);self.end_headers();return
  body=json.dumps({'status':'UP','event_count':len(latest['events']),'last_update':latest['last_update'],'events':latest['events'][-20:]}).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
threading.Thread(target=follow,daemon=True).start();ThreadingHTTPServer(('0.0.0.0',8097),H).serve_forever()
