#!/usr/bin/env bash
set -Eeuo pipefail
OUT=${1:-/var/lib/prabal-urja/scenario4/evidence/$(date -u +%Y%m%dT%H%M%SZ)}
install -d -m 0750 "$OUT"
cp -a /var/log/prabal-urja/scenario4/. "$OUT/logs" 2>/dev/null || true
cp -a /var/lib/prabal-urja/scenario4/rtu-state.json /var/lib/prabal-urja/scenario4/latest-state.json "$OUT/" 2>/dev/null || true
journalctl --since today --no-pager \
 -u prabal-iec104-outstation.service -u prabal-iec104-master.service \
 -u prabal-s04-process.service -u prabal-s04-console.service \
 -u prabal-s04-command-monitor.service -u prabal-s04-capture.service \
 > "$OUT/systemd-journal.log" || true
auditctl -l > "$OUT/audit-rules.txt" 2>/dev/null || true
ausearch -k prabal_s04_telecontrol --start today --format raw > "$OUT/audit-exec.log" 2>/dev/null || true
ss -ltnp > "$OUT/listening-sockets.txt" || true
sha256sum "$OUT"/* 2>/dev/null > "$OUT/SHA256SUMS" || true
echo "$OUT"
