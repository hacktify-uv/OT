#!/usr/bin/env bash
set -Eeuo pipefail
python3 - <<'PY'
import json,urllib.request,subprocess,sys,time
services=['prabal-s04-network.service','prabal-iec104-master.service','prabal-iec104-outstation.service','prabal-s04-process.service','prabal-s04-console.service']
for svc in services:
 if subprocess.run(['systemctl','is-active','--quiet',svc]).returncode:
  print('SERVICE_STATUS:DOWN | REASON:SERVICE_INACTIVE:'+svc);sys.exit(1)
try:
 with urllib.request.urlopen('http://127.0.0.1:8096/state',timeout=5) as r:s=json.load(r)
 with urllib.request.urlopen('http://127.0.0.1:8095/api/health',timeout=5) as r:h=json.load(r)
except Exception as e:
 print('SERVICE_STATUS:DOWN | REASON:TELEMETRY_ENDPOINT_UNAVAILABLE');sys.exit(1)
if h.get('status')!='UP':print('SERVICE_STATUS:DOWN | REASON:HMI_HEALTH_FAILED');sys.exit(1)
if not s.get('telecontrol_online'):
 print('SERVICE_STATUS:DOWN | REASON:LEGITIMATE_IEC104_TELEMETRY_STALE | MASTER_EVENT:'+str(s.get('master_event')));sys.exit(1)
print('SERVICE_STATUS:UP | REASON:LEGITIMATE_IEC104_TELEMETRY_CURRENT');sys.exit(0)
PY
