#!/usr/bin/env bash
set -Eeuo pipefail
DIR=${1:-/var/log/prabal-urja/scenario4/pcap}
for f in "$DIR"/*.pcap*; do
 [[ -e "$f" ]] || continue
 echo "===== $f ====="
 tshark -r "$f" -Y 'iec60870_104 && (iec60870_asdu.typeid == 45 || iec60870_asdu.typeid == 49 || iec60870_asdu.typeid == 100)' \
   -T fields -E header=y -E separator=, \
   -e frame.time_utc -e ip.src -e ip.dst -e iec60870_asdu.typeid \
   -e iec60870_asdu.oa -e iec60870_asdu.addr -e iec60870_asdu.ioa 2>/dev/null || true
done
