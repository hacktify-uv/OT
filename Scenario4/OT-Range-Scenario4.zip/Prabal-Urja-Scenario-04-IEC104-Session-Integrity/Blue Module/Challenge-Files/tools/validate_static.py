#!/usr/bin/env python3
from pathlib import Path
import ast,json,sys
root=Path(__file__).resolve().parents[2]
required=['setup.sh','deps.sh','reset.sh','validate.sh','Red-Team-Attack-Script.sh','Red-Writeup.md','Blue-Writeup.md','Description.md','README.md','Reports/INREP.md','Reports/SITREP.md','Reports/Red-Report.md','TTP/Setup-TTP.yml','TTP/Service-Availability-TTP.yml','Challenge-Files/tmpfiles/prabal-s04.conf','Challenge-Files/lib60870/source/prabal_iec104_outstation.c','Challenge-Files/lib60870/source/prabal_iec104_master.c','Challenge-Files/lib60870/source/prabal_iec104_tool.c']
missing=[x for x in required if not (root/x).is_file()]
for p in root.rglob('*.py'): ast.parse(p.read_text(),filename=str(p))
for p in root.rglob('*.json'): json.loads(p.read_text())
setup=(root/'TTP/Setup-TTP.yml').read_text()
assert 'command: echo "Setup Successfully"' in setup
svc=(root/'TTP/Service-Availability-TTP.yml').read_text()
for token in ('systemctl','ss -ltn','prabal_iec104_tool','curl','journalctl','SERVICE_STATUS:UP','SERVICE_STATUS:DOWN'): assert token in svc
assert '<<<' not in svc
if missing: print('MISSING:',*missing);sys.exit(1)
print('STATIC_VALIDATION:PASS')
