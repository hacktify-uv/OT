#!/usr/bin/env bash
set -Eeuo pipefail
# Instructor only: restore vulnerable transit route for a fresh repeat.
if ip netns list | grep -q pu-s04-master; then
 ip netns exec pu-s04-master ip route del 10.104.2.2/32 2>/dev/null || true
fi
ip link del pu04-safe 2>/dev/null || true
rm -f /etc/prabal-urja/scenario4/blue-contained
systemctl disable prabal-s04-hardening.service >/dev/null 2>&1 || true
logger -t prabal-s04 'Lab transit route restored for exercise repeat'
echo 'ISOLATED_TRANSIT_PATH_RESTORED'
