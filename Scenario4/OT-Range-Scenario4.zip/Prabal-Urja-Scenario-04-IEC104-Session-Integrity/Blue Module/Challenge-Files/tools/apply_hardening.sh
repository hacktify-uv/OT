#!/usr/bin/env bash
set -Eeuo pipefail
[[ $EUID -eq 0 ]] || { echo 'RUN_AS_ROOT' >&2; exit 1; }
# Lab Blue Team bypasses compromised transit instead of stopping all IEC-104.
# This requires a private, independent veth and a new route. No uplink or S3 traffic.
ip netns list | grep -q pu-s04-master || { echo 'MASTER_NETNS_MISSING' >&2; exit 1; }
if ! ip -o link show pu04-safe >/dev/null 2>&1; then
 ip link add pu04-safe type veth peer name pu04-m-safe
 ip link set pu04-m-safe netns pu-s04-master
fi
ip addr replace 10.104.3.1/24 dev pu04-safe
ip link set pu04-safe up
ip netns exec pu-s04-master ip addr replace 10.104.3.2/24 dev pu04-m-safe
ip netns exec pu-s04-master ip link set pu04-m-safe up
ip netns exec pu-s04-master ip route replace 10.104.2.2/32 via 10.104.3.1 dev pu04-m-safe
install -d -m 0750 /etc/prabal-urja/scenario4
printf 'bypass\n' > /etc/prabal-urja/scenario4/blue-contained
logger -t prabal-s04 'Blue containment: IEC104 master now bypasses compromised transit via private route'
echo 'BLUE_CONTAINMENT:MASTER_PATH_BYPASSES_TRANSIT'
