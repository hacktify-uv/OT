Place the official lib60870 v2.4.0 source archive here for disconnected installation.
