#!/usr/bin/env python3
from __future__ import annotations
import csv,json,os,signal,threading,time
from datetime import datetime,timezone
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import pandapower as pp
from master_freshness import evaluate as master_freshness
RUNNING=True; LOCK=threading.Lock(); LATEST={'status':'starting'}
STATE=Path('/var/lib/prabal-urja/scenario4/rtu-state.json'); RUN=Path('/run/prabal-s04'); LOG=Path('/var/log/prabal-urja/scenario4'); DATA=Path('/var/lib/prabal-urja/scenario4')
def now():return datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
def atomic(path:Path,text:str):tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(text);os.replace(tmp,path)
def build():
 n=pp.create_empty_network(); b0=pp.create_bus(n,vn_kv=220,name='Regional Grid');b1=pp.create_bus(n,vn_kv=220,name='Prabal Control Bus');b2=pp.create_bus(n,vn_kv=132,name='Strategic Corridor');pp.create_ext_grid(n,bus=b0,vm_pu=1.0);line=pp.create_line_from_parameters(n,b0,b1,95,0.04,0.29,9.5,0.95);trafo=pp.create_transformer_from_parameters(n, b1, b2, sn_mva=650, vn_hv_kv=220, vn_lv_kv=132, vkr_percent=0.35, vk_percent=12.0, pfe_kw=80, i0_percent=0.12);load=pp.create_load(n,b2,310,62);imp=pp.create_sgen(n,b1,350,18);return n,line,trafo,load,imp,b1
class H(BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def do_GET(self):
  if self.path not in ('/health','/state'):self.send_response(404);self.end_headers();return
  with LOCK:b=json.dumps(LATEST).encode()
  self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
def main():
 global RUNNING,LATEST
 for p in (RUN,LOG,DATA):p.mkdir(parents=True,exist_ok=True)
 signal.signal(signal.SIGTERM,lambda *_:globals().__setitem__('RUNNING',False));signal.signal(signal.SIGINT,lambda *_:globals().__setitem__('RUNNING',False))
 srv=ThreadingHTTPServer(('0.0.0.0',8096),H);threading.Thread(target=srv.serve_forever,daemon=True).start();n,line,trafo,load,imp,bus=build(); hist=LOG/'process-historian.csv';fields=['timestamp','scenario_state','feeder_closed','transfer_tie_closed','load_shedding_enabled','import_setpoint_mw','served_load_mw','transformer_loading_pct','corridor_loading_pct','bus_voltage_kv','risk_state','sequence'];
 while RUNNING:
  try:s=json.loads(STATE.read_text())
  except Exception:s={'feeder_closed':True,'transfer_tie_closed':False,'load_shedding_enabled':True,'import_setpoint_mw':350,'sequence':0}
  feeder=bool(s.get('feeder_closed',True));tie=bool(s.get('transfer_tie_closed',False));shed=bool(s.get('load_shedding_enabled',True));sp=max(200,min(500,int(s.get('import_setpoint_mw',350))));served=310.0 if feeder else (95.0 if shed else 40.0);n.load.at[load,'p_mw']=served;n.load.at[load,'q_mvar']=served*.2;n.sgen.at[imp,'p_mw']=sp;n.sgen.at[imp,'q_mvar']=18+(sp-350)*.08
  try:pp.runpp(n,numba=False);tr=float(n.res_trafo.at[trafo,'loading_percent']);co=float(n.res_line.at[line,'loading_percent']);v=float(n.res_bus.at[bus,'vm_pu'])*220
  except Exception as e:print('POWER_FLOW_FAILED',repr(e),flush=True);time.sleep(1);continue
  master=master_freshness(); # command configuration is retained as environmental context only
  state='IEC104_TELECONTROL_LOST' if not master['telecontrol_online'] else 'DISPATCH_TELECONTROL_HEALTHY';risk=2 if co>=100 or tr>=100 else (1 if co>=94 or tr>=94 else 0)
  row={'timestamp':now(),'status':'up','scenario_state':state,'feeder_closed':feeder,'transfer_tie_closed':tie,'load_shedding_enabled':shed,'import_setpoint_mw':sp,'served_load_mw':round(served,1),'transformer_loading_pct':round(tr,2),'corridor_loading_pct':round(co,2),'bus_voltage_kv':round(v,2),'risk_state':risk,'sequence':int(s.get('sequence',0)),**master}
  atomic(RUN/'telemetry.dat',f"{int(served*10)} {int(tr*10)} {int(co*10)} {int(v*10)} {risk}\n");atomic(DATA/'latest-state.json',json.dumps(row,indent=2))
  new=not hist.exists();
  with hist.open('a',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader() if new else None;w.writerow({k:row[k] for k in fields})
  with LOCK:LATEST=row
  time.sleep(1)
 srv.shutdown();return 0
if __name__=='__main__':raise SystemExit(main())
