#!/usr/bin/env python3
"""Evaluate native IEC-104 master data freshness; no simulated packet poisoning."""
import json,time
from pathlib import Path
DEFAULT=Path('/run/prabal-s04/master-heartbeat.json')

def evaluate(path=DEFAULT, now_epoch=None, stale_after=40):
    now_epoch=time.time() if now_epoch is None else now_epoch
    try:
        record=json.loads(Path(path).read_text())
        last=float(record['last_rx_epoch'])
        age=max(0.0,now_epoch-last) if last>0 else None
        is_live=(age is not None and age<=stale_after and record.get('event')=='DATA_RECEIVED')
        return {'telecontrol_online':is_live,'master_data_age_seconds':round(age,2) if age is not None else None,
                'master_event':record.get('event','UNKNOWN'),'master_rx_count':int(record.get('rx_count',0))}
    except (OSError,ValueError,KeyError,TypeError):
        return {'telecontrol_online':False,'master_data_age_seconds':None,'master_event':'NO_HEARTBEAT','master_rx_count':0}

if __name__=='__main__':
    print(json.dumps(evaluate(),indent=2))
