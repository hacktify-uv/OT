#!/usr/bin/env python3
"""Read-only IEC-104 PCAP inspector, using Python's standard library.
Classic little-endian or big-endian PCAP with Ethernet (DLT_EN10MB) only.
"""
import argparse
import socket
import struct
from pathlib import Path


def parse_pcap(path):
    with Path(path).open('rb') as f:
        head = f.read(24)
        if len(head) != 24:
            raise ValueError('Truncated PCAP header')
        magic = head[:4]
        endian = '<' if magic in (b'\xd4\xc3\xb2\xa1', b'\x4d\x3c\xb2\xa1') else '>'
        if magic not in (b'\xd4\xc3\xb2\xa1', b'\xa1\xb2\xc3\xd4',
                         b'\x4d\x3c\xb2\xa1', b'\xa1\xb2\x3c\x4d'):
            raise ValueError('Expected classic PCAP, not PCAPNG. Use tcpdump -w')
        if struct.unpack(endian + 'I', head[20:24])[0] != 1:
            raise ValueError('Expected Ethernet PCAP (linktype 1)')
        while True:
            rec = f.read(16)
            if not rec:
                return
            if len(rec) != 16:
                raise ValueError('Truncated packet header')
            sec, usec, inclen, _ = struct.unpack(endian + 'IIII', rec)
            frame = f.read(inclen)
            if len(frame) != inclen:
                raise ValueError('Truncated packet data')
            yield sec, usec, frame


def iec104_packets(frame):
    if len(frame) < 14 or frame[12:14] != b'\x08\x00':
        return
    ip = frame[14:]
    if len(ip) < 20 or ip[0] >> 4 != 4 or ip[9] != 6:
        return
    iphlen = (ip[0] & 15) * 4
    if len(ip) < iphlen + 20:
        return
    src = socket.inet_ntoa(ip[12:16]); dst = socket.inet_ntoa(ip[16:20])
    tcp = ip[iphlen:]
    sport, dport = struct.unpack('!HH', tcp[:4])
    if sport != 2404 and dport != 2404:
        return
    thlen = (tcp[12] >> 4) * 4
    payload = tcp[thlen:]
    offset = 0
    while len(payload) - offset >= 6:
        p = payload[offset:]
        if p[0] != 0x68 or p[1] < 4 or len(p) < p[1] + 2:
            break
        c = p[2:6]
        fmt = 'I' if c[0] & 1 == 0 else ('S' if c[0] & 3 == 1 else 'U')
        if fmt == 'I':
            ns = int.from_bytes(c[0:2], 'little') >> 1
            nr = int.from_bytes(c[2:4], 'little') >> 1
        elif fmt == 'S':
            ns = None; nr = int.from_bytes(c[2:4], 'little') >> 1
        else:
            ns = nr = None
        yield src, dst, sport, dport, fmt, ns, nr
        offset += p[1] + 2


def main():
    p = argparse.ArgumentParser()
    p.add_argument('capture', help='Classic .pcap saved by tcpdump, not pcapng')
    args = p.parse_args()
    count = 0
    last = {}
    for sec, usec, frame in parse_pcap(args.capture):
        for src, dst, sport, dport, fmt, ns, nr in iec104_packets(frame) or ():
            flow = (src, dst, sport, dport)
            note = ''
            if fmt == 'I' and flow in last and ns != (last[flow] + 1) % 32768:
                note = ' SEQUENCE_GAP_OR_RETRANSMISSION'
            if fmt == 'I':
                last[flow] = ns
            print(f'{sec}.{usec:06d} {src}:{sport} -> {dst}:{dport} IEC104={fmt} '
                  f'NS={ns} NR={nr}{note}')
            count += 1
    print('IEC104_APDUS_OBSERVED=' + str(count))
    return 0 if count else 1

if __name__ == '__main__':
    raise SystemExit(main())
