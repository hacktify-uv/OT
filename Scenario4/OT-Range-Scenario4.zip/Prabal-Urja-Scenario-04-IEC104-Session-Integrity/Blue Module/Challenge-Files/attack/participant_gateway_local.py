#!/usr/bin/env python3
"""Instructor-provisioned, lab-only control for the existing bounded APCI test.
This is NOT an on-path exploit or a generic packet-manipulation service.
Accessible on localhost only. The pre-existing Scenario 04 runner owns the test.
"""
import json
import os
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

RUNNER = Path('/opt/prabal-urja/scenario4/attack/run-apci-lab.sh')
NAMESPACE = Path('/var/run/netns/pu-s04-transit')
LOGFILE = Path('/var/log/prabal-urja/scenario4/participant-apci-run.log')
STATE = {'process': None, 'started': None, 'last_finished': None}
LOCK = threading.Lock()
DURATION = 95
COOLDOWN = 600

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print('APCI_GATEWAY %s %s' % (self.client_address[0], fmt % args), flush=True)

    def reply(self, status, data):
        raw = json.dumps(data, separators=(',', ':')).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        if self.path != '/status':
            return self.reply(404, {'error':'not found'})
        with LOCK:
            proc = STATE['process']
            running = proc is not None and proc.poll() is None
            exit_code = None if proc is None or running else proc.returncode
            started = STATE['started']
        tail = []
        try:
            tail = LOGFILE.read_text(errors='replace').splitlines()[-15:]
        except OSError:
            pass
        self.reply(200, {'lab':'scenario04', 'status': 'RUNNING' if running else 'IDLE',
                         'exit_code':exit_code, 'last_started_epoch':started, 'tail':tail})

    def do_POST(self):
        if self.path != '/run':
            return self.reply(404, {'error':'not found'})
        if self.client_address[0] != '127.0.0.1':
            return self.reply(403, {'error':'loopback only'})
        try:
            n = int(self.headers.get('Content-Length','-1'))
            if n < 0 or n > 128:
                return self.reply(400, {'error':'invalid request size'})
            request = json.loads(self.rfile.read(n))
        except (ValueError, UnicodeDecodeError):
            return self.reply(400, {'error':'invalid JSON'})
        if request != {'exercise':'SCENARIO04_APCI', 'duration': DURATION}:
            return self.reply(400, {'error':'fixed, bounded lab exercise only'})
        if not (RUNNER.is_file() and NAMESPACE.exists()):
            return self.reply(503, {'error':'isolated Scenario 04 runner or namespace missing'})
        with LOCK:
            proc = STATE['process']
            if proc is not None and proc.poll() is None:
                return self.reply(409, {'error':'exercise already running'})
            now = time.time()
            if STATE['started'] and now - STATE['started'] < COOLDOWN:
                return self.reply(429, {'error':'exercise cooldown active'})
            LOGFILE.parent.mkdir(parents=True, exist_ok=True)
            loghandle = LOGFILE.open('w')
            try:
                proc = subprocess.Popen(['/usr/bin/bash', str(RUNNER), str(DURATION)],
                                        stdin=subprocess.DEVNULL, stdout=loghandle,
                                        stderr=subprocess.STDOUT, close_fds=True,
                                        start_new_session=True)
            except OSError as exc:
                loghandle.close()
                return self.reply(500, {'error':str(exc)})
            loghandle.close()
            STATE['process'] = proc
            STATE['started'] = now
        self.reply(202, {'status':'STARTED', 'pid':proc.pid, 'scope':'isolated Scenario 04 only'})

if __name__ == '__main__':
    if os.geteuid() != 0:
        raise SystemExit('Root is required for the already-installed isolated runner')
    ThreadingHTTPServer(('127.0.0.1', 18095), Handler).serve_forever()
