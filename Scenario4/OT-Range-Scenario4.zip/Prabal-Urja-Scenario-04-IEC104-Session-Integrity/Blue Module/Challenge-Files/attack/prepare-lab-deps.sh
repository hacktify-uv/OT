#!/usr/bin/env bash
set -Eeuo pipefail
[[ $EUID -eq 0 ]] || { echo 'Run as root on isolated lab VM' >&2; exit 1; }
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends iptables libnetfilter-queue-dev libnfnetlink-dev python3-dev python3-venv build-essential
python3 -m venv /opt/prabal-urja/scenario4/attack-venv
/opt/prabal-urja/scenario4/attack-venv/bin/python -m pip install --upgrade pip
/opt/prabal-urja/scenario4/attack-venv/bin/python -m pip install 'NetfilterQueue>=1.1.0,<2' 'scapy>=2.5,<3'
echo 'S04_LAB_ATTACK_DEPENDENCIES_INSTALLED'
