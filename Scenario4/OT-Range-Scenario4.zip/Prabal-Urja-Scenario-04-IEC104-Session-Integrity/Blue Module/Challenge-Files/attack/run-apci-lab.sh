#!/usr/bin/env bash
set -Eeuo pipefail
[[ $EUID -eq 0 ]] || { echo 'INSTRUCTOR: use sudo on the isolated lab VM' >&2; exit 1; }
ROOT=/opt/prabal-urja/scenario4
DURATION=${1:-95}
[[ $DURATION =~ ^[0-9]+$ ]] && (( DURATION >= 45 && DURATION <= 180 )) || { echo 'DURATION must be 45..180' >&2; exit 2; }
command -v iptables >/dev/null || { echo 'iptables missing: install via attack/prepare-lab-deps.sh' >&2; exit 1; }
[[ -x $ROOT/attack-venv/bin/python ]] || { echo 'attack venv missing: run attack/prepare-lab-deps.sh' >&2; exit 1; }
ip netns list | grep -q '^pu-s04-transit' || { echo 'pu-s04-transit missing' >&2; exit 1; }
# All operations are restricted to the isolated pu-s04-transit netns, not host FORWARD rules.
RULE=(-p tcp -s 10.104.2.2 -d 10.104.1.2 --sport 2404 -j NFQUEUE --queue-num 104 --queue-bypass)
cleanup() { ip netns exec pu-s04-transit iptables -w 5 -D FORWARD "${RULE[@]}" >/dev/null 2>&1 || true; }
trap cleanup EXIT INT TERM
ip netns exec pu-s04-transit iptables -w 5 -I FORWARD 1 "${RULE[@]}"
echo 'SCENARIO04_ISOLATED_QUEUE_ACTIVE'
ip netns exec pu-s04-transit "$ROOT/attack-venv/bin/python" "$ROOT/attack/apci_lab.py" --duration "$DURATION"
