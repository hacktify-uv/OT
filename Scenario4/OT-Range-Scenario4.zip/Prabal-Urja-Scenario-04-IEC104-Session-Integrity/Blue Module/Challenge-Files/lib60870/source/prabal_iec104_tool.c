#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include "cs104_connection.h"
#include "hal_thread.h"
static volatile bool gotData=false;
static bool rx(void* p,int a,CS101_ASDU asdu){(void)p;(void)a; printf("ASDU type=%s(%d) cot=%d ca=%d oa=%d negative=%d elements=%d\n",TypeID_toString(CS101_ASDU_getTypeID(asdu)),CS101_ASDU_getTypeID(asdu),CS101_ASDU_getCOT(asdu),CS101_ASDU_getCA(asdu),CS101_ASDU_getOA(asdu),CS101_ASDU_isNegative(asdu),CS101_ASDU_getNumberOfElements(asdu));
 for(int i=0;i<CS101_ASDU_getNumberOfElements(asdu);i++){ InformationObject o=CS101_ASDU_getElement(asdu,i); if(!o)continue; int ioa=InformationObject_getObjectAddress(o); TypeID t=CS101_ASDU_getTypeID(asdu); if(t==M_SP_NA_1) printf("POINT ioa=%d bool=%d\n",ioa,SinglePointInformation_getValue((SinglePointInformation)o)); else if(t==M_ME_NB_1) printf("POINT ioa=%d scaled=%d\n",ioa,MeasuredValueScaled_getValue((MeasuredValueScaled)o)); InformationObject_destroy(o);} gotData=true; return true; }
static void usage(const char*n){fprintf(stderr,"Usage: %s --host IP [--port 2404] [--ca 47] [--oa N] interrogate | single IOA 0|1 [--select] | setpoint IOA VALUE [--select]\n",n);}
int main(int argc,char**argv){const char*host="127.0.0.1";int port=2404,ca=47,oa=7;bool select=false;int i=1;while(i<argc&&strncmp(argv[i],"--",2)==0){if(!strcmp(argv[i],"--host")&&i+1<argc)host=argv[++i];else if(!strcmp(argv[i],"--port")&&i+1<argc)port=atoi(argv[++i]);else if(!strcmp(argv[i],"--ca")&&i+1<argc)ca=atoi(argv[++i]);else if(!strcmp(argv[i],"--oa")&&i+1<argc)oa=atoi(argv[++i]);else if(!strcmp(argv[i],"--select"))select=true;else{usage(argv[0]);return 2;}i++;} if(i>=argc){usage(argv[0]);return 2;} const char*action=argv[i++];
 CS104_Connection c=CS104_Connection_create(host,port); CS104_Connection_setOriginatorAddress(c,(uint8_t)oa); CS104_Connection_setASDUReceivedHandler(c,rx,NULL); if(!CS104_Connection_connect(c)){fprintf(stderr,"CONNECT_FAILED host=%s port=%d\n",host,port);CS104_Connection_destroy(c);return 3;} CS104_Connection_sendStartDT(c);Thread_sleep(800);bool ok=false;
 if(!strcmp(action,"interrogate")){ok=CS104_Connection_sendInterrogationCommand(c,CS101_COT_ACTIVATION,ca,IEC60870_QOI_STATION);}
 else if(!strcmp(action,"single")&&i+1<argc){int ioa=atoi(argv[i++]);int value=atoi(argv[i++]);InformationObject o=(InformationObject)SingleCommand_create(NULL,ioa,value!=0,select,0);ok=CS104_Connection_sendProcessCommandEx(c,CS101_COT_ACTIVATION,ca,o);InformationObject_destroy(o);printf("COMMAND_SENT type=C_SC_NA_1 ioa=%d value=%d select=%d oa=%d\n",ioa,value,select,oa);}
 else if(!strcmp(action,"setpoint")&&i+1<argc){int ioa=atoi(argv[i++]);int value=atoi(argv[i++]);InformationObject o=(InformationObject)SetpointCommandScaled_create(NULL,ioa,value,select,0);ok=CS104_Connection_sendProcessCommandEx(c,CS101_COT_ACTIVATION,ca,o);InformationObject_destroy(o);printf("COMMAND_SENT type=C_SE_NB_1 ioa=%d value=%d select=%d oa=%d\n",ioa,value,select,oa);} else{usage(argv[0]);CS104_Connection_destroy(c);return 2;}
 if(!ok){fprintf(stderr,"SEND_FAILED\n");CS104_Connection_destroy(c);return 4;} for(int n=0;n<30&&!gotData;n++)Thread_sleep(100); Thread_sleep(500);CS104_Connection_close(c);CS104_Connection_destroy(c);printf("IEC104_OPERATION_COMPLETED\n");return 0;}
