#define _POSIX_C_SOURCE 200809L
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>
#include "cs104_slave.h"
#include "hal_thread.h"
#include "hal_time.h"

#define CA 47
#define IOA_FEEDER 5001
#define IOA_TIE 5002
#define IOA_LOAD_SHED 5003
#define IOA_IMPORT_SETPOINT 6001
#define IOA_SERVED_LOAD 7001
#define IOA_TRAFO_LOADING 7002
#define IOA_CORRIDOR_LOADING 7003
#define IOA_BUS_VOLTAGE 7004
#define IOA_RISK 7005
#define STATE_FILE "/var/lib/prabal-urja/scenario4/rtu-state.json"
#define TELEMETRY_FILE "/run/prabal-s04/telemetry.dat"
#define COMMAND_LOG "/var/log/prabal-urja/scenario4/iec104-commands.jsonl"

static bool running = true;
static bool feederClosed = true;
static bool transferTieClosed = false;
static bool loadSheddingEnabled = true;
static int importSetpointMW = 350;
static int sequenceNo = 0;
static Semaphore stateLock;

typedef struct { int served; int trafo_x10; int corridor_x10; int voltage_x10; int risk; } Telemetry;

static void sig_handler(int sig) { (void)sig; running = false; }
static void iso_time(char* out, size_t n) { time_t t=time(NULL); struct tm tmv; gmtime_r(&t,&tmv); strftime(out,n,"%Y-%m-%dT%H:%M:%SZ",&tmv); }

static bool json_bool(const char* text, const char* key, bool fallback) {
  const char* p=strstr(text,key); if(!p) return fallback; p=strchr(p,':'); if(!p) return fallback;
  while(*++p==' '||*p=='\t'){} return strncmp(p,"true",4)==0 ? true : (strncmp(p,"false",5)==0 ? false : fallback);
}
static int json_int(const char* text, const char* key, int fallback) {
  const char* p=strstr(text,key); if(!p) return fallback; p=strchr(p,':'); if(!p) return fallback;
  char* end=NULL; long v=strtol(p+1,&end,10); return end==p+1 ? fallback : (int)v;
}
static bool load_state(void) {
  FILE* f=fopen(STATE_FILE,"r"); if(!f) return false;
  char buf[4096]; size_t n=fread(buf,1,sizeof(buf)-1,f); fclose(f); buf[n]='\0';
  feederClosed=json_bool(buf,"\"feeder_closed\"",true);
  transferTieClosed=json_bool(buf,"\"transfer_tie_closed\"",false);
  loadSheddingEnabled=json_bool(buf,"\"load_shedding_enabled\"",true);
  importSetpointMW=json_int(buf,"\"import_setpoint_mw\"",350);
  sequenceNo=json_int(buf,"\"sequence\"",0);
  return true;
}
static void write_state(int oa, const char* command) {
  char tmp[256]; snprintf(tmp,sizeof(tmp),"%s.tmp.%d",STATE_FILE,getpid());
  FILE* f=fopen(tmp,"w"); if (!f) return;
  fprintf(f,"{\n  \"feeder_closed\": %s,\n  \"transfer_tie_closed\": %s,\n  \"load_shedding_enabled\": %s,\n  \"import_setpoint_mw\": %d,\n  \"last_originator\": %d,\n  \"last_command\": \"%s\",\n  \"sequence\": %d\n}\n", feederClosed?"true":"false", transferTieClosed?"true":"false", loadSheddingEnabled?"true":"false", importSetpointMW, oa, command, sequenceNo);
  fflush(f); fsync(fileno(f)); fclose(f); rename(tmp,STATE_FILE); chmod(STATE_FILE,0660);
}
static void log_command(int oa, const char* type, int ioa, int value, bool select, bool accepted) {
  char ts[40]; iso_time(ts,sizeof(ts)); FILE* f=fopen(COMMAND_LOG,"a"); if(!f) return;
  fprintf(f,"{\"timestamp\":\"%s\",\"event\":\"IEC104_COMMAND\",\"oa\":%d,\"ca\":%d,\"type\":\"%s\",\"ioa\":%d,\"value\":%d,\"select\":%s,\"accepted\":%s,\"sequence\":%d}\n",ts,oa,CA,type,ioa,value,select?"true":"false",accepted?"true":"false",sequenceNo);
  fclose(f);
}
static Telemetry read_telemetry(void) {
  Telemetry t={3100,880,912,2192,1};
  FILE* f=fopen(TELEMETRY_FILE,"r");
  if(f){
    int served, trafo_x10, corridor_x10, voltage_x10, risk;
    int parsed=fscanf(f,"%d %d %d %d %d",&served,&trafo_x10,&corridor_x10,&voltage_x10,&risk);
    fclose(f);
    if(parsed==5){
      t.served=served;
      t.trafo_x10=trafo_x10;
      t.corridor_x10=corridor_x10;
      t.voltage_x10=voltage_x10;
      t.risk=risk;
    }
  }
  return t;
}
static void add_single(CS101_ASDU a, int ioa, bool value) {
  InformationObject io=(InformationObject)SinglePointInformation_create(NULL,ioa,value,IEC60870_QUALITY_GOOD);
  CS101_ASDU_addInformationObject(a,io); InformationObject_destroy(io);
}
static void add_scaled(CS101_ASDU a, int ioa, int value) {
  InformationObject io=(InformationObject)MeasuredValueScaled_create(NULL,ioa,value,IEC60870_QUALITY_GOOD);
  CS101_ASDU_addInformationObject(a,io); InformationObject_destroy(io);
}
static void send_snapshot(IMasterConnection connection, CS101_CauseOfTransmission cot, int oa) {
  CS101_AppLayerParameters p=IMasterConnection_getApplicationLayerParameters(connection);
  CS101_ASDU sp=CS101_ASDU_create(p,false,cot,oa,CA,false,false);
  add_single(sp,IOA_FEEDER,feederClosed); add_single(sp,IOA_TIE,transferTieClosed); add_single(sp,IOA_LOAD_SHED,loadSheddingEnabled);
  IMasterConnection_sendASDU(connection,sp); CS101_ASDU_destroy(sp);
  Telemetry t=read_telemetry(); CS101_ASDU mv=CS101_ASDU_create(p,false,cot,oa,CA,false,false);
  add_scaled(mv,IOA_SERVED_LOAD,t.served); add_scaled(mv,IOA_TRAFO_LOADING,t.trafo_x10); add_scaled(mv,IOA_CORRIDOR_LOADING,t.corridor_x10); add_scaled(mv,IOA_BUS_VOLTAGE,t.voltage_x10); add_scaled(mv,IOA_RISK,t.risk);
  IMasterConnection_sendASDU(connection,mv); CS101_ASDU_destroy(mv);
}
static bool interrogationHandler(void* parameter, IMasterConnection connection, CS101_ASDU asdu, uint8_t qoi) {
  (void)parameter; if(CS101_ASDU_getCA(asdu)!=CA || qoi!=20){ IMasterConnection_sendACT_CON(connection,asdu,true); return true; }
  IMasterConnection_sendACT_CON(connection,asdu,false); Semaphore_wait(stateLock); send_snapshot(connection,CS101_COT_INTERROGATED_BY_STATION,CS101_ASDU_getOA(asdu)); Semaphore_post(stateLock); IMasterConnection_sendACT_TERM(connection,asdu); return true;
}
/* Session-integrity exercise: legacy dispatch switching commands are refused.
   This is an available native IEC-104 station, not a command-abuse challenge. */
static bool asduHandler(void* parameter, IMasterConnection connection, CS101_ASDU asdu) {
  (void)parameter;
  CS101_ASDU_setCOT(asdu, CS101_COT_ACTIVATION_CON);
  CS101_ASDU_setNegative(asdu, true);
  IMasterConnection_sendASDU(connection, asdu);
  printf("IEC104_UNAUTHORISED_CONTROL_REJECTED type=%d\n", (int)CS101_ASDU_getTypeID(asdu));
  fflush(stdout);
  return true;
}
static bool connectionRequestHandler(void* parameter,const char* ip){ (void)parameter; printf("CONNECTION_REQUEST source=%s decision=ACCEPT_NO_SOURCE_ALLOWLIST\n",ip); fflush(stdout); return true; }
static void connectionEventHandler(void* p, IMasterConnection c, CS104_PeerConnectionEvent e){ (void)p; printf("CONNECTION_EVENT handle=%p event=%d\n",(void*)c,(int)e); fflush(stdout); }
int main(void){ signal(SIGINT,sig_handler); signal(SIGTERM,sig_handler); stateLock=Semaphore_create(1); if(!load_state()) write_state(1,"BASELINE");
  CS104_Slave s=CS104_Slave_create(100,100); CS104_Slave_setLocalAddress(s,"0.0.0.0"); CS104_Slave_setLocalPort(s,2404); CS104_Slave_setServerMode(s,CS104_MODE_CONNECTION_IS_REDUNDANCY_GROUP);
  CS104_Slave_setInterrogationHandler(s,interrogationHandler,NULL); CS104_Slave_setASDUHandler(s,asduHandler,NULL); CS104_Slave_setConnectionRequestHandler(s,connectionRequestHandler,NULL); CS104_Slave_setConnectionEventHandler(s,connectionEventHandler,NULL);
  CS104_Slave_start(s); if(!CS104_Slave_isRunning(s)){ fprintf(stderr,"IEC104_SERVER_START_FAILED\n"); return 2; }
  printf("IEC104_SERVER_READY port=2404 ca=%d\n",CA); fflush(stdout);
  while(running) Thread_sleep(250);
  CS104_Slave_stop(s); CS104_Slave_destroy(s); Semaphore_destroy(stateLock); return 0; }
