#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <signal.h>
#include <time.h>
#include <pthread.h>
#include <string.h>
#include "cs104_connection.h"
#include "hal_thread.h"

static volatile sig_atomic_t running=1;
static pthread_mutex_t lock=PTHREAD_MUTEX_INITIALIZER;
static time_t last_rx=0;
static unsigned long rx_count=0;
static const char* HEARTBEAT="/run/prabal-s04/master-heartbeat.json";
static void stop(int signum) { (void)signum; running=0; }

static void heartbeat(const char* event) {
  char tmp[256];
  snprintf(tmp,sizeof(tmp),"%s.tmp",HEARTBEAT);
  pthread_mutex_lock(&lock);
  FILE *f=fopen(tmp,"w");
  if (f) {
    fprintf(f,"{\"event\":\"%s\",\"last_rx_epoch\":%lld,\"last_event_epoch\":%lld,\"rx_count\":%lu}\n",
            event,(long long)last_rx,(long long)time(NULL),rx_count);
    fclose(f); rename(tmp,HEARTBEAT);
  }
  pthread_mutex_unlock(&lock);
}
static void connection_event(void* ctx, CS104_Connection c, CS104_ConnectionEvent e) {
  (void)ctx;(void)c;
  if(e==CS104_CONNECTION_CLOSED || e==CS104_CONNECTION_FAILED) {
    heartbeat("DISCONNECTED"); puts("LEGITIMATE_MASTER_DISCONNECTED"); fflush(stdout);
  }
  else if(e==CS104_CONNECTION_OPENED) {
    heartbeat("CONNECTED"); puts("LEGITIMATE_MASTER_CONNECTED"); fflush(stdout);
  }
}
static bool rx(void*ctx,int addr,CS101_ASDU asdu) {
  (void)ctx;(void)addr;
  pthread_mutex_lock(&lock);last_rx=time(NULL);rx_count++;pthread_mutex_unlock(&lock);
  heartbeat("DATA_RECEIVED");
  printf("LEGITIMATE_MASTER_DATA type=%s cot=%d ca=%d elements=%d\n",TypeID_toString(CS101_ASDU_getTypeID(asdu)),CS101_ASDU_getCOT(asdu),CS101_ASDU_getCA(asdu),CS101_ASDU_getNumberOfElements(asdu));
  fflush(stdout);return true;
}
int main(int argc,char**argv) {
  const char*host=argc>1?argv[1]:"127.0.0.1";
  int port=argc>2?atoi(argv[2]):2404;
  signal(SIGINT,stop);signal(SIGTERM,stop);
  heartbeat("STARTING");
  while(running) {
    CS104_Connection c=CS104_Connection_create(host,port);
    CS104_Connection_setOriginatorAddress(c,1);
    CS104_Connection_setConnectionHandler(c,connection_event,NULL);
    CS104_Connection_setASDUReceivedHandler(c,rx,NULL);
    if(CS104_Connection_connect(c)) {
      CS104_Connection_sendStartDT(c);
      while(running) {
        if(!CS104_Connection_sendInterrogationCommand(c,CS101_COT_ACTIVATION,47,IEC60870_QOI_STATION)) {
          heartbeat("INTERROGATION_FAILED");break;
        }
        for(int i=0;i<150 && running;i++) Thread_sleep(100);
      }
      CS104_Connection_close(c);
    } else { heartbeat("CONNECT_FAILED"); }
    CS104_Connection_destroy(c);
    for(int i=0;i<20 && running;i++) Thread_sleep(100);
  }
  heartbeat("STOPPED");
  return 0;
}
