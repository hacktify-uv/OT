#!/usr/bin/env python3
import importlib.util,json,tempfile
from pathlib import Path
source=Path(__file__).resolve().parents[1]/'Challenge-Files/process/master_freshness.py'
spec=importlib.util.spec_from_file_location('fresh',source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with tempfile.TemporaryDirectory() as td:
 p=Path(td)/'heartbeat.json'
 assert m.evaluate(p,100)['telecontrol_online'] is False
 p.write_text(json.dumps({'event':'DATA_RECEIVED','last_rx_epoch':95,'rx_count':4}))
 assert m.evaluate(p,100)['telecontrol_online'] is True
 assert m.evaluate(p,140)['telecontrol_online'] is False
 p.write_text(json.dumps({'event':'DISCONNECTED','last_rx_epoch':139,'rx_count':4}))
 assert m.evaluate(p,140)['telecontrol_online'] is False
print('MASTER_FRESHNESS_TEST:PASS')
