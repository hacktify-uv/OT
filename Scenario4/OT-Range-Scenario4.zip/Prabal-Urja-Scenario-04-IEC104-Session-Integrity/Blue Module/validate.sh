#!/usr/bin/env bash
set -Eeuo pipefail
ROOT=/opt/prabal-urja/scenario4
if [[ "${1:-}" != '--installed' ]]; then
 python3 -m py_compile "$(dirname "$0")/Challenge-Files/process/"*.py
 bash -n "$(dirname "$0")/setup.sh"
 echo 'STATIC_CHECK:PASS'; exit 0
fi
systemctl is-active --quiet prabal-s04-network.service
ip netns exec pu-s04-master ip route get 10.104.2.2
ip netns exec pu-s04-transit ip route get 10.104.2.2
systemctl is-active --quiet prabal-iec104-master.service
systemctl is-active --quiet prabal-iec104-outstation.service
curl -fsS http://127.0.0.1:8095/api/health >/dev/null
# Incident workflow responds even when the dispatcher is healthy (MONITORING).
curl -fsS http://127.0.0.1:8095/api/incident >/dev/null
# The old anonymous discovery route must no longer be exposed.
[[ $(curl -sS -o /dev/null -w '%{http_code}' http://127.0.0.1:8095/robots.txt) == 404 ]]
[[ $(curl -sS -o /dev/null -w '%{http_code}' http://127.0.0.1:8095/engineering/station-register.json) == 404 ]]
curl -fsS http://127.0.0.1:8096/state >/dev/null
"$ROOT/tools/service_availability.sh"
