# Prabal Urja operational handoff
S1 OPC UA (`PU-GOV-PLC-02`) → S2 Modbus (`PU-RB-RTU-07`) → S3 DNP3 (`PU-LDC-DNP3-MASTER-01`, Northern Load Dispatch Centre) → S4 IEC-104 (`PU-LDC-IEC104-01`) → S5 IEC 61850 (`PU-DSS-IED-01`).

These are discoverable engineering and asset links. There is no shared electrical process model or direct network path between separately launched VM challenges. Scenario 3 is not modified.
