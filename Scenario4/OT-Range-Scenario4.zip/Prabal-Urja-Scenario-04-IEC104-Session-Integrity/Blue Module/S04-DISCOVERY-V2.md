# Scenario 04 | Revised participant path

**Not Scenario 03 again:** there is no `robots.txt` treasure hunt, no anonymous
JSON point-map and no command-authorisation or breaker-writing challenge.

1. Identify the IEC 60870-5-104 service and observe live dispatch telemetry.
2. Work from an instructor-authorised position on the **existing** master-to-RTU
   communication route, not merely a new TCP connection to port 2404.
3. Capture native IEC-104 frames, inspect the APCI I-frame N(S)/N(R) counters.
   A read-only classic PCAP inspector is installed at
   `/opt/prabal-urja/scenario4/attack/iec104_pcap_inspector.py`.
4. Investigate the published APCI sequence-manipulation technique. A bounded
   Scenario 04-only NFQUEUE experiment is installed at
   `/opt/prabal-urja/scenario4/attack/run-apci-lab.sh`, with optional dependencies
   from `attack/prepare-lab-deps.sh`. It touches only the 10.104.2.2:2404 ->
   10.104.1.2 flow in `pu-s04-transit`; never run it on a real OT network.
5. Verify *both* (a) a genuine capture of modified APCI N(S) and (b) the
   independent native master becoming stale. A DOWN status alone is NOT proof.
6. Only after a valid dispatch telemetry-loss incident, use the HMI's **Incident
   correlation** panel to obtain the relevant engineering SCL project and
   identify `PU-DSS-IED-01`. This is the logical Scenario 05 handoff, not
   network access, a password or a continuous shared plant simulation.

## Operator instructions

- Apply the patch with `sudo python3 patch_s04.py` on Scenario 04's VM.
- It modifies all 3 local modules and the installed Scenario 04 runtime.
- It edits `setup.sh` for subsequent fresh installs and does not rerun it.
- It restarts only `prabal-s04-console.service` if that service exists.
- To prepare optional attacker dependencies, run
  `sudo bash /opt/prabal-urja/scenario4/attack/prepare-lab-deps.sh`.
- To run an **instructor-contained** test after preparation, use
  `sudo bash /opt/prabal-urja/scenario4/attack/run-apci-lab.sh 95`.
- The tool must be live-tested. A participant-accessible on-path foothold is
  NOT automatically provisioned by this patch; it is an instructor/platform task.

## Scenario 05 non-repetition guardrails

Scenario 05 must not repeat S03's `robots.txt` + JSON point map, S04's
network-sequence poisoning, S01's maintenance-ticket trick, or S02/S03's
unrestricted protocol write-and-done attack. Its *separate* challenge is
engineering-workflow authorisation of a real IEC 61850 MMS setting-group change
and independent protection relay response. Merely browsing the SCL file or
connecting to port 102 must not count as exploitation.

Published reproducibility reference:
https://github.com/CrySyS/IEC-104-Attacks
