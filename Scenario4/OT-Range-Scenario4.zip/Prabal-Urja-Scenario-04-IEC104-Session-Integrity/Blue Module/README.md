# Prabal Urja Scenario 04 | IEC-104 Telecontrol Session Integrity

**Status:** Ubuntu deployable source candidate. Native compilation and APCI manipulation have NOT been verified on a live instance. No changes are made to Scenario 3.

## Objective
Northern Load Dispatch Centre's legitimate native lib60870 IEC-104 master communicates with a native outstation across a dedicated isolated transit namespace. The attacker has an on-path position to investigate documented IEC-104 APCI sequence-integrity attacks. The RTU remains active; dispatch telemetry becomes stale if the session is disrupted.

## Topology
- IEC-104 master in namespace `pu-s04-master`: `10.104.1.2`
- Isolated transit namespace `pu-s04-transit`: `10.104.1.1`, `10.104.2.1`
- Native IEC-104 outstation on lab host: `10.104.2.2:2404`
- HMI: port `8095`, process API: `8096`
- S3's `PU-LDC-DNP3-MASTER-01` identifies the control centre. S4's separate asset is `PU-LDC-IEC104-01`.

## Installation
On a **separate clean Ubuntu 22.04/24.04 VM** (not Scenario 3), with internet access to download lib60870 unless the vendor archive is preloaded:

```bash
sudo bash deps.sh
sudo bash setup.sh
sudo bash validate.sh --installed
```

The native upstream library is compiled during installation; no binary is bundled. The host must have permission to create Linux network namespaces.

## Participant discovery and attack
1. Discover HMI port 8095 and investigate the existing IEC-104 master/outstation communication path; no `robots.txt` or JSON-point-map clues.
2. Verify actual native master-to-RTU traffic and fresh telemetry.
3. Instructor provisions a restricted on-path transit position. Inspect IEC-104 N(S)/N(R) via Wireshark/tshark.
4. Reproduce a documented APCI sequence-integrity failure on this isolated lab path. A **source-only bounded NFQUEUE test** is included at `Challenge-Files/attack/run-apci-lab.sh`; the optional `prepare-lab-deps.sh` installs its prerequisites. This is instructor-contained, not a pre-built participant-ready attack.
5. Observe whether master telemetry genuinely becomes stale. Preserve packet captures to confirm root cause independently.

Instructor PCAP diagnostic:

```bash
sudo ip netns exec pu-s04-transit tcpdump -ni pu04-tm tcp port 2404
```

The transit namespace is NOT automatically exposed as an external participant SSH service. It must be deliberately made accessible through the range environment.

## Scoring and limitations
`DOWN` means the genuine master lost current telemetry; it does not, by itself, prove APCI poisoning. Packet-level evidence is a separate acceptance condition. S4 does not require legacy four-command switching and does not alter S3's API, processes, or TTP.

## Scenario 5 handoff
After genuine telemetry loss, `/api/incident/station-project.scd` identifies the independently launched protection IED. OpenStack assigns each new VM's dynamic IP. No invented direct network route or credentials.

## References
https://github.com/CrySyS/IEC-104-Attacks
https://github.com/mz-automation/lib60870


**Incident-first discovery v2:** See `S04-DISCOVERY-V2.md` for the new path and attack tool status.


### Clean-install v3 notes

`sudo bash setup.sh` performs dependency installation and starts all services, then waits for real IEC-104 master telemetry before declaring success (maximum approximately two minutes after starting services). It already includes the transformer-impedance correction and incident-discovery change, so **do not apply `patch_s04.py` or rerun separate hotfixes** after installing this ZIP. The installer does not alter Scenario 3 components, but install it on a separate fresh VM for isolation.

The setup does not automatically create a remote Red Team on-path account. Until that and the NFQUEUE experiment have been live-tested, the external Red Team exploit path remains incomplete.
