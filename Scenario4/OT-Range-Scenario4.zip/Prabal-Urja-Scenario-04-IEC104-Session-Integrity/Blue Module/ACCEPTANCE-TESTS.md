# Scenario 04: validation protocol

**No live Ubuntu install, native compilation, on-path attacker test, or APCI packet-manipulation test has been completed for this ZIP.** The command lines below are acceptance requirements, not observed results.

## 1. Deployment isolation

Install this module ONLY on a new Ubuntu 22.04 or 24.04 VM. Do not install on Scenario 03. The IPs in the namespace are internal to the new VM, and OpenStack floating addresses are assigned separately. Obtain upstream lib60870 source during setup.

```sh
sudo bash setup.sh
sudo bash validate.sh --installed
```

## 2. Establish normal IEC-104 communication

Confirm with all of these: `systemctl is-active prabal-iec104-master.service`, `journalctl -u prabal-iec104-master.service --since '-2 minutes'`, packet captures inside `pu-s04-transit`, and `/api/health`. Obtain a real `LEGITIMATE_MASTER_DATA` message and fresh `/run/prabal-s04/master-heartbeat.json`. A mere open port or HTTP health request is insufficient.

```sh
sudo ip netns exec pu-s04-transit tcpdump -ni pu04-tm tcp port 2404
curl -sS http://127.0.0.1:8096/state | python3 -m json.tool
test "$(curl -sS -o /dev/null -w '%{http_code}' http://127.0.0.1:8095/robots.txt)" = 404
curl -sS http://127.0.0.1:8095/api/incident
```

## 3. Reproduce the published on-path APCI experiment

The instructor must provide a controlled and expressly authorised on-path participant position in the isolated transit namespace. This package **does not** provide that externally reachable access path or an offensive injector. Use the published CrySyS research `https://github.com/CrySyS/IEC-104-Attacks` as an upstream study/reference, and independently capture real IEC-104 bytes before and after. Do not infer APCI poisoning solely from a disconnected service.

Verify that the legitimate master stops receiving fresh ASDUs (not merely that a test variable changes). The scoring TTP should return `SERVICE_STATUS:DOWN`, with evidence showing the actual manipulated APCI sequence in the PCAP. This remains **UNVERIFIED** until demonstrated.

## 4. Blue Team recovery

Preserve journal/PCAP/telemetry first, then bypass the compromised transit using the shipped Blue Team script and verify new, current native IEC-104 measurements. The original field-station process should remain available throughout. CTF TTP should return `SERVICE_STATUS:UP`. Verify both directions, then repeat from a fresh installation.

## 5. Engineering handoff

After a confirmed telemetry-loss incident, open the HMI incident-correlation panel and retrieve `/api/incident/station-project.scd`. Validate the IED name `PU-DSS-IED-01` against the Scenario 05 package. This is logical asset discovery, **not an unimplemented direct network pivot**.
