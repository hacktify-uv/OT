# Implementation and test status
- Static syntax and inventory tests: available in package.
- Native lib60870: fetched and compiled on Ubuntu, not included.
- Network namespaces: defined, require privileged Ubuntu runtime test.
- Genuine APCI poisoning and runtime recovery: NOT verified.
- Separate attacker on-path entry: requires instructor provision, no attacker exploit generator included.
- Scenario 3 unchanged.


## Clean install v3 (31 October 2026)

- Transformer short-circuit impedance parameters corrected in the source for all three modules.
- Legacy `/robots.txt` and public `/engineering/station-register.json` clues removed; incident correlation is gated on genuine lost IEC-104 master telemetry.
- New installers use up to two minutes of actual service-status polling rather than a fixed eight-second sleep and print service logs if not healthy.
- Optional bounded APCI research experiment is present under `Challenge-Files/attack/`. Its dependencies and instructor-controlled on-path position are NOT provisioned automatically.
- This bundle has passed syntax, source and HTTP-path tests in a build environment. **Native C compilation, NetfilterQueue attack effect and end-to-end Ubuntu reinstall have not been independently retested here.**
