# Blue Team investigation
1. Preserve master and outstation journals, the historian and transit PCAP.
2. Compare actual `master-heartbeat.json` timestamps, `master_rx_count`, and legitimate session events.
3. Examine APCI N(S)/N(R) continuity in actual capture to attribute the session failure. Stale telemetry alone is insufficient.
4. In the isolated lab, run `sudo /opt/prabal-urja/scenario4/tools/apply_hardening.sh` to reroute the legitimate master through a safe internal veth bypass of the compromised transit (not an external network).
5. Confirm fresh native IEC-104 interrogations and Service Availability `UP`.
