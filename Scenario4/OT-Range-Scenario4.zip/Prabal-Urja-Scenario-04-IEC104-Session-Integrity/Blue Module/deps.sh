#!/usr/bin/env bash
set -Eeuo pipefail
[[ $EUID -eq 0 ]] || { echo 'Run as root: sudo bash deps.sh' >&2; exit 1; }

source /etc/os-release

if command -v pacman &>/dev/null; then
  echo "[+] Detected Arch Linux or pacman-based system."
  pacman -Sy --noconfirm --needed \
    base-devel cmake git ca-certificates pkgconf python python-pip openssh \
    sudo nftables audit tcpdump wireshark-cli curl jq iproute2 openbsd-netcat zip unzip
elif command -v apt-get &>/dev/null; then
  export DEBIAN_FRONTEND=noninteractive
  apt-get update
  apt-get install -y --no-install-recommends build-essential cmake git ca-certificates pkg-config \
   python3 python3-venv python3-pip python3-dev openssh-server sudo nftables auditd \
   tcpdump tshark curl jq iproute2 netcat-openbsd zip unzip
else
  echo "[!] Error: No supported package manager (apt-get or pacman) found." >&2
  exit 1
fi
