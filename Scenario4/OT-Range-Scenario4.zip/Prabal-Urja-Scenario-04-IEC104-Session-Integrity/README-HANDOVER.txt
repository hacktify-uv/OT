PRABAL URJA SCENARIO 04 - HANDOVER

Contains Red, Blue, and Red-vs-Blue modules.
Use the appropriate module's setup.sh and validate.sh.

IMPORTANT:
1. Use an isolated, authorised Ubuntu lab environment.
2. Verify the configured participant VPN IP before deployment.
3. The APCI experiment requires prepare-lab-deps.sh.
4. After setup, an administrator may need to run:
   sudo bash /opt/prabal-urja/scenario4/attack/prepare-lab-deps.sh
   sudo systemctl restart prabal-s04-participant-gateway.service
5. Run the selected module's validate.sh.
6. Fresh-install functionality must be tested on a clean VM.
