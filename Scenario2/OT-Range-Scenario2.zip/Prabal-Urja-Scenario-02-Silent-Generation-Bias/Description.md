# Silent Generation Bias

Prabal Urja Hydroelectric Power Station is supporting the northern transmission corridor during an evening period of elevated demand. Unit-2 is operating under automatic load control while its generator transformer and the outgoing 220 kV corridor remain within their approved operating limits.

Following the telemetry irregularities investigated during the earlier maintenance event, shift supervisor **Ananya Rao** has asked grid operations engineer **Vikram Singh** to review a gradual change in Unit-2 output. The change is not large enough to trigger an immediate protection trip, but it is reducing operating margin and increasing thermal stress across connected equipment.

Red and Blue teams operate on the same live exercise infrastructure. The Red Team must determine whether the control path can be misused to create a meaningful process effect without crashing the controller or causing indiscriminate disruption. The Blue Team must identify abnormal control activity, distinguish malicious manipulation from legitimate dispatch behaviour, contain the source with minimal interruption, restore the approved operating state, and preserve evidence.

This is an intermediate OT live-fire scenario. Flooding, denial-of-service activity, operating-system exploitation, destructive file modification, and attacks against the range management plane are outside the rules of engagement.
