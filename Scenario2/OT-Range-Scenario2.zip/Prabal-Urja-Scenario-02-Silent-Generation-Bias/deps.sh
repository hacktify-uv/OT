#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
if [[ $EUID -ne 0 ]]; then echo "Run deps.sh as root: sudo bash deps.sh" >&2; exit 1; fi
[[ -r /etc/os-release ]] || { echo "Missing /etc/os-release" >&2; exit 1; }
# shellcheck disable=SC1091
source /etc/os-release
if command -v pacman &>/dev/null; then
  echo "[+] Detected Arch Linux or pacman-based system."
  pacman -Sy --noconfirm --needed \
    autoconf automake bison ca-certificates cmake curl flex git iproute2 jq libtool make \
    openbsd-netcat nftables openssl pkgconf python python-pip sqlite sudo tcpdump wireshark-cli \
    base-devel
elif command -v apt-get &>/dev/null; then
  if [[ "${ID:-}" != "ubuntu" ]] || [[ "${VERSION_ID:-}" != "22.04" && "${VERSION_ID:-}" != "24.04" ]]; then
    echo "[!] WARNING: Supported systems are Ubuntu 22.04 Jammy and Ubuntu 24.04 Noble." >&2
    echo "[!] Detected ID=${ID:-unknown} VERSION_ID=${VERSION_ID:-unknown}" >&2
    echo "[!] Proceeding with dependencies setup anyway..." >&2
  fi
  export DEBIAN_FRONTEND=noninteractive
  if [[ "${PRABAL_SKIP_APT_UPDATE:-0}" != "1" ]]; then apt-get update; fi
  # Avoid the interactive dumpcap privilege question. The capture service runs as root.
  echo 'wireshark-common wireshark-common/install-setuid boolean false' | debconf-set-selections || true
  apt-get install -y --no-install-recommends \
    autoconf automake bison build-essential ca-certificates cmake curl debconf-utils flex git \
    iproute2 jq libtool make netcat-openbsd nftables openssl pkg-config python3 python3-dev \
    python3-pip python3-venv sqlite3 sudo tcpdump tshark
else
  echo "[!] Error: No supported package manager (apt-get or pacman) found." >&2
  exit 1
fi

echo "DEPENDENCIES_INSTALLED"
