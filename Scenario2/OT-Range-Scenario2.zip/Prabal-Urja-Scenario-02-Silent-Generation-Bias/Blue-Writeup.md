# Blue Team Writeup — Scenario 2: Silent Generation Bias

## 1. Defensive objective

Detect and contain unauthorised Modbus control of Unit-2 while maintaining legitimate PLC operation, operator visibility and process simulation. Determine whether the observed output change is a valid dispatch action, operator error, controller malfunction or malicious network command.

## 2. Expected baseline

Asset: `PU-GOV-PLC-02`

Normal state:

| Item | Expected value |
|---|---:|
| Generator setpoint | approximately 650 MW |
| Ramp rate | 1.0 MW/s |
| Governor mode | automatic (`1`) |
| Maintenance override | disabled (`0`) |
| Cooling demand | 100% |
| Grid risk state | normal (`0`) |
| Authorised remote masters | defined by exercise asset register |

Core services:

```bash
systemctl status prabal-openplc.service --no-pager
systemctl status prabal-grid-simulator.service --no-pager
systemctl status prabal-operator-console.service --no-pager
systemctl status prabal-modbus-capture.service --no-pager
```

Validate the complete service chain:

```bash
cd Prabal-Urja-Scenario-02-Silent-Generation-Bias
sudo ./validate.sh
```

## 3. Initial detection

Potential indicators include:

- setpoint changes without a matching dispatch ticket;
- repeated small increases that remain below static alarm thresholds;
- command sequence increments outside the control-room workflow;
- Modbus FC06 or FC16 writes from an unapproved source;
- actual generation and transformer loading trending upward together;
- operator console showing a stressed state without a protection trip.

Review the current state:

```bash
curl -s http://127.0.0.1:8090/api/live | jq
curl -s http://127.0.0.1:8091/health | jq
```

Read the PLC directly using the packaged protocol probe:

```bash
sudo /opt/prabal-urja/scenario2/venv/bin/python \
  /opt/prabal-urja/scenario2/tools/modbus_probe.py \
  --host 127.0.0.1 --port 502 --address 1024 --count 24 | jq
```

## 4. Establish operational legitimacy

Before containment, ask:

1. Did grid operations authorise a Unit-2 setpoint change?
2. Does the command sequence match the dispatch log?
3. Was a maintenance override approved?
4. Did the change originate from an authorised master?
5. Is the change rate consistent with normal load following?

A network command may be technically valid while operationally unauthorised.

## 5. Review process historian evidence

Show recent setpoint and process changes:

```bash
tail -n 80 /var/log/prabal-urja-s02/process-historian.csv | column -s, -t
```

Review discrete command-change events:

```bash
jq -c 'select(.event_type=="PLC_COMMAND_REGISTER_CHANGE")' \
  /var/log/prabal-urja-s02/process-events.jsonl
```

Find the first departure from the approved 650 MW baseline:

```bash
awk -F, 'NR==1 || $2 != 650 {print}' \
  /var/log/prabal-urja-s02/process-historian.csv | head -30
```

Correlate:

- event timestamp;
- old and new setpoint;
- command sequence;
- actual generation response;
- transformer and corridor loading;
- risk-state transition.

## 6. Identify the Modbus command source

List packet captures:

```bash
sudo ls -lh /var/log/prabal-urja-s02/pcap/
```

Extract write operations from each capture:

```bash
for PCAP in /var/log/prabal-urja-s02/pcap/*.pcap; do
  echo "===== $PCAP ====="
  sudo /opt/prabal-urja/scenario2/tools/pcap_modbus_writes.sh "$PCAP"
done
```

Useful display filter:

```text
modbus.func_code == 6 || modbus.func_code == 16
```

Important function codes:

- `6` — Write Single Register
- `16` — Write Multiple Registers

Focus on references beginning at 1024 and determine:

- source IP and source port;
- destination IP and TCP 502;
- function code;
- target register;
- written value;
- frequency and timing.

Produce a source summary:

```bash
sudo tshark -n -r /var/log/prabal-urja-s02/pcap/<FILE>.pcap \
  -Y 'modbus.func_code == 6 || modbus.func_code == 16' \
  -T fields -e ip.src | sort | uniq -c | sort -nr
```

## 7. Check service and host integrity

Confirm the attacker has not changed the PLC program or stopped services:

```bash
systemctl is-active prabal-openplc.service prabal-grid-simulator.service prabal-operator-console.service
sha256sum /opt/prabal-urja/scenario2/openplc/webserver/st_files/prabal_unit2.st
journalctl -u prabal-openplc.service --since '-30 minutes' --no-pager
journalctl -u prabal-grid-simulator.service --since '-30 minutes' --no-pager
```

The intended attack changes command registers over Modbus. Unexpected program-file changes or service restarts indicate activity outside the expected scenario path.

## 8. Containment

### 8.1 Preserve evidence first

```bash
sudo /opt/prabal-urja/scenario2/tools/collect_evidence.sh
```

### 8.2 Apply a precise Modbus allowlist

Identify the legitimate SCADA master from the asset register and baseline packet captures, then run:

```bash
sudo /opt/prabal-urja/scenario2/tools/apply_hardening.sh <AUTHORISED_SCADA_MASTER_IP>
```

This permits:

- loopback traffic required by the process simulator and operator console;
- the approved remote master;
- no other remote Modbus clients.

Verify the rule:

```bash
sudo nft list table inet prabal_s02_hardening
```

Do not block all traffic to the host or stop OpenPLC unless a safety authority explicitly directs it. Broad shutdown would remove visibility and legitimate control.

### 8.3 Emergency source block alternative

When the authorised master cannot yet be confirmed, temporarily block only the identified hostile source:

```bash
sudo nft add table inet prabal_s02_incident
sudo nft 'add chain inet prabal_s02_incident input { type filter hook input priority -6; policy accept; }'
sudo nft add rule inet prabal_s02_incident input ip saddr <ATTACKER_IP> tcp dport 502 drop
```

Replace this temporary rule with the positive allowlist as soon as possible.

## 9. Recovery

Restore the approved Unit-2 command block locally:

```bash
sudo /opt/prabal-urja/scenario2/venv/bin/python \
  /opt/prabal-urja/scenario2/tools/operator_restore.py \
  --host 127.0.0.1 --port 502 | jq
```

Observe the process returning safely rather than forcing an immediate service restart:

```bash
watch -n 3 'curl -s http://127.0.0.1:8091/health | jq'
```

Recovery criteria:

- setpoint is 650 MW;
- actual generation trends toward 650 MW;
- governor mode is automatic;
- maintenance override is disabled;
- cooling demand is 100%;
- grid risk returns to 0;
- operator console and Modbus telemetry remain available.

## 10. Validation after containment

```bash
sudo ./validate.sh
```

Test locally:

```bash
curl -fsS http://127.0.0.1:8090/api/health | jq
curl -fsS http://127.0.0.1:8091/health | jq
```

From an unauthorised test host, TCP 502 should no longer accept Modbus requests. From the authorised master, polling should continue.

## 11. Eradication and long-term hardening

Recommended controls:

- explicit Modbus master allowlisting at the zone firewall and host;
- separate control and engineering paths;
- command-source and function-code monitoring;
- alerts for FC06/FC16 to critical registers;
- operational validation of dispatch setpoints and rate of change;
- authenticated jump-host access for engineering work;
- baseline hash monitoring for PLC programs;
- documented command-sequence ownership;
- redundant field/process validation rather than relying only on HMI alarms.

Where supported by the production architecture, place legacy unauthenticated protocols behind authenticated gateways instead of exposing them across broad routed zones.

## 12. Reporting

Complete:

- `Reports/INREP.md` for initial notification;
- `Reports/SITREP.md` for investigation and response updates;
- `Reports/Red-Report.md` for adversary findings and evidence.

Include screenshots of:

- live operator trend;
- anomalous command register values;
- packet source and Modbus function code;
- historian correlation;
- containment rule;
- restored process state.

## 13. Scenario 3 handoff

The operator environment identifies `PU-RB-RTU-07` as the River Bend feeder and bus-tie switching dependency. Blue should record this as a downstream asset at risk and notify the substation operations team. Scenario 3 is not deployed by this package.
