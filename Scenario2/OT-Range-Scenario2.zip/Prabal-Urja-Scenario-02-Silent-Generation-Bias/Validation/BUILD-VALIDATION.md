# Build Validation Record

## Package-level checks

- Required deliverables are present.
- Setup and reset scripts use strict Bash error handling.
- Ubuntu version is checked before installation.
- No Docker or container runtime is used.
- No host IP address is hardcoded by installation logic.
- Setup TTP command prints only `Setup Successfully`.
- Setup TTP links to the correct Service Availability TTP ID.
- Service availability requires systemd, socket and protocol/application probes.
- Python files pass compilation checks.
- Shell files pass `bash -n`.
- YAML files parse successfully.
- JavaScript passes syntax validation where Node.js is available.
- Internal checksums are produced before archiving.


## Functional tests completed during package construction

- Dependency-free Modbus/TCP client validated with FC03, FC06 and FC16 request/response handling.
- Register probe, targeted write utility and operator restoration utility validated against a protocol test endpoint.
- Operator-console health, live-state, history and intertie APIs validated with live Modbus data.
- Actual pandapower 3.3.2 power-flow model executed at baseline and biased dispatch levels.
- Baseline calibration confirmed at approximately 87.56% generator-transformer loading and 72.02% corridor loading at 650 MW.
- A 720–725 MW bias produced approximately 98% generator-transformer loading and more than 92% corridor loading.
- Scenario state progressed from `NORMAL_DISPATCH` to `GENERATION_BIAS_CONFIRMED` and returned to normal after restoration.
- OpenPLC database configuration helper validated against the expected Programs and Settings schema.

## Runtime checks performed by validate.sh

- OpenPLC systemd service active.
- pandapower simulator systemd service active.
- operator console systemd service active.
- Modbus packet capture supporting service active.
- baseline firewall systemd service active.
- TCP 502, 8080, 8443, 8090 and 8091 listening as designed.
- Modbus FC03 read from the real OpenPLC holding-register map.
- setpoint within PLC engineering bounds.
- pandapower health endpoint reports a live Modbus connection and process output.
- operator console reports a live Modbus connection.
- local OpenPLC engineering web interface responds.

## Environment limitation

The artifact build environment is not an Ubuntu 22.04/24.04 systemd VM. The pandapower process model and all package-owned Modbus/HMI components were executed and validated, but a complete native OpenPLC installation and systemd boot test could not be performed in this environment because the pinned GitHub source was not reachable from the build container. `setup.sh` fails closed on any OpenPLC installation, database, compile, listener or functional-probe error, and `validate.sh` performs the complete acceptance test on the target Ubuntu VM.
