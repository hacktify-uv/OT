#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
ENV_FILE=/etc/prabal-urja/scenario2.env
[[ -r "$ENV_FILE" ]] || { echo "VALIDATION:FAIL missing=$ENV_FILE"; exit 1; }
# shellcheck disable=SC1091
source "$ENV_FILE"
FAIL=0
check(){ local name="$1"; shift; if "$@"; then echo "[PASS] $name"; else echo "[FAIL] $name"; FAIL=1; fi; }
check_openplc_setting(){
  local key="$1" expected="$2" actual
  actual="$(sqlite3 /opt/prabal-urja/scenario2/openplc/webserver/openplc.db "SELECT Value FROM Settings WHERE Key='$key';")"
  [[ "$actual" == "$expected" ]]
}
check "OpenPLC systemd service" systemctl is-active --quiet prabal-openplc.service
check "pandapower simulator systemd service" systemctl is-active --quiet prabal-grid-simulator.service
check "operator console systemd service" systemctl is-active --quiet prabal-operator-console.service
check "Modbus capture systemd service" systemctl is-active --quiet prabal-modbus-capture.service
check "baseline firewall systemd service" systemctl is-active --quiet prabal-s02-firewall.service
check "Modbus/TCP listening port $MODBUS_PORT" bash -c "ss -ltn | grep -Eq ':${MODBUS_PORT}[[:space:]]'"
check "OpenPLC localhost web port $OPENPLC_WEB_PORT" bash -c "ss -ltn | grep -Eq ':${OPENPLC_WEB_PORT}[[:space:]]'"
check "OpenPLC localhost REST port $OPENPLC_REST_PORT" bash -c "ss -ltn | grep -Eq ':${OPENPLC_REST_PORT}[[:space:]]'"
check "operator console port $HMI_PORT" bash -c "ss -ltn | grep -Eq ':${HMI_PORT}[[:space:]]'"
check "grid health port $GRID_HEALTH_PORT" bash -c "ss -ltn | grep -Eq ':${GRID_HEALTH_PORT}[[:space:]]'"
check "OpenPLC selected program" bash -c "grep -Fxq prabal_unit2.st /opt/prabal-urja/scenario2/openplc/webserver/active_program"
check "OpenPLC automatic RUN mode" check_openplc_setting Start_run_mode true
check "OpenPLC Modbus configuration" check_openplc_setting Modbus_port "$MODBUS_PORT"
check "protocol-aware Modbus read" /opt/prabal-urja/scenario2/venv/bin/python /opt/prabal-urja/scenario2/tools/modbus_probe.py --host 127.0.0.1 --port "$MODBUS_PORT" --address 1024 --count 24
check "pandapower functional state" bash -c "curl -fsS --connect-timeout 3 --max-time 6 http://127.0.0.1:${GRID_HEALTH_PORT}/health | jq -e '.status == \"up\" and .modbus_connected == true and (.actual_generation_mw >= 500) and (.actual_generation_mw <= 750)' >/dev/null"
check "operator console functional health" bash -c "curl -fsS --connect-timeout 3 --max-time 6 http://127.0.0.1:${HMI_PORT}/api/health | jq -e '.status == \"up\" and .modbus_connected == true' >/dev/null"
check "operator console presentation" bash -c "curl -fsS --connect-timeout 3 --max-time 6 http://127.0.0.1:${HMI_PORT}/ | grep -Fq 'Prabal Urja'"
check "OpenPLC web interface responds locally" bash -c "code=\$(curl -sS -o /dev/null -w '%{http_code}' --connect-timeout 3 --max-time 6 http://127.0.0.1:${OPENPLC_WEB_PORT}/ || true); [[ \$code == 200 || \$code == 302 || \$code == 401 || \$code == 403 ]]"
if (( FAIL != 0 )); then echo "VALIDATION:FAIL"; exit 1; fi
echo "VALIDATION:PASS"
