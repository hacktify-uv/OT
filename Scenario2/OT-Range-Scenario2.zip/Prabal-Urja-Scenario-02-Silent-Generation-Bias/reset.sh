#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
PRESERVE=0
if [[ "${1:-}" == "--preserve-evidence" ]]; then PRESERVE=1; elif [[ $# -gt 0 ]]; then echo "Usage: sudo ./reset.sh [--preserve-evidence]" >&2; exit 2; fi
if [[ $EUID -ne 0 ]]; then echo "Run as root." >&2; exit 1; fi
ENV_FILE=/etc/prabal-urja/scenario2.env
[[ -r "$ENV_FILE" ]] || { echo "Scenario 2 is not installed." >&2; exit 1; }
# shellcheck disable=SC1091
source "$ENV_FILE"
if (( PRESERVE == 1 )); then /opt/prabal-urja/scenario2/tools/collect_evidence.sh; fi
systemctl stop prabal-operator-console.service prabal-grid-simulator.service prabal-modbus-capture.service
systemctl disable --now prabal-s02-hardening.service 2>/dev/null || true
nft delete table inet prabal_s02_hardening 2>/dev/null || true
rm -f /etc/prabal-urja/scenario2-hardening.nft
sed -i 's/^AUTHORIZED_MODBUS_MASTER=.*/AUTHORIZED_MODBUS_MASTER=/' "$ENV_FILE"
rm -f /var/log/prabal-urja-s02/pcap/*.pcap* /var/log/prabal-urja-s02/process-historian.csv /var/log/prabal-urja-s02/process-events.jsonl /var/log/prabal-urja-s02/operator-access.log 2>/dev/null || true
rm -f /var/lib/prabal-urja-s02/operator-historian.db /var/lib/prabal-urja-s02/latest-state.json 2>/dev/null || true
systemctl restart prabal-openplc.service
for _ in {1..60}; do ss -ltn | grep -Eq ":${MODBUS_PORT}[[:space:]]" && break; sleep 1; done
systemctl start prabal-grid-simulator.service
for _ in {1..60}; do curl -fsS "http://127.0.0.1:${GRID_HEALTH_PORT}/health" 2>/dev/null | jq -e '.modbus_connected == true' >/dev/null && break; sleep 1; done
/opt/prabal-urja/scenario2/venv/bin/python /opt/prabal-urja/scenario2/tools/operator_restore.py --host 127.0.0.1 --port "$MODBUS_PORT"
systemctl start prabal-operator-console.service prabal-modbus-capture.service
sleep 5
"$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/validate.sh"
echo "RESET_COMPLETE scenario=Prabal-Urja-S02 vulnerable_state=restored"
