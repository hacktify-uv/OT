# Prabal Urja Scenario 2 — Silent Generation Bias

## Purpose

This package deploys the second stage of the interconnected Prabal Urja power-sector Red-vs-Blue campaign. It uses:

- the real OpenPLC Runtime as the soft PLC;
- real Modbus/TCP communications on the standard TCP service port;
- an IEC 61131-3 Structured Text governor program;
- pandapower for electrical process calculations;
- a native operator trend console;
- rolling packet capture and historian evidence.

The unsafe condition is a realistic control-network weakness: the Modbus/TCP service accepts valid write commands from any reachable client. There is no authenticated master relationship and the controller validates only broad engineering limits, not operational authorisation or source identity.

## Supported systems

- Ubuntu Server 22.04 LTS Jammy
- Ubuntu Server 24.04 LTS Noble
- x86_64 cloud/server image
- systemd-based cloud image
- Internet access during installation unless OpenPLC source and Python wheels are pre-staged

Docker is not used.

## Recommended VM size

- 4 vCPU
- 8 GB RAM
- 30 GB disk
- one isolated exercise interface

## Installation

```bash
cd Prabal-Urja-Scenario-02-Silent-Generation-Bias
sudo bash deps.sh
sudo bash setup.sh
```

Optional variables:

```bash
sudo PRABAL_HMI_PORT=8090 \
     PRABAL_GRID_HEALTH_PORT=8091 \
     PRABAL_CAPTURE_INTERFACE=any \
     bash setup.sh
```

The installer does not assign or hardcode a host IP. Addressing is controlled by the infrastructure layer. Documentation uses the requested isolated `195.0.0.0/8` exercise plan.

## Installed services

| Service | Function | Default port |
|---|---|---:|
| `prabal-openplc.service` | OpenPLC soft PLC and Modbus/TCP server | TCP 502 |
| OpenPLC local engineering interface | Restricted to loopback | TCP 8080 |
| OpenPLC local REST interface | Restricted to loopback | TCP 8443 |
| `prabal-grid-simulator.service` | pandapower process simulation and health API | TCP 8091 |
| `prabal-operator-console.service` | Unit-2 operator console and historian | TCP 8090 |
| `prabal-modbus-capture.service` | Rolling Modbus packet capture | N/A |
| `prabal-s02-firewall.service` | Restricts OpenPLC engineering UI to localhost | N/A |
| `prabal-s02-hardening.service` | Optional persistent authorised-master allowlist after Blue containment | N/A |

## Important paths

```text
/opt/prabal-urja/scenario2/                  application and OpenPLC runtime
/etc/prabal-urja/scenario2.env               runtime configuration
/var/log/prabal-urja-s02/process-historian.csv
/var/log/prabal-urja-s02/process-events.jsonl
/var/log/prabal-urja-s02/operator-access.log
/var/log/prabal-urja-s02/pcap/               rolling Modbus captures
/var/lib/prabal-urja-s02/latest-state.json
```

## Validation

```bash
sudo ./validate.sh
```

Validation requires all three service-health vectors:

1. systemd services must be active;
2. expected ports must be listening;
3. functional probes must successfully read real Modbus registers and live process state.

## Reset

```bash
sudo ./reset.sh
```

Preserve evidence first:

```bash
sudo ./reset.sh --preserve-evidence
```

## Evidence collection

```bash
sudo /opt/prabal-urja/scenario2/tools/collect_evidence.sh
```

## Blue Team hardening helper

After identifying the authorised SCADA master address:

```bash
sudo /opt/prabal-urja/scenario2/tools/apply_hardening.sh <AUTHORISED_MASTER_IP>
```

This installs and enables a persistent, narrowly scoped Modbus allowlist while preserving local process simulation and operator-console polling. `reset.sh` removes the allowlist and restores the vulnerable exercise state.

## Campaign boundary

Scenario 1 provides the asset identity `PU-GOV-PLC-02` and indicates that the downstream governor uses Modbus/TCP. Scenario 2 introduces the River Bend switching dependency `PU-RB-RTU-07`, but does not deploy Scenario 3 or any DNP3 service.


## OpenPLC startup assurance

The installer registers `prabal_unit2.st` in the native OpenPLC database, selects it as the active program, sets `Start_run_mode=true`, enables Modbus/TCP on port 502, and disables the unused DNP3, EtherNet/IP and S7 listeners. The OpenPLC engineering HTTP and REST interfaces remain locally available for administration but are blocked from non-loopback interfaces by the scenario firewall.
