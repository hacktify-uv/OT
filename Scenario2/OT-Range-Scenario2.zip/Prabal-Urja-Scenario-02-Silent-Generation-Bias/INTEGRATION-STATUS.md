# Prabal Urja Scenario 02: source-integrity review

**STATUS: NOT END-TO-END CERTIFIED.**

Original source files are included from the user-supplied archive (with generated caches omitted where necessary).

## Confirmed review finding

Existing OpenPLC and Modbus code are retained. The next RTU must be discovered from a deployed engineering inventory; creating a standalone clue does not prove asset connectivity.

## Handoff requirement

Next asset: `PU-RB-RTU-07` with required service port `20001`. An IP address must be supplied through operator configuration, resolved by DNS or `/etc/hosts`, and tested from the actual Red Team subnet. The check **does not** grant credentials or prove an exploitable weakness.

## Mandatory demonstration

A clean Ubuntu deployment, real wire-level protocol exchange, true process transition, application audit, independent Blue Team observation, and tested containment/recovery. These requirements are NOT claimed satisfied by this source package.
