#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE=/var/log/prabal-urja-s02-setup.log
INSTALL_DIR=/opt/prabal-urja/scenario2
ENV_DIR=/etc/prabal-urja
ENV_FILE=$ENV_DIR/scenario2.env
LOG_DIR=/var/log/prabal-urja-s02
STATE_DIR=/var/lib/prabal-urja-s02
SERVICE_USER=prabalgrid
SERVICE_GROUP=prabalgrid
OPENPLC_REVISION="${PRABAL_OPENPLC_REVISION:-b5d4135}"
OPENPLC_WEB_PORT=8080
OPENPLC_REST_PORT=8443
MODBUS_PORT=502
HMI_PORT="${PRABAL_HMI_PORT:-8090}"
GRID_HEALTH_PORT="${PRABAL_GRID_HEALTH_PORT:-8091}"
CAPTURE_INTERFACE="${PRABAL_CAPTURE_INTERFACE:-any}"
SKIP_APT_UPDATE="${PRABAL_SKIP_APT_UPDATE:-0}"

on_error(){ local rc=$?; echo "[!] Setup failed at line ${BASH_LINENO[0]} with exit code $rc" >&2; echo "[!] Review $LOG_FILE" >&2; exit "$rc"; }
trap on_error ERR
if [[ $EUID -ne 0 ]]; then echo "Run setup.sh as root: sudo bash setup.sh" >&2; exit 1; fi
mkdir -p "$(dirname "$LOG_FILE")"; touch "$LOG_FILE"; chmod 0600 "$LOG_FILE"; exec > >(tee -a "$LOG_FILE") 2>&1

echo "[+] Prabal Urja Scenario 2 installation started at $(date -u --iso-8601=seconds)"
[[ -r /etc/os-release ]] || { echo "Missing /etc/os-release" >&2; exit 1; }
# shellcheck disable=SC1091
source /etc/os-release
if [[ "${ID:-}" != ubuntu ]] || [[ "${VERSION_ID:-}" != 22.04 && "${VERSION_ID:-}" != 24.04 ]]; then
  echo "[!] WARNING: This package officially supports Ubuntu 22.04 and 24.04 only." >&2
  echo "[!] Detected: ID=${ID:-unknown} VERSION_ID=${VERSION_ID:-unknown}" >&2
  echo "[!] Proceeding with installation anyway..." >&2
fi
for p in "$MODBUS_PORT" "$HMI_PORT" "$GRID_HEALTH_PORT" "$OPENPLC_WEB_PORT" "$OPENPLC_REST_PORT"; do
  [[ "$p" =~ ^[0-9]+$ ]] && (( p >= 1 && p <= 65535 )) || { echo "Invalid port: $p" >&2; exit 1; }
done
if [[ "$MODBUS_PORT" == "$HMI_PORT" || "$MODBUS_PORT" == "$GRID_HEALTH_PORT" || "$HMI_PORT" == "$GRID_HEALTH_PORT" ]]; then echo "Service ports must be unique." >&2; exit 1; fi
for p in "$MODBUS_PORT" "$HMI_PORT" "$GRID_HEALTH_PORT" "$OPENPLC_WEB_PORT" "$OPENPLC_REST_PORT"; do
  if ss -ltnH 2>/dev/null | awk '{print $4}' | grep -Eq "(^|:)$p$"; then
    case "$p" in
      "$OPENPLC_WEB_PORT") systemctl is-active --quiet prabal-openplc.service 2>/dev/null || { echo "Port $p is already occupied." >&2; exit 1; } ;;
      "$MODBUS_PORT") systemctl is-active --quiet prabal-openplc.service 2>/dev/null || { echo "Port $p is already occupied." >&2; exit 1; } ;;
      "$HMI_PORT") systemctl is-active --quiet prabal-operator-console.service 2>/dev/null || { echo "Port $p is already occupied." >&2; exit 1; } ;;
      "$GRID_HEALTH_PORT") systemctl is-active --quiet prabal-grid-simulator.service 2>/dev/null || { echo "Port $p is already occupied." >&2; exit 1; } ;;
      "$OPENPLC_REST_PORT") systemctl is-active --quiet prabal-openplc.service 2>/dev/null || { echo "Port $p is already occupied." >&2; exit 1; } ;;
    esac
  fi
done

PRABAL_SKIP_APT_UPDATE="$SKIP_APT_UPDATE" "$SCRIPT_DIR/deps.sh"
if ! getent group "$SERVICE_GROUP" >/dev/null; then groupadd --system "$SERVICE_GROUP"; fi
if ! id "$SERVICE_USER" >/dev/null 2>&1; then useradd --system --gid "$SERVICE_GROUP" --home-dir "$INSTALL_DIR" --shell /usr/sbin/nologin "$SERVICE_USER"; fi

systemctl disable --now openplc.service 2>/dev/null || true
systemctl disable --now prabal-s02-hardening.service 2>/dev/null || true
systemctl stop prabal-operator-console.service prabal-grid-simulator.service prabal-modbus-capture.service prabal-openplc.service prabal-s02-firewall.service 2>/dev/null || true
rm -f /etc/prabal-urja/scenario2-hardening.nft
rm -f /lib/systemd/system/openplc.service /etc/systemd/system/openplc.service

rm -rf "$INSTALL_DIR"
install -d -m 0755 -o root -g root "$INSTALL_DIR" "$INSTALL_DIR/openplc" "$INSTALL_DIR/process" "$INSTALL_DIR/hmi" "$INSTALL_DIR/tools"
install -d -m 0755 -o root -g root "$ENV_DIR"
install -d -m 0750 -o "$SERVICE_USER" -g "$SERVICE_GROUP" "$LOG_DIR" "$STATE_DIR"
install -d -m 0750 -o root -g "$SERVICE_GROUP" "$LOG_DIR/pcap"

SOURCE_CACHE="$SCRIPT_DIR/Challenge-Files/vendor/OpenPLC_v3-${OPENPLC_REVISION}.tar.gz"
TMP_ARCHIVE=""
if [[ -f "$SOURCE_CACHE" ]]; then
  echo "[+] Using packaged OpenPLC source cache."
  [[ ! -f "$SOURCE_CACHE.sha256" ]] || (cd "$(dirname "$SOURCE_CACHE")" && sha256sum -c "$(basename "$SOURCE_CACHE").sha256")
  tar -xzf "$SOURCE_CACHE" --strip-components=1 -C "$INSTALL_DIR/openplc"
else
  echo "[+] Cloning official OpenPLC Runtime repository and recursively fetching submodules..."
  git clone https://github.com/thiagoralves/OpenPLC_v3.git "$INSTALL_DIR/openplc"
  (cd "$INSTALL_DIR/openplc" && git checkout "$OPENPLC_REVISION" && git submodule update --init --recursive)
fi

"$SCRIPT_DIR/Challenge-Files/openplc/patches/patch_openplc.sh" "$INSTALL_DIR/openplc"
cd "$INSTALL_DIR/openplc"
bash ./background_installer.sh linux
systemctl disable --now openplc.service 2>/dev/null || true
rm -f /lib/systemd/system/openplc.service /etc/systemd/system/openplc.service

install -o root -g root -m 0644 "$SCRIPT_DIR/Challenge-Files/openplc/programs/prabal_unit2.st" "$INSTALL_DIR/openplc/webserver/st_files/prabal_unit2.st"
python3 "$SCRIPT_DIR/Challenge-Files/openplc/patches/configure_openplc_db.py" \
  --database "$INSTALL_DIR/openplc/webserver/openplc.db" \
  --program-file prabal_unit2.st \
  --modbus-port "$MODBUS_PORT"
cd "$INSTALL_DIR/openplc/webserver"
./scripts/compile_program.sh prabal_unit2.st
grep -Fxq prabal_unit2.st active_program || { echo "OpenPLC active program was not selected." >&2; exit 1; }
sqlite3 openplc.db "SELECT Value FROM Settings WHERE Key='Start_run_mode';" | grep -Fxq true || { echo "OpenPLC auto-RUN is not enabled." >&2; exit 1; }
sqlite3 openplc.db "SELECT Value FROM Settings WHERE Key='Modbus_port';" | grep -Fxq "$MODBUS_PORT" || { echo "OpenPLC Modbus port is not configured." >&2; exit 1; }
[[ -x "$INSTALL_DIR/openplc/start_openplc.sh" ]] || { echo "OpenPLC start script was not generated." >&2; exit 1; }

cp -a "$SCRIPT_DIR/Challenge-Files/process/." "$INSTALL_DIR/process/"
cp -a "$SCRIPT_DIR/Challenge-Files/hmi/." "$INSTALL_DIR/hmi/"
cp -a "$SCRIPT_DIR/Challenge-Files/tools/." "$INSTALL_DIR/tools/"
find "$INSTALL_DIR/process" "$INSTALL_DIR/hmi" "$INSTALL_DIR/tools" -type f -name '*.py' -exec chmod 0755 {} +
find "$INSTALL_DIR/tools" -type f -name '*.sh' -exec chmod 0755 {} +

python3 -m venv "$INSTALL_DIR/venv"
"$INSTALL_DIR/venv/bin/python" -m pip install --upgrade pip setuptools wheel
WHEELHOUSE="$SCRIPT_DIR/Challenge-Files/wheelhouse"
if compgen -G "$WHEELHOUSE/*.whl" >/dev/null; then
  "$INSTALL_DIR/venv/bin/pip" install --no-index --find-links "$WHEELHOUSE" -r "$INSTALL_DIR/process/requirements.txt"
else
  "$INSTALL_DIR/venv/bin/pip" install --no-cache-dir -r "$INSTALL_DIR/process/requirements.txt"
fi

cat > "$ENV_FILE" <<ENVEOF
# Prabal Urja Scenario 2 runtime configuration
MODBUS_HOST=127.0.0.1
MODBUS_PORT=$MODBUS_PORT
MODBUS_UNIT_ID=1
OPENPLC_WEB_PORT=$OPENPLC_WEB_PORT
OPENPLC_REST_PORT=$OPENPLC_REST_PORT
HMI_PORT=$HMI_PORT
GRID_HEALTH_PORT=$GRID_HEALTH_PORT
CAPTURE_INTERFACE=$CAPTURE_INTERFACE
S02_LOG_DIR=$LOG_DIR
S02_STATE_DIR=$STATE_DIR
HMI_DB_PATH=$STATE_DIR/operator-historian.db
HMI_ACCESS_LOG=$LOG_DIR/operator-access.log
AUTHORIZED_MODBUS_MASTER=
ENVEOF
chmod 0640 "$ENV_FILE"; chown root:"$SERVICE_GROUP" "$ENV_FILE"

cat > "$ENV_DIR/scenario2-baseline.nft" <<NFT
table inet prabal_s02_baseline {
  chain input {
    type filter hook input priority -10; policy accept;
    iifname != "lo" tcp dport { $OPENPLC_WEB_PORT, $OPENPLC_REST_PORT } drop
  }
}
NFT
chmod 0644 "$ENV_DIR/scenario2-baseline.nft"

chown -R root:root "$INSTALL_DIR/openplc" "$INSTALL_DIR/tools" "$INSTALL_DIR/venv"
chown -R "$SERVICE_USER":"$SERVICE_GROUP" "$INSTALL_DIR/process" "$INSTALL_DIR/hmi" "$LOG_DIR" "$STATE_DIR"
chmod -R go-w "$INSTALL_DIR"
chmod 0750 "$LOG_DIR" "$STATE_DIR"; chmod 0750 "$LOG_DIR/pcap"

for svc in prabal-openplc.service prabal-grid-simulator.service prabal-operator-console.service prabal-modbus-capture.service prabal-s02-firewall.service prabal-s02-hardening.service; do
  install -o root -g root -m 0644 "$SCRIPT_DIR/Challenge-Files/systemd/$svc" "/etc/systemd/system/$svc"
done
systemctl daemon-reload
systemctl enable --now prabal-s02-firewall.service
systemctl enable --now prabal-openplc.service
for _ in {1..90}; do
  if ss -ltn | grep -Eq ":${MODBUS_PORT}[[:space:]]" && ss -ltn | grep -Eq ":${OPENPLC_WEB_PORT}[[:space:]]" && ss -ltn | grep -Eq ":${OPENPLC_REST_PORT}[[:space:]]"; then break; fi
  sleep 1
done
if ! ss -ltn | grep -Eq ":${MODBUS_PORT}[[:space:]]" || ! ss -ltn | grep -Eq ":${OPENPLC_WEB_PORT}[[:space:]]" || ! ss -ltn | grep -Eq ":${OPENPLC_REST_PORT}[[:space:]]"; then
  echo "[!] OpenPLC did not expose all required listeners." >&2
  systemctl --no-pager --full status prabal-openplc.service || true
  journalctl -u prabal-openplc.service -n 120 --no-pager || true
  exit 1
fi
/opt/prabal-urja/scenario2/openplc/.venv/bin/python3 --version >/dev/null
"$INSTALL_DIR/venv/bin/python" "$INSTALL_DIR/tools/operator_restore.py" --port "$MODBUS_PORT"
systemctl enable --now prabal-grid-simulator.service
for _ in {1..60}; do curl -fsS "http://127.0.0.1:${GRID_HEALTH_PORT}/health" 2>/dev/null | jq -e '.modbus_connected == true' >/dev/null && break; sleep 1; done
systemctl enable --now prabal-operator-console.service prabal-modbus-capture.service
for _ in {1..60}; do curl -fsS "http://127.0.0.1:${HMI_PORT}/api/health" 2>/dev/null | jq -e '.modbus_connected == true' >/dev/null && break; sleep 1; done
"$SCRIPT_DIR/validate.sh"
PRIMARY_IP="$(ip route get 1.1.1.1 2>/dev/null | grep -oP 'src \K\S+' || hostname -I 2>/dev/null | awk '{print $1}' || echo '')"
echo
printf '[+] Unit-2 operator console: http://%s:%s/\n' "${PRIMARY_IP:-<TARGET_IP>}" "$HMI_PORT"
printf '[+] Modbus/TCP controller: %s:%s\n' "${PRIMARY_IP:-<TARGET_IP>}" "$MODBUS_PORT"
echo "[+] OpenPLC engineering web interface is restricted to localhost on port $OPENPLC_WEB_PORT."
if [[ -n "$PRIMARY_IP" && "$PRIMARY_IP" != 195.* ]]; then echo "[!] Assign the requested isolated 195.0.0.0/8 exercise address at the infrastructure layer."; fi
echo "[+] Scenario 2 setup completed successfully."
