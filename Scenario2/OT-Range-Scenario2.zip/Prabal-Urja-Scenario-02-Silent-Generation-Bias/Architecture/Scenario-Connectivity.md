# Scenario Connectivity

## Scenario 1 to Scenario 2

Scenario 1's OPC UA namespace contains the operational relationship between the Unit-2 integration gateway and governor asset `PU-GOV-PLC-02`. This is the campaign justification for Red moving from maintenance telemetry access into the Hydro Control Zone.

The connection is meaningful rather than cosmetic: the same Unit-2 referenced in Scenario 1 becomes the controlled physical process in Scenario 2.

## Scenario 2 to Scenario 3

As Unit-2 generation rises, the generator transformer and northern corridor lose operating margin. The Scenario 2 operator console identifies River Bend asset `PU-RB-RTU-07` as the remote feeder and bus-tie switching dependency used during corridor stress.

Scenario 3 will therefore involve remote switching decisions that can redistribute the already stressed power flow. Scenario 2 does not deploy a DNP3 outstation or implement Scenario 3 in advance.
