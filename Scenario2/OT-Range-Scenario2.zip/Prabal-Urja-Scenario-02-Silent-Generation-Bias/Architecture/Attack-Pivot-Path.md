# Attack Pivot Path

## Entry from Scenario 1

The earlier OPC UA investigation exposes legitimate engineering metadata identifying:

- downstream asset: `PU-GOV-PLC-02`;
- function: Unit-2 governor and generator-transformer auxiliary control;
- protocol: Modbus/TCP;
- zone: Hydro Control Zone.

No Scenario 2 credentials or register addresses are supplied to Red participants.

## Scenario 2 progression

```text
Scenario 1 engineering metadata
        |
        v
Discover PU-GOV-PLC-02 service exposure
        |
        v
Identify OpenPLC-style Modbus memory region
        |
        v
Distinguish command registers from changing process feedback
        |
        v
Apply slow generation-setpoint bias
        |
        v
Observe transformer and corridor stress
        |
        v
Discover River Bend switching dependency PU-RB-RTU-07
```

## Defensive correlation

Blue must combine:

- Modbus packet source and function codes;
- process historian changes;
- operator dispatch context;
- command sequence values;
- actual transformer and corridor response.
