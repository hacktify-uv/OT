# Prabal Urja Interconnected Range — Overall Network

The addresses below are architectural examples only. Challenge code does not hardcode them.

```text
                                  RED TEAM ENCLAVE
                                  195.10.10.0/24
                                           |
                                  Range Router / Firewall
                                           |
                     +---------------------+---------------------+
                     |                                           |
             OT ACCESS / VENDOR DMZ                         BLUE SOC ZONE
                195.20.10.0/24                            195.70.10.0/24
                     |                                           |
       S01 OPC UA Maintenance Gateway                  SOC / packet analysis
       Example: 195.20.10.21                            Example: 195.70.10.10
                     |
                     | Discovered asset relationship
                     v
              HYDRO CONTROL ZONE
                195.40.10.0/24
                     |
       S02 PU-GOV-PLC-02 — OpenPLC / Modbus TCP
       Operator console + pandapower process model
       Example: 195.40.10.22
                     |
                     | Northern-corridor operational dependency
                     v
       FUTURE S03 RIVER BEND SUBSTATION ZONE
                195.50.10.0/24
              PU-RB-RTU-07 — DNP3
```

## Pivot logic

1. Scenario 1 reveals the downstream controller asset identifier and protocol relationship.
2. Red reaches the Hydro Control Zone through the authorised exercise routing path.
3. Scenario 2 exposes no credentials because Modbus/TCP control is based on network reachability rather than authenticated identity.
4. Manipulation of Unit-2 generation stresses the northern corridor.
5. The resulting operational condition justifies investigation of the River Bend remote switching dependency in Scenario 3.
