# Scenario 2 Network Diagram

```text
                     Red Team workstation
                     195.10.10.0/24
                              |
                      Exercise routing path
                              |
                              v
                PU-GOV-PLC-02 / Scenario 2 VM
                Hydro Control Zone 195.40.10.0/24

      +----------------------+----------------------+---------------------+
      |                      |                      |                     |
 TCP 502                TCP 8090               TCP 8091            Local TCP 8080
 OpenPLC Runtime        Operator Console       Grid Health API      OpenPLC Engineering UI
 Modbus/TCP             Live trends            pandapower state     Loopback-restricted
      |                      |                      |
      +----------------------+----------------------+
                             |
                  Unit-2 / GT-2 / 220 kV corridor
                     electrical process model
```

## Trust problem

The baseline environment does not authenticate Modbus masters. Any routed host that can reach TCP 502 can submit valid Modbus control messages. The PLC enforces only broad engineering bounds.
