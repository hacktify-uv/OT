# OpenPLC v3 legacy revision migration candidate

This ZIP is based ONLY on the user's existing Scenario 2 no-firewall archive.
Reference archive files or scenario content were not imported.

Upstream OpenPLC Git commit: 68d46cf5bbe1be7316acac55b3f2f7751c0cf550
GitHub: https://github.com/thiagoralves/OpenPLC_v3

Scope: installation compatibility and version-dependent validation only. The
existing PLC program, Modbus register map, HMI, process simulator, challenge
TTPs, blue/red writeups, scoring, and service availability files are unchanged.
The existing no-firewall configuration is retained. Keep this intentionally
vulnerable setup inside an isolated and authorized exercise network.

Prerequisite: Python 2.7 and its pip module must already be available as
`python2.7 -m pip`. This version's original installer requires Python 2.7,
which is unavailable through default Ubuntu 22.04/24.04 repositories. The
setup script now fails safely BEFORE stopping or deleting an existing setup if
Python 2.7/pip is not provisioned.

Important: The original setup.sh continues to recreate /opt/prabal-urja/scenario2.
Back up the current installation before any successful migration attempt.
Do not replace the running installation without an exercise maintenance window.

On a host with prerequisites fulfilled:
    sudo bash setup.sh
    sudo bash validate.sh

Testing: Bash syntax, ZIP integrity and preservation of unchanged files were
checked OFFLINE. This archive has NOT passed an end-to-end Ubuntu installation,
PLC compile, fieldbus interoperability, or exploit test. It is a candidate, not
a validated drop-in replacement. If an upstream compiler or Python package
fails to install, preserve the setup log for a targeted follow-up repair.

Changes in this candidate:
- setup.sh: pins historical OpenPLC SHA, checks Python2 before destructive work,
  adapts old C++ editor source check and excludes the absent REST :8443 probe.
- patch_openplc_legacy.sh: adapts upstream installer package dependencies to
  avoid unpinned, unsupported Python2 wheels.
- configure_openplc_db.py: allows historically absent optional Settings keys.
- validate.sh: omits REST :8443 probe absent in the historical release.
- dependencies.lock and prepare-openplc.sh: record the historical pin.
