#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import math
import os
import signal
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pandapower as pp
from pandapower.auxiliary import LoadflowNotConverged

from modbus_client import ModbusError, ModbusTCPClient

RUNNING = True
LATEST_LOCK = threading.Lock()
LATEST: dict[str, object] = {
    "status": "starting",
    "asset": "PU-GOV-PLC-02",
    "last_update": None,
    "modbus_connected": False,
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def env_int(name: str, default: int) -> int:
    return int(os.environ.get(name, str(default)))


def build_network() -> tuple[object, int, int, int, int]:
    net = pp.create_empty_network(name="Prabal Urja Unit-2 and Northern Corridor")
    bus_unit = pp.create_bus(net, vn_kv=15.75, name="PU Unit-2 Generator Bus")
    bus_station = pp.create_bus(net, vn_kv=220.0, name="Prabal 220 kV Bus")
    bus_north = pp.create_bus(net, vn_kv=220.0, name="Northern Corridor Grid")
    pp.create_ext_grid(net, bus=bus_north, vm_pu=1.0, name="Regional Grid Equivalent")
    trafo = pp.create_transformer_from_parameters(
        net,
        hv_bus=bus_station,
        lv_bus=bus_unit,
        sn_mva=800.0,
        vn_hv_kv=220.0,
        vn_lv_kv=15.75,
        vk_percent=12.0,
        vkr_percent=0.35,
        pfe_kw=90.0,
        i0_percent=0.12,
        shift_degree=0.0,
        name="GT-2 15.75/220 kV Generator Transformer",
    )
    line = pp.create_line_from_parameters(
        net,
        from_bus=bus_station,
        to_bus=bus_north,
        length_km=86.0,
        r_ohm_per_km=0.042,
        x_ohm_per_km=0.31,
        c_nf_per_km=9.5,
        max_i_ka=0.95,
        name="Prabal-North 220 kV Corridor",
    )
    generator = pp.create_sgen(net, bus=bus_unit, p_mw=650.0, q_mvar=25.0, name="Unit-2 Generator")
    load = pp.create_load(net, bus=bus_station, p_mw=450.0, q_mvar=85.0, name="Prabal Auxiliary and Regional Load")
    return net, generator, trafo, line, load


class HealthHandler(BaseHTTPRequestHandler):
    server_version = "PrabalGridHealth/1.0"

    def log_message(self, fmt: str, *args: object) -> None:
        return

    def do_GET(self) -> None:  # noqa: N802
        if self.path not in ("/health", "/state"):
            self.send_response(404)
            self.end_headers()
            return
        with LATEST_LOCK:
            body = json.dumps(LATEST, sort_keys=True).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def start_health_server(port: int) -> ThreadingHTTPServer:
    server = ThreadingHTTPServer(("0.0.0.0", port), HealthHandler)
    thread = threading.Thread(target=server.serve_forever, name="grid-health", daemon=True)
    thread.start()
    return server


def append_csv(path: Path, row: dict[str, object], fieldnames: list[str]) -> None:
    new_file = not path.exists() or path.stat().st_size == 0
    with path.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        if new_file:
            writer.writeheader()
        writer.writerow(row)
        handle.flush()


def append_event(path: Path, event: dict[str, object]) -> None:
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, sort_keys=True) + "\n")
        handle.flush()


def main() -> int:
    global RUNNING
    host = os.environ.get("MODBUS_HOST", "127.0.0.1")
    port = env_int("MODBUS_PORT", 502)
    unit_id = env_int("MODBUS_UNIT_ID", 1)
    health_port = env_int("GRID_HEALTH_PORT", 8091)
    bias_confirm_seconds = float(os.environ.get("BIAS_CONFIRM_SECONDS", "20"))
    if not 1.0 <= bias_confirm_seconds <= 300.0:
        raise ValueError("BIAS_CONFIRM_SECONDS must be between 1 and 300")
    log_dir = Path(os.environ.get("S02_LOG_DIR", "/var/log/prabal-urja-s02"))
    state_dir = Path(os.environ.get("S02_STATE_DIR", "/var/lib/prabal-urja-s02"))
    if not log_dir.exists(): log_dir.mkdir(parents=True, exist_ok=True)
    if not state_dir.exists(): state_dir.mkdir(parents=True, exist_ok=True)
    historian_path = log_dir / "process-historian.csv"
    event_path = log_dir / "process-events.jsonl"
    latest_path = state_dir / "latest-state.json"

    def stop_handler(signum: int, frame: object) -> None:
        global RUNNING
        RUNNING = False

    signal.signal(signal.SIGTERM, stop_handler)
    signal.signal(signal.SIGINT, stop_handler)

    health = start_health_server(health_port)
    client = ModbusTCPClient(host=host, port=port, unit_id=unit_id, timeout=2.5)
    net, generator_idx, trafo_idx, line_idx, _load_idx = build_network()

    actual_mw = 650.0
    winding_temp_c = 72.0
    heartbeat = 0
    last_commands: tuple[int, ...] | None = None
    bias_started: float | None = None
    last_tick = time.monotonic()
    fields = [
        "timestamp", "setpoint_mw", "ramp_rate_mw_s", "governor_mode", "maintenance_override",
        "cooling_demand_pct", "command_sequence", "actual_generation_mw", "transformer_loading_pct",
        "corridor_loading_pct", "unit_bus_voltage_kv", "winding_temperature_c", "risk_state",
        "scenario_state", "modbus_connected"
    ]

    while RUNNING:
        tick = time.monotonic()
        elapsed = clamp(tick - last_tick, 0.1, 5.0)
        last_tick = tick
        timestamp = utc_now()
        try:
            commands = client.read_holding_registers(1024, 6)
            setpoint, ramp_tenths, governor_mode, maintenance_override, cooling_pct, sequence = commands
            if last_commands is None:
                last_commands = tuple(commands)
            elif tuple(commands) != last_commands:
                names = ["GeneratorSetpointMW", "RampRateTenthsMWPerSecond", "GovernorMode", "MaintenanceOverride", "CoolingDemandPercent", "CommandSequence"]
                changes = {
                    names[i]: {"previous": last_commands[i], "current": commands[i]}
                    for i in range(len(commands)) if commands[i] != last_commands[i]
                }
                append_event(event_path, {
                    "timestamp": timestamp,
                    "event_type": "PLC_COMMAND_REGISTER_CHANGE",
                    "asset": "PU-GOV-PLC-02",
                    "changes": changes,
                    "note": "Determine the Modbus client source from the accompanying packet capture."
                })
                last_commands = tuple(commands)

            ramp_mw_s = clamp(ramp_tenths / 10.0, 0.2, 5.0)
            if governor_mode == 0:
                target_mw = 500.0
            else:
                target_mw = float(setpoint)
            delta = clamp(target_mw - actual_mw, -ramp_mw_s * elapsed, ramp_mw_s * elapsed)
            actual_mw += delta

            net.sgen.at[generator_idx, "p_mw"] = actual_mw
            net.sgen.at[generator_idx, "q_mvar"] = 20.0 + max(0.0, actual_mw - 650.0) * 0.08
            pp.runpp(net, algorithm="nr", init="auto", calculate_voltage_angles=True, max_iteration=20, numba=False)

            transformer_loading = float(net.res_trafo.at[trafo_idx, "loading_percent"])
            corridor_loading = float(net.res_line.at[line_idx, "loading_percent"])
            unit_voltage_kv = float(net.res_bus.loc[net.sgen.at[generator_idx, "bus"], "vm_pu"]) * 15.75

            ambient = 31.0
            cooling_factor = clamp(cooling_pct / 100.0, 0.6, 1.0)
            target_temp = ambient + (transformer_loading / 100.0) ** 2 * (53.0 / cooling_factor)
            winding_temp_c += (target_temp - winding_temp_c) * min(1.0, elapsed / 45.0)

            if transformer_loading >= 98.0 or corridor_loading >= 98.0 or winding_temp_c >= 96.0:
                risk_state = 2
            elif transformer_loading >= 90.0 or corridor_loading >= 88.0 or winding_temp_c >= 88.0:
                risk_state = 1
            else:
                risk_state = 0

            if setpoint >= 720 and actual_mw >= 710 and (transformer_loading >= 88.0 or corridor_loading >= 88.0):
                if bias_started is None:
                    bias_started = tick
                scenario_state = "GENERATION_BIAS_CONFIRMED" if tick - bias_started >= bias_confirm_seconds else "GENERATION_BIAS_DEVELOPING"
            else:
                bias_started = None
                scenario_state = "NORMAL_DISPATCH"

            heartbeat = (heartbeat + 1) & 0xFFFF
            feedback = [
                int(round(actual_mw)),
                int(round(transformer_loading * 10.0)),
                int(round(corridor_loading * 10.0)),
                int(round(unit_voltage_kv * 100.0)),
                int(round(winding_temp_c * 10.0)),
                risk_state,
                sequence,
                heartbeat,
            ]
            client.write_multiple_registers(1040, feedback)

            state = {
                "status": "up",
                "asset": "PU-GOV-PLC-02",
                "last_update": timestamp,
                "modbus_connected": True,
                "setpoint_mw": setpoint,
                "ramp_rate_mw_s": round(ramp_mw_s, 2),
                "governor_mode": governor_mode,
                "maintenance_override": maintenance_override,
                "cooling_demand_pct": cooling_pct,
                "command_sequence": sequence,
                "actual_generation_mw": round(actual_mw, 2),
                "transformer_loading_pct": round(transformer_loading, 2),
                "corridor_loading_pct": round(corridor_loading, 2),
                "unit_bus_voltage_kv": round(unit_voltage_kv, 3),
                "winding_temperature_c": round(winding_temp_c, 2),
                "risk_state": risk_state,
                "scenario_state": scenario_state,
            }
            latest_path.write_text(json.dumps(state, indent=2, sort_keys=True), encoding="utf-8")
            row = {name: state.get(name) for name in fields}
            row["timestamp"] = timestamp
            append_csv(historian_path, row, fields)
            with LATEST_LOCK:
                LATEST.clear()
                LATEST.update(state)
        except (OSError, ModbusError, ValueError, LoadflowNotConverged) as exc:
            error_state = {
                "status": "degraded",
                "asset": "PU-GOV-PLC-02",
                "last_update": timestamp,
                "modbus_connected": False,
                "error": str(exc),
            }
            with LATEST_LOCK:
                LATEST.clear()
                LATEST.update(error_state)
            append_event(event_path, {"timestamp": timestamp, "event_type": "SIMULATOR_ERROR", "error": str(exc)})
        time.sleep(1.0)

    health.shutdown()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
