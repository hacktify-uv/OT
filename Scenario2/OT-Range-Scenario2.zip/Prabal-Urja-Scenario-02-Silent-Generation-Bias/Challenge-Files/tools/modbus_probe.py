#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "process"))
from modbus_client import ModbusTCPClient  # noqa: E402

def main() -> int:
    p=argparse.ArgumentParser()
    p.add_argument('--host',default='127.0.0.1');p.add_argument('--port',type=int,default=502)
    p.add_argument('--unit-id',type=int,default=1);p.add_argument('--timeout',type=float,default=3.0)
    p.add_argument('--address',type=int,default=1024);p.add_argument('--count',type=int,default=24)
    a=p.parse_args()
    c=ModbusTCPClient(a.host,a.port,a.unit_id,a.timeout)
    regs=c.read_holding_registers(a.address,a.count)
    result={"status":"up","host":a.host,"port":a.port,"unit_id":a.unit_id,"address":a.address,"count":a.count,"registers":regs}
    if a.address <= 1024 and a.address + a.count > 1024:
        setpoint=regs[1024-a.address]
        result["generator_setpoint_mw"]=setpoint
        if not 500 <= setpoint <= 750:
            raise RuntimeError(f"setpoint outside engineering bounds: {setpoint}")
    print(json.dumps(result,sort_keys=True))
    return 0
if __name__=='__main__':
    raise SystemExit(main())
