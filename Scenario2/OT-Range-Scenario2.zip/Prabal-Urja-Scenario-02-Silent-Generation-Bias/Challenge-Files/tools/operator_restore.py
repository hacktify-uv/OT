#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "process"))
from modbus_client import ModbusTCPClient  # noqa: E402

def main() -> int:
    p=argparse.ArgumentParser(description='Restore Prabal Urja Unit-2 governor baseline')
    p.add_argument('--host',default='127.0.0.1');p.add_argument('--port',type=int,default=502);p.add_argument('--unit-id',type=int,default=1)
    a=p.parse_args();c=ModbusTCPClient(a.host,a.port,a.unit_id,3.0)
    before=c.read_holding_registers(1024,6)
    sequence=(before[5]+1)&0xffff
    desired=[650,10,1,0,100,sequence]
    c.write_multiple_registers(1024,desired)
    time.sleep(1)
    after=c.read_holding_registers(1024,6)
    if after!=desired: raise RuntimeError(f'verification failed expected={desired} actual={after}')
    print(json.dumps({"status":"restored","before":before,"after":after},sort_keys=True));return 0
if __name__=='__main__': raise SystemExit(main())
