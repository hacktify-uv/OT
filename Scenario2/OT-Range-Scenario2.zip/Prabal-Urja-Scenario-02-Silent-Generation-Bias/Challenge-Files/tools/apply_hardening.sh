#!/usr/bin/env bash
set -Eeuo pipefail
if [[ $EUID -ne 0 ]]; then echo "Run as root." >&2; exit 1; fi
AUTHORIZED="${1:-}"
if [[ -z "$AUTHORIZED" ]]; then echo "Usage: sudo apply_hardening.sh <authorised-modbus-master-ip>" >&2; exit 2; fi
python3 - "$AUTHORIZED" <<'PY'
import ipaddress,sys
ipaddress.IPv4Address(sys.argv[1])
PY
ENV=/etc/prabal-urja/scenario2.env
RULES=/etc/prabal-urja/scenario2-hardening.nft
[[ -r "$ENV" ]] || { echo "Missing $ENV" >&2; exit 1; }
# shellcheck disable=SC1091
source "$ENV"
cat > "$RULES" <<NFT
table inet prabal_s02_hardening {
  chain input {
    type filter hook input priority -5; policy accept;
    iifname "lo" tcp dport $MODBUS_PORT accept
    ip saddr $AUTHORIZED tcp dport $MODBUS_PORT accept
    tcp dport $MODBUS_PORT drop
  }
}
NFT
chmod 0644 "$RULES"
if grep -q '^AUTHORIZED_MODBUS_MASTER=' "$ENV"; then
  sed -i "s/^AUTHORIZED_MODBUS_MASTER=.*/AUTHORIZED_MODBUS_MASTER=$AUTHORIZED/" "$ENV"
else
  echo "AUTHORIZED_MODBUS_MASTER=$AUTHORIZED" >> "$ENV"
fi
chmod 0640 "$ENV"
systemctl daemon-reload
systemctl enable --now prabal-s02-hardening.service
nft list table inet prabal_s02_hardening >/dev/null
printf 'HARDENING_APPLIED authorised_modbus_master=%s port=%s persistent=yes\n' "$AUTHORIZED" "$MODBUS_PORT"
