#!/usr/bin/env bash
set -Eeuo pipefail
[[ -r /etc/prabal-urja/scenario2.env ]] && source /etc/prabal-urja/scenario2.env
OUT="${1:-/var/tmp/prabal-s02-evidence-$(date -u +%Y%m%dT%H%M%SZ)}"
mkdir -p "$OUT"
chmod 0700 "$OUT"
cp -a /var/log/prabal-urja-s02 "$OUT/logs" 2>/dev/null || true
cp -a /var/lib/prabal-urja-s02/latest-state.json "$OUT/" 2>/dev/null || true
journalctl -u prabal-openplc.service -u prabal-grid-simulator.service -u prabal-operator-console.service -u prabal-modbus-capture.service --no-pager > "$OUT/systemd-journal.txt" 2>&1 || true
ss -ltnp > "$OUT/listening-sockets.txt" 2>&1 || true
systemctl status prabal-openplc.service prabal-grid-simulator.service prabal-operator-console.service prabal-modbus-capture.service --no-pager > "$OUT/service-status.txt" 2>&1 || true
/opt/prabal-urja/scenario2/venv/bin/python /opt/prabal-urja/scenario2/tools/modbus_probe.py --host 127.0.0.1 --port "${MODBUS_PORT:-502}" --address 1024 --count 24 > "$OUT/register-snapshot.json" 2>&1 || true
nft list ruleset > "$OUT/nftables-ruleset.txt" 2>&1 || true
find "$OUT" -type f ! -name SHA256SUMS -print0 \
  | sort -z \
  | xargs -0 -r sha256sum > "$OUT/SHA256SUMS"
tar -C "$(dirname "$OUT")" -czf "$OUT.tar.gz" "$(basename "$OUT")"
echo "$OUT.tar.gz"
