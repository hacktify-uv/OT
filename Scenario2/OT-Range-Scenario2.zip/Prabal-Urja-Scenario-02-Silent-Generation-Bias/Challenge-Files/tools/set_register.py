#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "process"))
from modbus_client import ModbusTCPClient  # noqa: E402

def main() -> int:
    p=argparse.ArgumentParser(description='Authorised Modbus register maintenance utility')
    p.add_argument('address',type=int);p.add_argument('value',type=int)
    p.add_argument('--host',default='127.0.0.1');p.add_argument('--port',type=int,default=502);p.add_argument('--unit-id',type=int,default=1)
    a=p.parse_args();c=ModbusTCPClient(a.host,a.port,a.unit_id,3.0);c.write_single_register(a.address,a.value)
    got=c.read_holding_registers(a.address,1)[0]
    print(json.dumps({"address":a.address,"requested":a.value,"observed":got,"verified":got==(a.value&0xffff)},sort_keys=True))
    return 0 if got==(a.value&0xffff) else 1
if __name__=='__main__': raise SystemExit(main())
