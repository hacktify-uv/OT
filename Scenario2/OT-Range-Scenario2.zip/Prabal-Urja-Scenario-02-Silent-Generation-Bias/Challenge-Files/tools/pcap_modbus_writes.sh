#!/usr/bin/env bash
set -Eeuo pipefail
PCAP="${1:?Usage: pcap_modbus_writes.sh <pcap-file>}"
tshark -n -r "$PCAP" -Y 'modbus.func_code == 6 || modbus.func_code == 16' \
  -T fields -E header=y -E separator='|' -E quote=d \
  -e frame.time -e ip.src -e tcp.srcport -e ip.dst -e tcp.dstport \
  -e modbus.func_code -e modbus.reference_num -e modbus.word_cnt -e modbus.regval_uint16
