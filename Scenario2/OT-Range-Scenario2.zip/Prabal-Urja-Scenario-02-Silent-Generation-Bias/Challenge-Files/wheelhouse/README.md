# Optional Python wheelhouse

The Scenario 2 process simulator requires pandapower. `setup.sh` installs the
pinned requirements from this directory when wheel files are present. Otherwise
it retrieves them from PyPI during installation.

To pre-stage dependencies for the same CPU architecture and Python version:

```bash
python3 -m pip download -r ../process/requirements.txt -d .
```
