#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from modbus_client import ModbusError, ModbusTCPClient

STATIC_DIR = Path(__file__).resolve().parent / "static"
STATE_LOCK = threading.Lock()
STATE: dict[str, object] = {"status": "starting", "modbus_connected": False}
DB_PATH = Path(os.environ.get("HMI_DB_PATH", "/var/lib/prabal-urja-s02/operator-historian.db"))
ACCESS_LOG = Path(os.environ.get("HMI_ACCESS_LOG", "/var/log/prabal-urja-s02/operator-access.log"))


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def initialise_db() -> None:
    if not DB_PATH.parent.exists(): DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(DB_PATH) as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS samples (
                timestamp TEXT PRIMARY KEY,
                setpoint_mw REAL,
                actual_mw REAL,
                transformer_loading REAL,
                corridor_loading REAL,
                unit_voltage REAL,
                winding_temp REAL,
                risk_state INTEGER,
                sequence INTEGER
            )
        """)
        db.execute("CREATE INDEX IF NOT EXISTS idx_samples_timestamp ON samples(timestamp)")


def poller() -> None:
    host = os.environ.get("MODBUS_HOST", "127.0.0.1")
    port = int(os.environ.get("MODBUS_PORT", "502"))
    unit = int(os.environ.get("MODBUS_UNIT_ID", "1"))
    client = ModbusTCPClient(host=host, port=port, unit_id=unit, timeout=2.5)
    while True:
        timestamp = utc_now()
        try:
            command = client.read_holding_registers(1024, 6)
            feedback = client.read_holding_registers(1040, 8)
            sample = {
                "status": "up",
                "asset": "PU-GOV-PLC-02",
                "last_update": timestamp,
                "modbus_connected": True,
                "setpoint_mw": command[0],
                "ramp_rate_mw_s": command[1] / 10.0,
                "governor_mode": command[2],
                "maintenance_override": command[3],
                "cooling_demand_pct": command[4],
                "command_sequence": command[5],
                "actual_generation_mw": feedback[0],
                "transformer_loading_pct": feedback[1] / 10.0,
                "corridor_loading_pct": feedback[2] / 10.0,
                "unit_bus_voltage_kv": feedback[3] / 100.0,
                "winding_temperature_c": feedback[4] / 10.0,
                "risk_state": feedback[5],
                "command_sequence_echo": feedback[6],
                "simulator_heartbeat": feedback[7],
            }
            with sqlite3.connect(DB_PATH) as db:
                db.execute(
                    "INSERT OR REPLACE INTO samples VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (timestamp, sample["setpoint_mw"], sample["actual_generation_mw"],
                     sample["transformer_loading_pct"], sample["corridor_loading_pct"],
                     sample["unit_bus_voltage_kv"], sample["winding_temperature_c"],
                     sample["risk_state"], sample["command_sequence"]),
                )
                cutoff = (datetime.now(timezone.utc) - timedelta(hours=12)).isoformat().replace("+00:00", "Z")
                db.execute("DELETE FROM samples WHERE timestamp < ?", (cutoff,))
            with STATE_LOCK:
                STATE.clear()
                STATE.update(sample)
        except (OSError, ModbusError, ValueError) as exc:
            with STATE_LOCK:
                STATE.clear()
                STATE.update({"status": "degraded", "last_update": timestamp, "modbus_connected": False, "error": str(exc)})
        time.sleep(1.0)


class Handler(BaseHTTPRequestHandler):
    server_version = "PrabalOperatorConsole/1.0"

    def log_message(self, fmt: str, *args: object) -> None:
        if not ACCESS_LOG.parent.exists(): ACCESS_LOG.parent.mkdir(parents=True, exist_ok=True)
        with ACCESS_LOG.open("a", encoding="utf-8") as handle:
            handle.write(f"{utc_now()} source={self.client_address[0]} {fmt % args}\n")

    def send_bytes(self, code: int, content_type: str, data: bytes) -> None:
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        if parsed.path == "/api/live":
            with STATE_LOCK:
                data = json.dumps(STATE, sort_keys=True).encode()
            self.send_bytes(200, "application/json", data)
            return
        if parsed.path == "/api/health":
            with STATE_LOCK:
                body = {
                    "status": "up" if STATE.get("modbus_connected") else "degraded",
                    "modbus_connected": bool(STATE.get("modbus_connected")),
                    "last_update": STATE.get("last_update"),
                }
            self.send_bytes(200, "application/json", json.dumps(body).encode())
            return
        if parsed.path == "/api/history":
            minutes = max(1, min(120, int(parse_qs(parsed.query).get("minutes", ["30"])[0])))
            cutoff = (datetime.now(timezone.utc) - timedelta(minutes=minutes)).isoformat().replace("+00:00", "Z")
            with sqlite3.connect(DB_PATH) as db:
                rows = db.execute(
                    "SELECT timestamp,setpoint_mw,actual_mw,transformer_loading,corridor_loading,winding_temp,risk_state FROM samples WHERE timestamp >= ? ORDER BY timestamp",
                    (cutoff,),
                ).fetchall()
            names = ["timestamp", "setpoint_mw", "actual_mw", "transformer_loading", "corridor_loading", "winding_temp", "risk_state"]
            self.send_bytes(200, "application/json", json.dumps([dict(zip(names, row)) for row in rows]).encode())
            return
        if parsed.path == "/api/intertie":
            body = {
                "coordination_asset": "PU-RB-RTU-07",
                "location": "River Bend Remote Substation",
                "role": "Feeder and bus-tie switching coordination",
                "status": "TELEMETRY AVAILABLE - SWITCHING REQUIRES CONTROL-CENTRE AUTHORISATION",
                "note": "This operational dependency becomes relevant if the northern corridor remains stressed."
            }
            self.send_bytes(200, "application/json", json.dumps(body).encode())
            return

        target = "index.html" if parsed.path == "/" else parsed.path.lstrip("/")
        if ".." in target:
            self.send_bytes(400, "text/plain", b"Bad request")
            return
        path = STATIC_DIR / target
        if not path.is_file():
            self.send_bytes(404, "text/plain", b"Not found")
            return
        content_type = "text/html; charset=utf-8"
        if path.suffix == ".css":
            content_type = "text/css; charset=utf-8"
        elif path.suffix == ".js":
            content_type = "application/javascript; charset=utf-8"
        self.send_bytes(200, content_type, path.read_bytes())


def main() -> int:
    initialise_db()
    threading.Thread(target=poller, name="modbus-poller", daemon=True).start()
    port = int(os.environ.get("HMI_PORT", "8090"))
    server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
