#!/usr/bin/env python3
"""Small dependency-free Modbus/TCP client used by the range services.

The OpenPLC endpoint is the real protocol server. This client creates standard
MBAP and Modbus PDUs for FC03, FC06 and FC16 and performs strict response checks.
"""
from __future__ import annotations

import socket
import struct
import threading
from dataclasses import dataclass


class ModbusError(RuntimeError):
    pass


@dataclass
class ModbusTCPClient:
    host: str
    port: int = 502
    unit_id: int = 1
    timeout: float = 3.0

    _counter = 0
    _lock = threading.Lock()

    @classmethod
    def _transaction_id(cls) -> int:
        with cls._lock:
            cls._counter = (cls._counter + 1) & 0xFFFF
            return cls._counter or 1

    @staticmethod
    def _recv_exact(sock: socket.socket, length: int) -> bytes:
        data = bytearray()
        while len(data) < length:
            chunk = sock.recv(length - len(data))
            if not chunk:
                raise ModbusError("connection closed before complete response")
            data.extend(chunk)
        return bytes(data)

    def _request(self, pdu: bytes) -> bytes:
        tid = self._transaction_id()
        mbap = struct.pack(">HHHB", tid, 0, len(pdu) + 1, self.unit_id)
        with socket.create_connection((self.host, self.port), timeout=self.timeout) as sock:
            sock.settimeout(self.timeout)
            sock.sendall(mbap + pdu)
            header = self._recv_exact(sock, 7)
            r_tid, protocol, length, unit = struct.unpack(">HHHB", header)
            if r_tid != tid or protocol != 0 or unit != self.unit_id or length < 2:
                raise ModbusError("invalid MBAP response")
            response = self._recv_exact(sock, length - 1)
        if response[0] & 0x80:
            code = response[1] if len(response) > 1 else -1
            raise ModbusError(f"Modbus exception function=0x{response[0]:02x} code={code}")
        return response

    def read_holding_registers(self, address: int, count: int) -> list[int]:
        if not 1 <= count <= 125:
            raise ValueError("count must be between 1 and 125")
        response = self._request(struct.pack(">BHH", 3, address, count))
        if response[0] != 3 or response[1] != count * 2 or len(response) != 2 + count * 2:
            raise ModbusError("malformed FC03 response")
        return list(struct.unpack(">" + "H" * count, response[2:]))

    def write_single_register(self, address: int, value: int) -> None:
        value &= 0xFFFF
        request = struct.pack(">BHH", 6, address, value)
        response = self._request(request)
        if response != request:
            raise ModbusError("FC06 echo mismatch")

    def write_multiple_registers(self, address: int, values: list[int]) -> None:
        if not 1 <= len(values) <= 123:
            raise ValueError("values length must be between 1 and 123")
        payload = struct.pack(">BHHB", 16, address, len(values), len(values) * 2)
        payload += struct.pack(">" + "H" * len(values), *[v & 0xFFFF for v in values])
        response = self._request(payload)
        if response != struct.pack(">BHH", 16, address, len(values)):
            raise ModbusError("FC16 acknowledgement mismatch")
