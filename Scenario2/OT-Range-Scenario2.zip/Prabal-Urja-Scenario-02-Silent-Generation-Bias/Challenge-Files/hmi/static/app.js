const $ = id => document.getElementById(id);
const modeName = v => ({0:'STOP / MINIMUM LOAD',1:'AUTOMATIC LOAD CONTROL',2:'MANUAL ENGINEERING'})[v] || `UNKNOWN (${v})`;
const riskName = v => ({0:'NORMAL',1:'STRESSED',2:'CRITICAL'})[v] || 'UNKNOWN';
function fixed(v,n=1){return Number(v ?? 0).toFixed(n)}
async function json(url){const r=await fetch(url,{cache:'no-store'});if(!r.ok)throw new Error(`${r.status}`);return r.json()}
function renderLive(s){
  $('linkState').textContent=s.modbus_connected?'PLC LINK HEALTHY':'PLC LINK DEGRADED';$('linkState').className=`status ${s.modbus_connected?'up':'down'}`;
  $('setpoint').textContent=fixed(s.setpoint_mw,0);$('actual').textContent=fixed(s.actual_generation_mw,0);
  $('transformer').textContent=fixed(s.transformer_loading_pct);$('corridor').textContent=fixed(s.corridor_loading_pct);
  $('voltage').textContent=fixed(s.unit_bus_voltage_kv,2);$('temperature').textContent=fixed(s.winding_temperature_c);
  $('mode').textContent=modeName(s.governor_mode);$('ramp').textContent=`${fixed(s.ramp_rate_mw_s)} MW/s`;
  $('cooling').textContent=`${fixed(s.cooling_demand_pct,0)}%`;$('sequence').textContent=s.command_sequence ?? '--';
  $('risk').textContent=riskName(s.risk_state);$('diagramMW').textContent=`${fixed(s.actual_generation_mw,0)} MW`;
  $('diagramTrafo').textContent=`${fixed(s.transformer_loading_pct)}%`;$('diagramLine').textContent=`${fixed(s.corridor_loading_pct)}%`;
  const a=$('alarm'); if(s.risk_state===2){a.className='alarm critical';a.innerHTML='<strong>GRID OPERATING LIMIT EXCEEDED</strong><p>Immediate operator review required.</p>'}
  else if(s.risk_state===1){a.className='alarm stressed';a.innerHTML='<strong>ADVISORY: REDUCED OPERATING MARGIN</strong><p>No static protection trip threshold has been crossed.</p>'}
  else{a.className='alarm normal';a.innerHTML='<strong>NO ACTIVE PROTECTION ALARM</strong><p>Static alarm thresholds remain within configured limits.</p>'}
}
function line(ctx,pts,key,min,max,color,w,h,pad){ctx.strokeStyle=color;ctx.lineWidth=2;ctx.beginPath();pts.forEach((p,i)=>{const x=pad+i*Math.max(1,(w-2*pad)/Math.max(1,pts.length-1));const y=h-pad-((Number(p[key])-min)/(max-min))*(h-2*pad);i?ctx.lineTo(x,y):ctx.moveTo(x,y)});ctx.stroke()}
function draw(points){const c=$('trend'),ctx=c.getContext('2d'),w=c.width,h=c.height,p=34;ctx.clearRect(0,0,w,h);ctx.strokeStyle='#203641';ctx.lineWidth=1;for(let i=0;i<6;i++){const y=p+i*(h-2*p)/5;ctx.beginPath();ctx.moveTo(p,y);ctx.lineTo(w-p,y);ctx.stroke()}if(!points.length)return;line(ctx,points,'setpoint_mw',450,800,'#f3c969',w,h,p);line(ctx,points,'actual_mw',450,800,'#6ed1e8',w,h,p);line(ctx,points,'transformer_loading',50,110,'#d989e8',w,h,p);line(ctx,points,'corridor_loading',50,110,'#7fe0a2',w,h,p);$('trendTime').textContent=`${points.length} samples • ${new Date(points.at(-1).timestamp).toLocaleTimeString()}`}
async function refresh(){try{renderLive(await json('/api/live'));draw(await json('/api/history?minutes=30'))}catch(e){$('linkState').textContent='CONSOLE DATA UNAVAILABLE';$('linkState').className='status down'}}
json('/api/intertie').then(v=>{$('intertie').innerHTML=`<div><dt>Remote Asset</dt><dd>${v.coordination_asset}</dd></div><div><dt>Location</dt><dd>${v.location}</dd></div><div><dt>Function</dt><dd>${v.role}</dd></div><div><dt>Status</dt><dd>${v.status}</dd></div>`}).catch(()=>{});
refresh();setInterval(refresh,2000);
