#!/usr/bin/env bash
set -Eeuo pipefail
OPENPLC_DIR="${1:?Usage: patch_openplc_legacy.sh <OpenPLC directory>}"
INSTALLER="$OPENPLC_DIR/background_installer.sh"
WEBSERVER="$OPENPLC_DIR/webserver/webserver.py"
[[ -f "$INSTALLER" && -f "$WEBSERVER" && -f "$OPENPLC_DIR/webserver/core/custom_layer.h" ]] || {
  echo "[!] Historical OpenPLC C++ code editor sources missing; refusing to continue." >&2
  exit 1
}
python3 - "$INSTALLER" <<'PYCODE'
from pathlib import Path
import sys
p = Path(sys.argv[1]); s = p.read_text()
start = s.find('function linux_install_deps {')
end = s.find('function install_all_libs {', start)
if start < 0 or end < 0:
    raise SystemExit('Unexpected historical OpenPLC installer layout')
replacement = r"""function linux_install_deps {
    $1 apt-get update
    $1 apt-get install -y --no-install-recommends build-essential pkg-config \
        bison flex autoconf automake libtool make git sqlite3 cmake curl
}
function install_py_deps {
    if [ -f "$(pwd)/py2deps/flask/__init__.py" ]; then return 0; fi
    python2.7 -m pip install --no-cache-dir --target "$(pwd)/py2deps" \
        'Flask==1.1.4' 'Werkzeug==1.0.1' 'Jinja2==2.11.3' \
        'MarkupSafe==1.1.1' 'itsdangerous==1.1.0' \
        'Flask-Login==0.5.0' 'pyserial==3.5' 'pymodbus==2.1.0'
}

"""
s = s[:start] + replacement + s[end:]
p.write_text(s)
PYCODE
bash -n "$INSTALLER"
echo 'LEGACY_OPENPLC_INSTALLER_COMPATIBILITY_PATCHED'
