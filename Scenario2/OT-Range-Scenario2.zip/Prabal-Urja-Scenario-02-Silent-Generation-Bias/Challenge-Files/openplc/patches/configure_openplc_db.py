#!/usr/bin/env python3
"""Configure the pinned OpenPLC v3 database for Prabal Urja Scenario 2.

This script is deliberately strict: it validates the expected schema, selects the
scenario ST program, enables auto-RUN and exposes only Modbus/TCP. It is run by
setup.sh after OpenPLC installation and before systemd startup.
"""
from __future__ import annotations

import argparse
import sqlite3
import time
from pathlib import Path


def table_columns(db: sqlite3.Connection, table: str) -> set[str]:
    return {str(row[1]) for row in db.execute(f"PRAGMA table_info({table})")}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--database", required=True)
    parser.add_argument("--program-file", default="prabal_unit2.st")
    parser.add_argument("--modbus-port", type=int, default=502)
    args = parser.parse_args()

    database = Path(args.database)
    if not database.is_file():
        raise SystemExit(f"OpenPLC database not found: {database}")
    if not 1 <= args.modbus_port <= 65535:
        raise SystemExit("Invalid Modbus port")

    with sqlite3.connect(database) as db:
        program_columns = table_columns(db, "Programs")
        settings_columns = table_columns(db, "Settings")
        required_program = {"Name", "Description", "File", "Date_upload"}
        required_settings = {"Key", "Value"}
        if not required_program.issubset(program_columns):
            raise SystemExit(f"Unexpected Programs schema: {sorted(program_columns)}")
        if not required_settings.issubset(settings_columns):
            raise SystemExit(f"Unexpected Settings schema: {sorted(settings_columns)}")

        db.execute("DELETE FROM Programs WHERE File = ?", (args.program_file,))
        db.execute(
            "INSERT INTO Programs (Name, Description, File, Date_upload) VALUES (?, ?, ?, ?)",
            (
                "Prabal Urja Unit-2 Governor Control",
                "Native IEC 61131-3 governor and generation control program for Unit-2",
                args.program_file,
                int(time.time()),
            ),
        )

        desired = {
            "Modbus_port": str(args.modbus_port),
            "Dnp3_port": "disabled",
            "Enip_port": "disabled",
            "snap7": "false",
            "Pstorage_polling": "disabled",
            "Start_run_mode": "true",
        }
        existing = {str(row[0]) for row in db.execute("SELECT Key FROM Settings")}
        required = {"Modbus_port", "Start_run_mode"}
        missing = sorted(required - existing)
        if missing:
            raise SystemExit(f"Required OpenPLC settings are missing: {', '.join(missing)}")
        configured = {key: val for key, val in desired.items() if key in existing}
        for key, value in configured.items():
            db.execute("UPDATE Settings SET Value = ? WHERE Key = ?", (value, key))
        db.commit()

        selected = db.execute(
            "SELECT Name, Description, File FROM Programs WHERE File = ?", (args.program_file,)
        ).fetchone()
        settings = dict(
            db.execute(
                "SELECT Key, Value FROM Settings WHERE Key IN (" + ",".join("?" for _ in configured) + ")",
                tuple(configured.keys()),
            ).fetchall()
        )

    if not selected or selected[2] != args.program_file:
        raise SystemExit("Scenario program was not registered in OpenPLC")
    for key, expected in configured.items():
        if str(settings.get(key)) != expected:
            raise SystemExit(f"OpenPLC setting validation failed: {key}")

    print(f"OPENPLC_DATABASE_CONFIGURED program={args.program_file} modbus={args.modbus_port} autorun=true")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
