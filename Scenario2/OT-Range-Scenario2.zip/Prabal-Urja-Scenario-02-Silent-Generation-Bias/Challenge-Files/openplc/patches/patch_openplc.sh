#!/usr/bin/env bash
set -Eeuo pipefail
OPENPLC_DIR="${1:?Usage: patch_openplc.sh <OpenPLC directory>}"
COMPILE="$OPENPLC_DIR/webserver/scripts/compile_program.sh"
INSTALLER="$OPENPLC_DIR/background_installer.sh"
[[ -f "$COMPILE" && -f "$INSTALLER" ]] || { echo "OpenPLC source tree is incomplete" >&2; exit 1; }

# Ubuntu enables PIE by default. OpenPLC v3's generated objects are not always
# linked safely under those defaults. Add -no-pie to final runtime link steps.
python3 - "$COMPILE" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
s = p.read_text()
s = s.replace('g++ -std=gnu++11 *.cpp *.o -o openplc', 'g++ -std=gnu++11 -no-pie *.cpp *.o -o openplc')
s = s.replace('g++ *.cpp *.o -o openplc', 'g++ -no-pie *.cpp *.o -o openplc')
p.write_text(s)
PY

# Ubuntu 24.04 protects the system Python environment (PEP 668). OpenPLC has a
# project virtual environment already, so remove the redundant global pip write.
sed -i '/^[[:space:]]*python3 -m pip install pymodbus==2\.5\.3[[:space:]]*$/d' "$INSTALLER"

# Add support for Arch Linux package manager (pacman) in background_installer.sh dependency check
python3 - "$INSTALLER" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
s = p.read_text()
# Add pacman check before apt-get check
old_str = '    elif [ -x /usr/bin/apt-get ]; then'
new_str = '    elif [ -x /usr/bin/pacman ]; then\n        $1 pacman -Sy --noconfirm --needed base-devel cmake curl git openssl pkgconf python python-pip sqlite\n    elif [ -x /usr/bin/apt-get ]; then'
if old_str in s:
    s = s.replace(old_str, new_str)
else:
    print("Warning: apt-get check not found in background_installer.sh", file=sys.stderr)
p.write_text(s)
PY

# Fix swapfile creation on F2FS/Btrfs filesystems to prevent corruption (e.g. on Arch Linux)
python3 - "$INSTALLER" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
s = p.read_text()
old_swap = """function swap_on {
    echo "creating swapfile..."

    # Fallocate is instantaneous. Only use dd as fallback.
    $1 touch "$SWAP_FILE"
    $1 fallocate -zl 1G "$SWAP_FILE" ||
    $1 dd if=/dev/zero of="$SWAP_FILE" bs=1M count=1000

    $1 mkswap "$SWAP_FILE"
    $1 swapon "$SWAP_FILE"
}"""
new_swap = """function swap_on {
    echo "creating swapfile..."

    # Fallocate is instantaneous. Only use dd as fallback.
    $1 touch "$SWAP_FILE"
    $1 chattr +C "$SWAP_FILE" 2>/dev/null || true
    $1 fallocate -l 1G "$SWAP_FILE" ||
    $1 dd if=/dev/zero of="$SWAP_FILE" bs=1M count=1000

    $1 chmod 0600 "$SWAP_FILE"
    $1 mkswap "$SWAP_FILE"
    $1 swapon "$SWAP_FILE"
}"""
if old_swap in s:
    s = s.replace(old_swap, new_swap)
else:
    # Fallback if there are minor formatting differences
    old_swap_alt = '    $1 fallocate -zl 1G "$SWAP_FILE" ||'
    new_swap_alt = '    $1 chattr +C "$SWAP_FILE" 2>/dev/null || true\\n    $1 fallocate -l 1G "$SWAP_FILE" ||'
    if old_swap_alt in s:
        s = s.replace(old_swap_alt, new_swap_alt)
        s = s.replace('    $1 mkswap "$SWAP_FILE"', '    $1 chmod 0600 "$SWAP_FILE"\\n    $1 mkswap "$SWAP_FILE"')
    else:
        print("Warning: swapfile function not matched in background_installer.sh", file=sys.stderr)
p.write_text(s)
PY

# Update cmake_minimum_required in opendnp3 to version 3.5 for newer CMake compatibility
CMAKE_LISTS="$OPENPLC_DIR/utils/dnp3_src/CMakeLists.txt"
if [[ -f "$CMAKE_LISTS" ]]; then
  sed -i 's/cmake_minimum_required (VERSION 2.8)/cmake_minimum_required (VERSION 3.5)/g' "$CMAKE_LISTS"
fi

# Add support for Arch Linux pacman in install_libmodbus and install_opendnp3
python3 - "$INSTALLER" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
s = p.read_text()
old_libmodbus = """    # Fix for RPM-based distros
    if [ -x /bin/yum ]; then
        sudo cp /usr/local/lib/pkgconfig/libmodbus.pc /usr/share/pkgconfig/
        sudo cp /usr/local/lib/lib*.* /lib64/
    fi"""
new_libmodbus = """    # Fix for RPM-based distros
    if [ -x /bin/yum ]; then
        sudo cp /usr/local/lib/pkgconfig/libmodbus.pc /usr/share/pkgconfig/
        sudo cp /usr/local/lib/lib*.* /lib64/
    fi
    # Fix for pacman-based distros (Arch Linux)
    if [ -x /usr/bin/pacman ]; then
        $1 cp /usr/local/lib/pkgconfig/libmodbus.pc /usr/share/pkgconfig/
        $1 cp -d /usr/local/lib/libmodbus* /usr/lib/
    fi"""
if old_libmodbus in s:
    s = s.replace(old_libmodbus, new_libmodbus)
else:
    print("Warning: libmodbus rpm check not found in background_installer.sh", file=sys.stderr)

old_opendnp3 = """    $1 make install || fail "Error installing OpenDNP3"
    $1 ldconfig"""
new_opendnp3 = """    $1 make install || fail "Error installing OpenDNP3"
    if [ -x /usr/bin/pacman ]; then
        $1 cp -d /usr/local/lib/libasiodnp3.so /usr/local/lib/libasiopal.so /usr/local/lib/libopendnp3.so /usr/local/lib/libopenpal.so /usr/lib/
    fi
    $1 ldconfig"""
if old_opendnp3 in s:
    s = s.replace(old_opendnp3, new_opendnp3)
else:
    print("Warning: opendnp3 install steps not found in background_installer.sh", file=sys.stderr)
p.write_text(s)
PY

# Fix race condition in webserver/core/server.cpp thread arguments
python3 - "$OPENPLC_DIR" <<'PY'
from pathlib import Path
import sys
SERVER_CPP = Path(sys.argv[1]) / "webserver/core/server.cpp"
if SERVER_CPP.exists():
    sc = SERVER_CPP.read_text()
    old_start = """        else
        {
            int arguments[2];
            pthread_t thread;
            int ret = -1;
            sprintf(log_msg, "Server: Client accepted! Creating thread for the new client ID: %d...\\n", client_fd);
            openplc_log(log_msg);
            arguments[0] = client_fd;
            arguments[1] = protocol_type;
            ret = pthread_create(&thread, NULL, handleConnections, (void*)arguments);
            if (ret==0) 
            {
                pthread_detach(thread);
            }
        }"""
    new_start = """        else
        {
            int *arguments = (int *)malloc(sizeof(int) * 2);
            pthread_t thread;
            int ret = -1;
            sprintf(log_msg, "Server: Client accepted! Creating thread for the new client ID: %d...\\n", client_fd);
            openplc_log(log_msg);
            arguments[0] = client_fd;
            arguments[1] = protocol_type;
            ret = pthread_create(&thread, NULL, handleConnections, (void*)arguments);
            if (ret==0) 
            {
                pthread_detach(thread);
            }
            else
            {
                free(arguments);
            }
        }"""
    if old_start in sc:
        sc = sc.replace(old_start, new_start)
    else:
        print("Warning: old_start not found in server.cpp", file=sys.stderr)

    old_handle = """void *handleConnections(void *arguments)
{
    char log_msg[1000];
    int *args = (int *)arguments;
    int client_fd = args[0];
    int protocol_type = args[1];"""
    new_handle = """void *handleConnections(void *arguments)
{
    char log_msg[1000];
    int *args = (int *)arguments;
    int client_fd = args[0];
    int protocol_type = args[1];
    free(arguments);"""
    if old_handle in sc:
        sc = sc.replace(old_handle, new_handle)
    else:
        print("Warning: old_handle not found in server.cpp", file=sys.stderr)
    SERVER_CPP.write_text(sc)
else:
    print("Warning: server.cpp not found", file=sys.stderr)
PY

echo "OPENPLC_PATCHED"
