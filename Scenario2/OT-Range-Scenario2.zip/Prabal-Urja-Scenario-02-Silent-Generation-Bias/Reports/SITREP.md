# SITREP Report (SITREP)

**Cyber Exercise — Prabal Urja Grid Sentinel**  
**Scenario 2 — Silent Generation Bias**  
**Version 1.0**

---

**Date:** [YYYY-MM-DD]  
**Time:** [Time of Detection/Update]  
**Incident ID:** SITREP-PU-S02-[NUMBER]

---

## 1. Incident Overview

**Description:**

- Unauthorised Modbus/TCP governor-command changes detected on `PU-GOV-PLC-02`.
- Service affected: Prabal Urja Unit-2 OpenPLC governor control path.
- Attack vector: valid Modbus FC06/FC16 write commands accepted from a reachable but unapproved client.
- Operational effect: Unit-2 generation biased above the approved 650 MW dispatch point, increasing GT-2 and northern-corridor loading.
- Core services remained available during the observed activity.

**Severity Level:** High

**Impact:** Reduced operating margin, rising transformer winding temperature, increased corridor loading and risk of a coordinated follow-on switching event.

**Affected System:** `PU-GOV-PLC-02` — OpenPLC Runtime / Modbus TCP 502

---

## 2. Incident Details

**Detection Method:**

Review of operator trends, process historian data and packet captures identified command-register changes not supported by the dispatch log.

Initial commands:

```bash
curl -s http://127.0.0.1:8090/api/live | jq
jq -c 'select(.event_type=="PLC_COMMAND_REGISTER_CHANGE")' \
  /var/log/prabal-urja-s02/process-events.jsonl
```

Packet review:

```bash
sudo /opt/prabal-urja/scenario2/tools/pcap_modbus_writes.sh \
  /var/log/prabal-urja-s02/pcap/<CAPTURE>.pcap
```

**Specific indicators:**

- Write Single Register (`FC06`) or Write Multiple Registers (`FC16`).
- Target address 1024 for generator setpoint.
- Changes to address 1029 for command sequence.
- Source IP `[ATTACKER_IP]` not approved as a Modbus master.
- Setpoint progression: `[LIST OBSERVED VALUES]`.
- First anomalous timestamp: `[UTC TIMESTAMP]`.

**Initial Detection Time:** [Timestamp]

**Attack Vector:** Unauthenticated Modbus/TCP command message and parameter modification

---

## 3. Response Actions Taken

### Containment

- Collected packet, process and service evidence before modifying controls.
- Identified the unauthorised source from packet captures.
- Applied `[temporary source block / authorised-master allowlist]`.
- Preserved loopback Modbus access required by the process simulator and operator console.
- Confirmed legitimate SCADA polling remained available.

Commands used:

```bash
sudo /opt/prabal-urja/scenario2/tools/collect_evidence.sh
sudo /opt/prabal-urja/scenario2/tools/apply_hardening.sh <AUTHORISED_MASTER_IP>
sudo nft list table inet prabal_s02_hardening
```

### Eradication

- Verified the IEC 61131-3 program file had not been altered.
- Reviewed OpenPLC and grid-simulator journals for service manipulation.
- Removed unauthorised network reachability to TCP 502.
- Confirmed no unexpected maintenance override or governor-mode change remained.

### Recovery

- Restored the approved controller command block.
- Monitored actual generation as it returned safely to 650 MW.
- Confirmed transformer and corridor loading returned to acceptable levels.
- Confirmed grid risk state returned to `0`.
- Re-ran full three-vector service validation.

```bash
sudo /opt/prabal-urja/scenario2/venv/bin/python \
  /opt/prabal-urja/scenario2/tools/operator_restore.py \
  --host 127.0.0.1 --port 502
sudo ./validate.sh
```

### Lessons Learned

- Valid OT protocol messages can be malicious even when the controller remains healthy.
- Port-level monitoring alone is insufficient; defenders must inspect function codes, register addresses and process context.
- Static high/low alarms may miss gradual but harmful operating changes.
- Positive master allowlisting is safer than identifying attackers only after impact.
- Process historian, network packet and operator-log correlation is essential.

---

## 4. Technical Analysis

**Evidence:**

- `/var/log/prabal-urja-s02/process-historian.csv`
- `/var/log/prabal-urja-s02/process-events.jsonl`
- `/var/log/prabal-urja-s02/pcap/*.pcap`
- `/var/lib/prabal-urja-s02/latest-state.json`
- systemd journals for all Scenario 2 services
- nftables rules before and after containment

**Indicators of Compromise:**

- Unapproved source IP communicating with TCP 502.
- FC06/FC16 writes to command-register block 1024–1029.
- Generator setpoint above approved dispatch.
- Command sequence not traceable to the operator workflow.
- Process risk changing from normal to stressed shortly after register writes.

**Tactics, Techniques and Procedures:**

**MITRE ATT&CK for ICS T0836 — Modify Parameter**  
The attacker changed a process-control setpoint using a legitimate industrial protocol.

**MITRE ATT&CK for ICS T0831 — Manipulation of Control**  
The attacker influenced Unit-2 output and the resulting electrical process.

**MITRE ATT&CK for ICS T1692.001 — Unauthorized Message: Command Message**  
The attacker transmitted syntactically valid control messages from an unauthorised source.

**Mitigation Recommendations:**

- Enforce Modbus master allowlisting.
- Alert on write function codes and critical register ranges.
- Validate commands against dispatch and change-management records.
- Segment the Hydro Control Zone from vendor and general control networks.
- Require authenticated mediation for routed legacy-protocol access.
- Retain rolling packet capture and high-resolution process history.
- Add rate-of-change and operating-margin analytics.

---

## 5. Communication

**Internal Notification:**

- Blue Team Incident Commander: immediate
- Hydro Operations Shift Supervisor: immediate
- Grid Control / Load Dispatch: immediate
- OT Engineering: immediate
- SOC Lead **Meera Iyer**: immediate
- Exercise Control: according to live-fire rules

**External Notification:**

Training exercise only unless Exercise Control declares a real-world incident. No external notification should be made without authorisation.

**Updates:**

- Frequency: every 30 minutes during active containment, or immediately following a major process-state change
- Channel: approved exercise incident channel and encrypted operational email

---

## 6. Additional Notes

The stressed-corridor condition increases the importance of River Bend remote switching asset `PU-RB-RTU-07`. The substation operations team should be advised of the attempted control manipulation even before Scenario 3 begins.

---

## 7. Submission

**Prepared By:** [Blue Team Analyst Name]  
**Reviewed By:** [Incident Commander]  
**Status:** [Initial / Update / Final]

## 8. POC (Screenshots)

Attach screenshots of:

- initial operator trend;
- direct PLC register state;
- packet source and Modbus function code;
- process-event correlation;
- containment control;
- final restored condition.
