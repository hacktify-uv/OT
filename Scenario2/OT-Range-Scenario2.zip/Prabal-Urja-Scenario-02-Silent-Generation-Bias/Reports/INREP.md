# Incident Notification Report (INREP)

**Cyber Exercise — Prabal Urja Grid Sentinel**  
**Scenario 2 — Silent Generation Bias**  
**Version 1.0**

---

**Date:** [YYYY-MM-DD]  
**Time:** [Time of Incident in UTC/IST]  
**Report ID:** IN-PU-S02-[NUMBER]

---

## 1. Current Situation

**Description:** An unauthorised change to the Unit-2 generator dispatch setpoint has been detected on controller `PU-GOV-PLC-02`. The controller is accepting Modbus/TCP write commands and actual generation is moving away from the approved 650 MW operating point. Generator-transformer and northern-corridor loading are increasing.

**Threat Level:** High

**Areas of Concern:**

- Valid Modbus control messages may have originated from an unapproved network source.
- The change remains within broad PLC engineering limits and may not trigger an immediate protection trip.
- Sustained generation bias can reduce transformer and corridor operating margin.
- The River Bend remote switching dependency may become operationally significant if corridor stress continues.
- Additional command-register changes may follow unless the source is contained.

---

## 2. Threat Intelligence

**Sources:**

- Process historian: `/var/log/prabal-urja-s02/process-historian.csv`
- Command-change events: `/var/log/prabal-urja-s02/process-events.jsonl`
- Modbus packet captures: `/var/log/prabal-urja-s02/pcap/`
- Current process state: `/var/lib/prabal-urja-s02/latest-state.json`
- OpenPLC journal: `journalctl -u prabal-openplc.service`
- Grid simulator journal: `journalctl -u prabal-grid-simulator.service`

**Indicators of Compromise:**

- Modbus function code 6 or 16 targeting holding-register address 1024 or adjacent command registers.
- Generator setpoint differing from the approved 650 MW value without a matching dispatch instruction.
- Repeated small setpoint increases over a short period.
- Command sequence values not recorded in the operator dispatch workflow.
- Modbus/TCP requests to `PU-GOV-PLC-02` from a source not present in the authorised-master list.
- Transformer or corridor loading moving into the stressed region after command-register changes.

**Log Entry Identified:**

```json
[Paste the relevant PLC_COMMAND_REGISTER_CHANGE event here]
```

**Packet Evidence:**

```text
[Paste tshark output containing timestamp, source IP, function code, register and value]
```

---

## 3. Vulnerability Identification

**Vulnerability:** Unauthenticated and insufficiently restricted Modbus/TCP control access

**Affected Control Path:** Modbus/TCP holding-register writes to the OpenPLC Unit-2 governor command block

**Description:** The controller accepts valid Modbus/TCP write commands from any routed client that can reach TCP 502. The PLC enforces broad engineering value limits but does not authenticate the requesting master, verify operational approval, or restrict critical register writes to an authorised source.

**Patch Status:** Ongoing — network allowlisting, command-source monitoring and operating-state restoration required

---

## 4. Security Operations

**Prevention Steps:**

- Apply a positive source allowlist for the authorised SCADA master.
- Alert on Modbus FC06 and FC16 writes to the governor command block.
- Validate setpoint changes against dispatch instructions and approved rate-of-change limits.
- Separate engineering, operator and vendor traffic at the network layer.
- Maintain packet capture and process-history retention for critical control paths.
- Introduce an authenticated gateway where legacy unauthenticated protocols must cross routed zones.

**Immediate Actions:**

1. Preserve evidence:
   ```bash
   sudo /opt/prabal-urja/scenario2/tools/collect_evidence.sh
   ```
2. Identify the unauthorised source from Modbus packet captures.
3. Apply a precise source block or authorised-master allowlist.
4. Restore the approved command block locally:
   ```bash
   sudo /opt/prabal-urja/scenario2/venv/bin/python \
     /opt/prabal-urja/scenario2/tools/operator_restore.py \
     --host 127.0.0.1 --port 502
   ```
5. Monitor the process until actual generation returns near 650 MW and risk state returns to normal.
6. Notify hydro operations, grid control and the Blue Team incident commander.

---

## 5. Additional Notes

This incident is part of the interconnected Prabal Urja Red-vs-Blue exercise. Scenario 1 exposed the operational relationship to `PU-GOV-PLC-02`. Scenario 2 can create the conditions that make River Bend switching asset `PU-RB-RTU-07` relevant to the next stage.

**Connected services at risk:**

- Unit-2 generator transformer GT-2
- Prabal-North 220 kV corridor
- River Bend remote feeder and bus-tie switching coordination

---

## 6. POC (Screenshots)

Attach:

- operator-console trend showing setpoint and actual generation;
- direct Modbus register snapshot;
- packet capture showing the unauthorised source and write function code;
- process-event log entry;
- containment rule;
- restored normal state.
