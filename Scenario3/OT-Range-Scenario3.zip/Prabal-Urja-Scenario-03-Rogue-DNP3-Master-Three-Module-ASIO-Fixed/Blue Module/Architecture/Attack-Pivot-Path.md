# Attack Pivot Path

## Campaign progression

```text
Scenario 1                                  Scenario 2
OPC UA maintenance exposure                OpenPLC / Modbus generation bias
        |                                             |
        | reveals downstream controller               | identifies River Bend as
        | relationships                               | a critical switching dependency
        v                                             v
            Scenario 3 — River Bend DNP3 RTU
            retained maintenance listener
            unauthorised second master
            valid Select-Before-Operate controls
                              |
                              | demonstrates that trusted-source assumptions
                              | and command semantics are not independently verified
                              v
            Scenario 4 — Control-centre IEC-104 command abuse
```

## Scenario 3 Red path

```text
Red workstation
    |
    | narrow service discovery
    v
TCP 20001 retained DNP3 maintenance channel
    |
    | DNP3 integrity read / point interpretation
    v
Binary-output controls for bus tie and feeder breakers
    |
    | close bus tie, then open Feeder A
    v
River Bend load transfers onto Feeder B
    |
    | corridor and transformer margin reduced
    v
Operational evidence points toward weak command authorisation at control centre
```

## Blue defensive path

```text
Process alarm + breaker-state change
    |
    +--> DNP3 command audit: SELECT and OPERATE
    +--> socket state: second TCP master session
    +--> PCAP: unexpected IP and DNP3 source address
    +--> historian: Feeder B load and corridor rise
    |
    v
Preserve evidence -> restrict maintenance listener -> restore switching -> validate polling
```
