# Scenario Connectivity and Story Justification

## Input from Scenario 2

Scenario 2 leaves Prabal Urja Unit-2 near 720 MW and identifies River Bend RTU `PU-RB-RTU-07` as the switching dependency for the northern corridor. The elevated generation condition does not by itself create an outage, but it reduces the reserve available when feeder topology changes.

## Scenario 3 operational consequence

River Bend normally carries approximately 318 MW on Feeder A and 302 MW on Feeder B with the bus tie open. A valid close command to the bus tie followed by an open command to Feeder A transfers the combined load to Feeder B. The process model records:

- Feeder B near 620 MW;
- transformer loading near 101.4%;
- northern-corridor loading near 96.8%;
- system frequency near 49.94 Hz;
- overload alarms while telemetry and authorised DNP3 polling remain available.

The attack therefore creates a controlled operational effect without relying on denial of service or a fake OT protocol.

## Handoff to Scenario 4

Blue evidence shows that network reachability and a valid protocol sequence were enough to operate field devices. Red learns that the control environment relies heavily on source location and legitimate utilities rather than independent command approval. Scenario 4 extends that lesson into the control centre through native IEC-104 command abuse.

Scenario 3 does not install, emulate or expose IEC-104. Its handoff consists only of storyline evidence and architectural context.
