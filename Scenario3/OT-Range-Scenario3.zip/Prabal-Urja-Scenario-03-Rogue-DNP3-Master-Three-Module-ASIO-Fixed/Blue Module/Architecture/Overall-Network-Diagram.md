# Overall Prabal Urja Range Architecture

> The `195.0.0.0/8` addresses below are documentation examples for the isolated exercise. The setup scripts do not assign or hardcode host addresses.

```text
                                  RED TEAM ENCLAVE
                                  195.10.10.0/24
                            [Red Operations Workstation]
                                         |
                                         | controlled range routing
                                         v
+---------------------------- RANGE CORE / FILTERING ----------------------------+
|                                                                                |
|  VENDOR / OT ACCESS DMZ              CONTROL-CENTRE ZONE        BLUE SOC ZONE   |
|  195.20.10.0/24                     195.30.10.0/24             195.70.10.0/24   |
|  Scenario 1 OPC UA                   Load-dispatch services     SIEM / PCAP      |
|  maintenance gateway                Legitimate DNP3 master     Analyst station  |
|           |                                  |                        |          |
|           +----------------------+-----------+------------------------+          |
|                                  |                                             |
|                         OT CONTROL NETWORK                                     |
|                                  |                                             |
|        HYDRO PLANT ZONE          |         RIVER BEND SUBSTATION ZONE          |
|        195.40.10.0/24            |         195.50.10.0/24                      |
|        Scenario 2 OpenPLC        +-------->[PU-RB-RTU-07]                      |
|        Unit-2 governor                     DNP3 TCP 20000 / 20001              |
|                                                   |                            |
|                                                   v                            |
|                                      POWER-PROCESS ZONE                        |
|                                      195.60.10.0/24                            |
|                                      Breakers, feeders, corridor               |
+--------------------------------------------------------------------------------+
```

## Scenario 3 documentation identities

| Role | Example address | Runtime behaviour |
|---|---:|---|
| Red workstation | `195.10.10.44` | Discovers and reaches the retained maintenance listener |
| Control-centre master | `195.30.10.11` | Represented locally by the legitimate master service in the single-VM package |
| River Bend RTU | `195.50.10.27` | Assigned externally by the range; never hardcoded |
| Blue monitoring host | `195.70.10.20` | Receives mirrored or collected evidence |

The single-VM scenario package co-locates the legitimate master, outstation, process model and console for easy deployment. Network controls preserve distinct logical relationships. A multi-VM deployment may move the legitimate master to the control-centre subnet without changing the DNP3 point model.
