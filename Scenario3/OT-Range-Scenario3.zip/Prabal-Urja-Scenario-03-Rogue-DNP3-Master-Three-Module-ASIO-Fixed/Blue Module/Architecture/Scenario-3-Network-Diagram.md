# Scenario 3 Network Diagram — River Bend Substation

```text
                          195.30.10.0/24 CONTROL-CENTRE ZONE

                PU-LDC-DNP3-MASTER-01 (DNP3 source address 1)
                                     |
                         authorised primary session
                         TCP 20000 / outstation 10
                                     |
                                     v
+--------------------------------------------------------------------------------+
| River Bend 220/132 kV Substation                         Example 195.50.10.27   |
|                                                                                |
|  +-------------------------- PU-RB-RTU-07 -------------------------------+      |
|  |                                                                      |      |
|  | OpenDNP3 primary channel               OpenDNP3 maintenance channel   |      |
|  | TCP 20000                              TCP 20001                      |      |
|  | Expected master: 1                     Expected master: 2            |      |
|  | Remote access blocked                  Remote access incorrectly open |      |
|  |                                        respondToAnyMaster enabled     |      |
|  +-------------------------------+------------------+-------------------+      |
|                                  |                  ^                          |
|                                  |                  | second DNP3 master       |
|                                  |                  | from 195.10.10.0/24      |
|                                  v                  |                          |
|     +-----------------+    +-------------------+    |                          |
|     | DNP3 command    |--->| Breaker/process   |<---+                          |
|     | audit & PCAP    |    | model             |                               |
|     +-----------------+    +---------+---------+                               |
|                                      |                                         |
|                                      v                                         |
|                         Operator Console TCP 8092                              |
+--------------------------------------------------------------------------------+
                                       |
                     Feeder A 318 MW   |   Feeder B 302 MW
                            [52A]-------+-------[52C]
                                      [52B]
                                    BUS TIE
```

## Exposure logic

- TCP 20000 is present for the legitimate OpenDNP3 master but is blocked from non-loopback interfaces by the baseline range firewall.
- TCP 20001 remains reachable from the exercise OT network.
- DNP3 source and destination addresses are protocol-layer identities and are separate from IP addresses.
- The process remains available while the second master issues valid controls, allowing simultaneous Red action and Blue investigation.
