#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

if [[ ${EUID} -ne 0 ]]; then
  echo "Run this script as root: sudo bash deps.sh" >&2
  exit 1
fi

source /etc/os-release

if [[ "${ID:-}" == "ubuntu" ]] || [[ "${ID:-}" == "debian" ]]; then
  export DEBIAN_FRONTEND=noninteractive
  if command -v debconf-set-selections >/dev/null 2>&1; then
    echo 'wireshark-common wireshark-common/install-setuid boolean false' | debconf-set-selections
  fi
  apt-get update
  apt-get install -y --no-install-recommends \
    build-essential cmake curl ca-certificates libasio-dev \
    python3 tshark tcpdump jq nftables unzip
elif [[ "${ID:-}" == "arch" ]]; then
  pacman -S --noconfirm --needed base-devel cmake curl ca-certificates asio python wireshark-cli tcpdump jq nftables unzip
else
  echo "Unsupported OS for automatic dependency installation" >&2
  exit 1
fi

for command in cmake curl python3 tshark tcpdump jq nft; do
  command -v "$command" >/dev/null 2>&1 || { echo "Missing dependency after installation: $command" >&2; exit 1; }
done

echo "DEPENDENCIES_INSTALLED"
