#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
[[ ${EUID} -eq 0 ]] || { echo "Run as root: sudo $0 [AUTHORISED_MAINTENANCE_IPV4]" >&2; exit 1; }
ROOT=/opt/prabal-urja/scenario3
AUTHORIZED_MASTER="${1:-}"
[[ -d "$ROOT" ]] || { echo "Scenario 03 is not installed" >&2; exit 1; }
"$ROOT/tools/collect_evidence.sh"
if [[ -n "$AUTHORIZED_MASTER" ]]; then "$ROOT/tools/apply_hardening.sh" "$AUTHORIZED_MASTER"; else "$ROOT/tools/apply_hardening.sh"; fi
python3 "$ROOT/tools/operator_restore.py" --operator "Blue Team" --reason "Contain unauthorised DNP3 control and restore approved River Bend topology"
for _ in {1..20}; do state="$(jq -r '.scenario_state // empty' /var/lib/prabal-urja/scenario3/state.json 2>/dev/null || true)"; [[ "$state" == NORMAL_SWITCHING_CONFIGURATION ]] && break; sleep 1; done
jq . /var/lib/prabal-urja/scenario3/state.json
"$ROOT/tools/service_availability.sh"
echo "BLUE_CONTAINMENT:COMPLETE"
