# Blue Team Writeup — Scenario 3: Rogue DNP3 Master at River Bend Substation

## 1. Defensive objective

Detect and investigate unauthorised DNP3 switching at River Bend, contain the second master without interrupting the legitimate load-dispatch relationship, restore the approved breaker arrangement, preserve evidence and verify that telemetry and process control remain available.

The expected professional outcome is selective containment. Stopping every DNP3 service or powering down the RTU protects neither availability nor operational safety.

## 2. Starting operational baseline

### Authorised asset

| Field | Approved value |
|---|---|
| Asset | `PU-RB-RTU-07` |
| Site | River Bend 220/132 kV Substation |
| DNP3 outstation address | 10 |
| Authorised primary master address | 1 |
| Primary session | Local/control-centre path to TCP 20000 |
| Maintenance master address | 2, permitted only during an approved window |
| Approved switching | Feeder A closed, bus tie open, Feeder B closed |

### Normal process values

| Measurement | Approximate baseline |
|---|---:|
| Feeder A | 318 MW |
| Feeder B | 302 MW |
| Bus voltage | 218.7 kV |
| Transformer loading | 84.2% |
| Northern corridor loading | 78.6% |
| Frequency | 50.00 Hz |

### Core services

```bash
systemctl --no-pager --full status \
  prabal-dnp3-outstation.service \
  prabal-dnp3-master.service \
  prabal-riverbend-process.service \
  prabal-dnp3-command-monitor.service \
  prabal-riverbend-console.service
```

Validate the scenario before the exercise:

```bash
sudo /opt/prabal-urja/scenario3/tools/service_availability.sh
```

Expected result:

```text
SERVICE_STATUS:UP
```

## 3. Initial detection indicators

The incident may first appear as one or more of the following:

- bus-tie breaker unexpectedly changes from open to closed;
- Feeder A opens outside the approved switching schedule;
- Feeder B load rises toward 620 MW;
- transformer loading exceeds 95%;
- northern-corridor loading exceeds 90%;
- a second TCP session appears on the River Bend maintenance listener;
- DNP3 SELECT and OPERATE messages originate from a non-approved IP or master address;
- the accepted-operation counter increments without an operator work order.

Review the current process state:

```bash
curl -s http://127.0.0.1:8093/state | jq .
```

Open the operator display:

```text
http://<SCENARIO_3_IP>:8092/
```

Do not rely on the display alone. Correlate the process state, DNP3 traffic, system socket state and audit logs.

## 4. Preserve volatile evidence first

Record the current time and active sessions:

```bash
date -u
sudo ss -tnap | grep -E ':20000|:20001'
sudo ss -ltnp | grep -E ':20000|:20001|:8092|:8093|:8094'
```

Preserve system state without stopping services:

```bash
sudo /opt/prabal-urja/scenario3/tools/collect_evidence.sh
```

Record the resulting archive path. Do not run `reset.sh` until the incident timeline and containment evidence have been captured.

## 5. Identify the second DNP3 master

### Socket analysis

```bash
sudo ss -tnap '( sport = :20001 or dport = :20001 )'
```

The legitimate control-centre master is expected on the primary TCP 20000 relationship. A remote source connected to TCP 20001 outside an approved maintenance window is suspicious.

Capture the peer address:

```bash
sudo ss -tnp | awk '$4 ~ /:20001$/ || $5 ~ /:20001$/ {print}'
```

### Live protocol analysis

Because TCP 20001 is a retained non-default maintenance port, explicitly decode it as DNP3:

```bash
sudo tshark -n -i any \
  -d tcp.port==20001,dnp3 \
  -f 'tcp port 20000 or tcp port 20001' \
  -Y 'dnp3' \
  -T fields -E header=y -E separator='|' \
  -e frame.time -e ip.src -e ip.dst -e tcp.srcport -e tcp.dstport \
  -e dnp3.src -e dnp3.dst -e dnp3.al.func \
  -e dnp3.al.point_index -e dnp3.al.bocs -e dnp3.al.ctrlstatus
```

Interpret the key fields:

| Field | Defensive use |
|---|---|
| `ip.src` | Network origin of the master session |
| `dnp3.src` | DNP3 master link address |
| `dnp3.dst` | DNP3 outstation link address, expected 10 |
| `dnp3.al.func` | Application function such as SELECT or OPERATE |
| `dnp3.al.point_index` | Controlled binary-output index |
| `dnp3.al.bocs` | Control Relay Output Block operation |
| `dnp3.al.ctrlstatus` | Outstation command status |

Expected malicious sequence:

1. DNP3 integrity or class read from an unexpected network source;
2. SELECT for binary-output point 1 with close/latch-on control;
3. OPERATE for point 1;
4. SELECT for binary-output point 0 with open/latch-off control;
5. OPERATE for point 0.

## 6. Review protocol-aware audit evidence

The command monitor records observed controls independently of the operator display:

```bash
sudo jq . /var/log/prabal-urja/scenario3/dnp3-commands.jsonl
```

Filter accepted operations:

```bash
sudo jq -c 'select(.event=="DNP3_OPERATION_ACCEPTED")' \
  /var/log/prabal-urja/scenario3/dnp3-commands.jsonl
```

Summarise source IP, master address, function and point:

```bash
sudo jq -r '
  select(.event=="DNP3_OPERATION_ACCEPTED") |
  [.timestamp,.source_ip,.dnp3_master,.dnp3_outstation,.dnp3_function,.point,.desired_closed] |
  @tsv' /var/log/prabal-urja/scenario3/dnp3-commands.jsonl
```

A source master other than the approved control-centre relationship is an IOC even when the DNP3 command status is successful.

## 7. Reconstruct the process effect

Review process events:

```bash
sudo jq . /var/log/prabal-urja/scenario3/process-events.jsonl
```

Review the historian around the incident:

```bash
sudo column -s, -t < /var/log/prabal-urja/scenario3/process-historian.csv | tail -40
```

Or extract only the critical fields:

```bash
sudo awk -F, 'NR==1 || $2 != "NORMAL_SWITCHING_CONFIGURATION" || $10 >= 90' \
  /var/log/prabal-urja/scenario3/process-historian.csv
```

The expected timeline is:

| Stage | Breaker state | Process effect |
|---|---|---|
| Baseline | A closed, tie open, B closed | Split loading, normal margin |
| First command | A closed, tie closed, B closed | Buses paralleled, approximately 310 MW per feeder |
| Second command | A open, tie closed, B closed | Load transferred to Feeder B, overload alarms |

Confirm the authoritative state:

```bash
sudo jq '{scenario_state,breakers,metrics,alarms,last_command,rogue_master_ip}' \
  /var/lib/prabal-urja/scenario3/state.json
```

## 8. Validate that authorised polling remains healthy

The incident is not a DNP3 outage. Verify the legitimate master before containment:

```bash
systemctl is-active prabal-dnp3-master.service
sudo ss -tnp | grep '127.0.0.1:20000'
sudo journalctl -u prabal-dnp3-master.service --since '-10 minutes' --no-pager | tail -80
```

Verify the outstation and process:

```bash
systemctl is-active prabal-dnp3-outstation.service
curl -s http://127.0.0.1:8093/health | jq .
curl -s http://127.0.0.1:8092/api/health | jq .
```

This distinction is important: a valid but unauthorised command can coexist with healthy telemetry and service availability.

## 9. Containment

### Preferred containment: close the retained maintenance path

If no maintenance work is authorised:

```bash
sudo /opt/prabal-urja/scenario3/tools/apply_hardening.sh
sudo systemctl enable prabal-s03-hardening.service
```

This blocks non-loopback access to TCP 20001 while preserving the legitimate TCP 20000 session.

### Alternative containment: allow one approved maintenance master

When a documented maintenance host must remain connected:

```bash
sudo /opt/prabal-urja/scenario3/tools/apply_hardening.sh <AUTHORISED_MASTER_IP>
sudo systemctl enable prabal-s03-hardening.service
```

Inspect the resulting rules:

```bash
sudo nft list table inet prabal_s03
```

Confirm the suspicious session has terminated:

```bash
sudo ss -tnap '( sport = :20001 or dport = :20001 )'
```

Do not block loopback or TCP 20000, because the current package uses that relationship for the authorised master.

## 10. Safe restoration

The correct switching restoration order is:

1. close Feeder A;
2. verify Feeder A closed and carrying load;
3. open the bus tie;
4. verify normal split loading;
5. confirm alarms clear.

The package provides an authorised operator-restoration workflow that performs the safe state transition and records the operator and reason:

```bash
sudo /opt/prabal-urja/scenario3/tools/operator_restore.py \
  --operator "Ananya Rao" \
  --reason "Unauthorised DNP3 switching contained; restore approved River Bend topology"
```

Wait for process propagation:

```bash
sleep 5
```

Validate:

```bash
sudo jq '{scenario_state,breakers,metrics,alarms,last_restore}' \
  /var/lib/prabal-urja/scenario3/state.json
```

Expected result:

```text
Feeder A: closed
Bus tie: open
Feeder B: closed
Corridor loading: approximately 78.6%
Transformer loading: approximately 84.2%
Scenario state: NORMAL_SWITCHING_CONFIGURATION
```

## 11. Recovery validation

Run the full three-vector health check:

```bash
sudo /opt/prabal-urja/scenario3/tools/service_availability.sh
```

Confirm all systemd services:

```bash
systemctl is-active \
  prabal-dnp3-outstation.service \
  prabal-dnp3-master.service \
  prabal-riverbend-process.service \
  prabal-dnp3-command-monitor.service \
  prabal-riverbend-console.service \
  prabal-dnp3-capture.service
```

Confirm ports and sessions:

```bash
sudo ss -ltnp | grep -E ':20000|:20001|:8092|:8093|:8094'
sudo ss -tnp | grep '127.0.0.1:20000'
```

Confirm application health:

```bash
curl -fsS http://127.0.0.1:8093/health | jq .
curl -fsS http://127.0.0.1:8094/health | jq .
curl -fsS http://127.0.0.1:8092/api/health | jq .
```

## 12. Root-cause analysis

The primary findings are:

1. A retained DNP3 maintenance listener was reachable from a broad OT network.
2. DNP3 Secure Authentication or equivalent source authentication was absent.
3. The maintenance outstation responded to arbitrary DNP3 master addresses.
4. Network policy distinguished neither approved maintenance windows nor approved master sources.
5. Valid Select-Before-Operate commands were treated as authorised solely because they were protocol-correct.
6. Breaker controls lacked an independent operational approval or command allowlist.

## 13. Long-term remediation

- remove TCP 20001 when the maintenance path is not required;
- place maintenance access behind a controlled jump host and time-bound approval;
- restrict each DNP3 outstation to explicitly approved source IP and link-layer master address;
- implement DNP3 Secure Authentication where supported by all endpoints;
- alert on a second master session or master-address change;
- inspect DNP3 command semantics, not only service reachability;
- baseline SELECT, OPERATE and DIRECT_OPERATE activity;
- require switching-order correlation with approved operator work orders;
- retain packet capture and RTU sequence-of-events data with reliable time synchronisation;
- test recovery without disabling legitimate telemetry.

## 14. Detection logic examples

### Unexpected remote master on the maintenance port

```bash
sudo ss -tnH '( sport = :20001 or dport = :20001 )' \
  | awk '$4 !~ /^127\.0\.0\.1:/ && $5 !~ /^127\.0\.0\.1:/ {print}'
```

### DNP3 control functions in PCAP

```bash
sudo /opt/prabal-urja/scenario3/tools/pcap_dnp3_controls.sh
```

### Accepted operations from non-loopback sources

```bash
sudo jq -e '
  select(.event=="DNP3_OPERATION_ACCEPTED") |
  select(.source_ip!="127.0.0.1" and .source_ip!="::1")' \
  /var/log/prabal-urja/scenario3/dnp3-commands.jsonl
```

### Process and command correlation

```bash
sudo jq -s '
  map(select(.event=="DNP3_CONTROL_APPLIED")) |
  sort_by(.timestamp)' /var/log/prabal-urja/scenario3/process-events.jsonl
```

## 15. MITRE ATT&CK for ICS mapping

- T1692.001 — Unauthorized Message: Command Message
- T0831 — Manipulation of Control
- T0836 — Modify Parameter
- T0888 — Remote Services, where the retained telecontrol path is used remotely

## 16. Incident reporting

Complete the package reports:

- `Reports/INREP.md` for immediate notification;
- `Reports/SITREP.md` for the detailed operational update;
- `Reports/Red-Report.md` for the adversary finding and proof of control.

Attach:

- source IP and DNP3 master address;
- SELECT and OPERATE evidence;
- affected point indexes and breaker states;
- historian measurements before and after the transfer;
- containment rule output;
- post-restoration health validation;
- screenshots from the operator console and packet analysis.

## 17. Connection to Scenario 4

The investigation should conclude that protocol-correct commands can be dangerous even when sent through a healthy and trusted OT service. This becomes the investigative starting point for Scenario 4, where a legitimate control-centre utility and trusted source host are abused to generate IEC-104 commands. No Scenario 4 host or protocol is deployed here.
