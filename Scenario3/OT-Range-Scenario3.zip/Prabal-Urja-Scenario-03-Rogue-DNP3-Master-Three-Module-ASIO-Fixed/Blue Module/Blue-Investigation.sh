#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
ROOT=/opt/prabal-urja/scenario3
STATE=/var/lib/prabal-urja/scenario3/state.json
LOGROOT=/var/log/prabal-urja/scenario3
[[ -d "$ROOT" ]] || { echo "Scenario 03 is not installed" >&2; exit 1; }
echo "=== Current process state ==="; jq . "$STATE"
echo; echo "=== Recent DNP3 controls ==="; tail -n 30 "$LOGROOT/dnp3-commands.jsonl" 2>/dev/null | jq -c . 2>/dev/null || tail -n 30 "$LOGROOT/dnp3-commands.jsonl" 2>/dev/null || true
echo; echo "=== Recent process events ==="; tail -n 30 "$LOGROOT/process-events.jsonl" 2>/dev/null | jq -c . 2>/dev/null || tail -n 30 "$LOGROOT/process-events.jsonl" 2>/dev/null || true
echo; echo "=== DNP3 sockets ==="; ss -tnap | grep -E ':(20000|20001)\b' || true
echo; echo "=== Recent packet captures ==="; find "$LOGROOT/pcap" -maxdepth 1 -type f -name '*.pcap*' -printf '%TY-%Tm-%TdT%TH:%TM:%TSZ %s %p\n' 2>/dev/null | sort | tail -n 10 || true
echo; echo "=== Service availability ==="; "$ROOT/tools/service_availability.sh"
