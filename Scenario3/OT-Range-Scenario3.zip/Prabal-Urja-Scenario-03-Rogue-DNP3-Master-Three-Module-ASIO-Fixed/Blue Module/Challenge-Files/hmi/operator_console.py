#!/usr/bin/env python3
"""Read-only River Bend operator console served with Python's standard library."""
from __future__ import annotations

import json
import mimetypes
import os
import signal
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlparse

STATE_FILE = Path(os.environ.get("PRABAL_STATE_FILE", "/var/lib/prabal-urja/scenario3/state.json"))
EVENTS_FILE = Path(os.environ.get("PRABAL_EVENTS_FILE", "/var/log/prabal-urja/scenario3/process-events.jsonl"))
STATIC_DIR = Path(__file__).resolve().parent / "static"
BIND = os.environ.get("PRABAL_CONSOLE_BIND", "0.0.0.0")
PORT = int(os.environ.get("PRABAL_CONSOLE_PORT", "8092"))
STOP = threading.Event()
AUTHORITY_REGISTRY = Path(os.environ.get("PRABAL_AUTHORITY_REGISTRY", "/opt/prabal-urja/scenario3/config/control-authority.json"))
MASTER_RUNTIME = Path(os.environ.get("PRABAL_MASTER_RUNTIME", "/run/prabal-s03/master-identity.json"))


def read_state() -> dict[str, Any]:
    try:
        with STATE_FILE.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
            return value if isinstance(value, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError, json.JSONDecodeError):
        return {}


def control_authority() -> tuple[int, dict[str, Any]]:
    state = read_state()
    if not state.get("scenario_confirmed", False):
        return 200, {"status": "PENDING", "reason": "SWITCHING_INCIDENT_NOT_CONFIRMED"}
    registry = read_json(AUTHORITY_REGISTRY)
    observed = read_json(MASTER_RUNTIME)
    freshness = time.time() - float(observed.get("updated_epoch", 0) or 0)
    matches = (
        registry.get("outstation_asset") == state.get("asset_id")
        and registry.get("master_stack_name") == observed.get("master_stack_name")
        and registry.get("master_link_address") == observed.get("local_link_address")
        and registry.get("outstation_link_address") == observed.get("outstation_link_address")
        and 0 <= freshness <= 12
    )
    if not matches:
        return 503, {"status": "UNVERIFIED", "reason": "LIVE_MASTER_OR_ENGINEERING_RECORD_MISMATCH"}
    return 200, {
        "status": "VERIFIED",
        "source": "live_master_heartbeat_and_engineering_asset_register",
        "outstation": registry["outstation_asset"],
        "legitimate_master": observed["master_stack_name"],
        "master_link_address": observed["local_link_address"],
        "registered_control_authority": registry["registered_control_authority"],
        "engineering_group": registry["engineering_group"],
        "related_telecontrol_standard": registry["related_telecontrol_standard"],
        "handoff_scope": registry["handoff_scope"],
    }


def recent_events(limit: int = 30) -> list[dict[str, Any]]:
    if not EVENTS_FILE.exists():
        return []
    try:
        lines = EVENTS_FILE.read_text(encoding="utf-8", errors="replace").splitlines()[-limit:]
    except OSError:
        return []
    output: list[dict[str, Any]] = []
    for line in lines:
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        output.append({
            "timestamp": item.get("timestamp"),
            "event": item.get("event"),
            "point": item.get("point"),
            "desired_closed": item.get("desired_closed"),
            "source": item.get("source_ip") or item.get("requested_by"),
        })
    return output


class Handler(BaseHTTPRequestHandler):
    server_version = "PrabalRiverBendConsole/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        return

    def common_headers(self, content_type: str, length: int) -> None:
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(length))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self'; script-src 'self'; connect-src 'self'")

    def send_json(self, status: int, payload: Any) -> None:
        body = json.dumps(payload, sort_keys=True).encode("utf-8")
        self.send_response(status)
        self.common_headers("application/json; charset=utf-8", len(body))
        self.end_headers()
        self.wfile.write(body)

    def send_file(self, path: Path) -> None:
        try:
            resolved = path.resolve(strict=True)
            static_root = STATIC_DIR.resolve(strict=True)
            resolved.relative_to(static_root)
            data = resolved.read_bytes()
        except (OSError, ValueError):
            self.send_error(404)
            return
        content_type = mimetypes.guess_type(str(resolved))[0] or "application/octet-stream"
        if content_type.startswith("text/") or content_type in {"application/javascript", "application/json"}:
            content_type += "; charset=utf-8"
        self.send_response(200)
        self.common_headers(content_type, len(data))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        if path == "/":
            self.send_file(STATIC_DIR / "index.html")
            return
        # S03_ROOT_ROBOTS_ROUTE
        if path == "/robots.txt":
            from pathlib import Path
            try:
                body = (Path(__file__).resolve().parent / "static" / "robots.txt").read_bytes()
            except OSError:
                self.send_error(404)
                return
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if path.startswith("/static/"):
            relative = path.removeprefix("/static/")
            if not relative or "\x00" in relative:
                self.send_error(404)
                return
            self.send_file(STATIC_DIR / relative)
            return
        if path == "/api/control-authority":
            status, data = control_authority()
            self.send_json(status, data)
            return
        if path == "/api/state":
            state = read_state()
            self.send_json(200 if state else 503, state or {"error": "state unavailable"})
            return
        if path == "/api/events":
            self.send_json(200, {"events": recent_events()})
            return
        if path == "/api/health":
            state = read_state()
            heartbeat = int(state.get("heartbeat", 0) or 0)
            age = max(0, int(time.time()) - heartbeat) if heartbeat else 999999
            up = bool(state) and age <= 4
            self.send_json(200 if up else 503, {
                "status": "UP" if up else "DOWN",
                "component": "river-bend-operator-console",
                "process_current": age <= 4,
                "heartbeat_age_seconds": age,
                "scenario_state": state.get("scenario_state"),
            })
            return
        self.send_error(404)


def shutdown(_signum: int, _frame: Any) -> None:
    STOP.set()


def main() -> int:
    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)
    server = ThreadingHTTPServer((BIND, PORT), Handler)
    server.timeout = 0.5
    while not STOP.is_set():
        server.handle_request()
    server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
