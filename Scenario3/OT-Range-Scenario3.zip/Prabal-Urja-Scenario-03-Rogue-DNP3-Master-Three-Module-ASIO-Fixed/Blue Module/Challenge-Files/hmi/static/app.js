const $ = (id) => document.getElementById(id);
const fmt = (value, digits=1) => Number(value ?? 0).toFixed(digits);
const deviceName = (point) => ({0:"RB-FDR-A-52A",1:"RB-BT-52B",2:"RB-FDR-B-52C"}[point] ?? "Station Control");
const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (ch) => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[ch]));
function breaker(id, closed){const el=$(id);el.classList.toggle("closed",!!closed);el.classList.toggle("open",!closed);}
function setAlarm(name, active, detail, critical=false){if(!active)return "";return `<div class="alarm ${critical?'critical':''}"><strong>${name}</strong><span>${detail}</span></div>`;}
async function updateState(){
  try{
    const r=await fetch('/api/state',{cache:'no-store'}); if(!r.ok)throw new Error('state unavailable');
    const s=await r.json(), m=s.metrics||{}, b=s.breakers||{}, a=s.alarms||{};
    $('telemetry-status').textContent='TELEMETRY LIVE';$('telemetry-status').className='pill ok';
    $('bus-voltage').textContent=fmt(m.bus_voltage_kv,1);$('frequency').textContent=fmt(m.frequency_hz,2);
    $('transformer-loading').textContent=fmt(m.transformer_loading_pct,1);$('corridor-loading').textContent=fmt(m.corridor_loading_pct,1);
    $('feeder-a-mw').textContent=`${fmt(m.feeder_a_mw,0)} MW`;$('feeder-b-mw').textContent=`${fmt(m.feeder_b_mw,0)} MW`;
    $('scenario-state').textContent=(s.scenario_state||'UNKNOWN').replaceAll('_',' ');$('summary').textContent=s.operational_summary||'No current operator summary.';
    breaker('breaker-a',b.feeder_a_closed);breaker('breaker-tie',b.bus_tie_closed);breaker('breaker-b',b.feeder_b_closed);
    const alarms=[setAlarm('Northern Corridor Overload',a.corridor_overload,`${fmt(m.corridor_loading_pct,1)}% corridor loading`,true),setAlarm('Transformer Thermal Margin',a.transformer_overload,`${fmt(m.transformer_loading_pct,1)}% calculated loading`,true),setAlarm('River Bend Bus Undervoltage',a.low_bus_voltage,`${fmt(m.bus_voltage_kv,1)} kV measured`),setAlarm('Outgoing Load Loss',a.load_loss,'One or more scheduled loads are de-energised',true)].filter(Boolean);
    $('alarm-list').innerHTML=alarms.length?alarms.join(''):'<div class="empty">No active process alarms.</div>';
  }catch(e){$('telemetry-status').textContent='TELEMETRY LOST';$('telemetry-status').className='pill bad';}
}
async function updateEvents(){
  try{const r=await fetch('/api/events',{cache:'no-store'});const data=await r.json();const events=(data.events||[]).slice().reverse();
    $('events-body').innerHTML=events.length?events.map(e=>{const when=e.timestamp?new Date(e.timestamp).toLocaleTimeString('en-IN',{hour12:false,timeZone:'Asia/Kolkata'}):'--';const state=e.desired_closed===true?'CLOSE':e.desired_closed===false?'OPEN':'-';return `<tr><td>${escapeHtml(when)}</td><td>${escapeHtml(e.event||'-')}</td><td>${escapeHtml(deviceName(e.point))}</td><td>${escapeHtml(state)}</td><td>${escapeHtml(e.source||'-')}</td></tr>`;}).join(''):'<tr><td colspan="5">No operational events recorded.</td></tr>';
  }catch(e){}
}
function updateClock(){$('clock').textContent=new Date().toLocaleTimeString('en-IN',{hour12:false,timeZone:'Asia/Kolkata'})+' IST';}
updateState();updateEvents();updateClock();setInterval(updateState,2000);setInterval(updateEvents,3000);setInterval(updateClock,1000);

async function updateAuthority(){
  try {
    const response=await fetch('/api/control-authority',{cache:'no-store'});
    const data=await response.json();
    const panel=$('authority-panel');
    if(!response.ok||data.status!=='VERIFIED'){panel.hidden=true;return;}
    $('authority-rtu').textContent=data.outstation;
    $('authority-master').textContent=data.legitimate_master;
    $('authority-centre').textContent=data.registered_control_authority;
    $('authority-protocol').textContent=data.related_telecontrol_standard;
    panel.hidden=false;
  }catch(e){$('authority-panel').hidden=true;}
}
updateAuthority();setInterval(updateAuthority,5000);
