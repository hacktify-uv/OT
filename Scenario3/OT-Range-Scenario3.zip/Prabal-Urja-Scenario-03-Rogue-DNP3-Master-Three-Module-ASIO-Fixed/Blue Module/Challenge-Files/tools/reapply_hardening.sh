#!/usr/bin/env bash
set -Eeuo pipefail
ENV_FILE=/etc/prabal-urja/scenario3/hardening.env
[[ -f "$ENV_FILE" ]] || exit 0
# shellcheck disable=SC1090
source "$ENV_FILE"
exec /opt/prabal-urja/scenario3/tools/apply_hardening.sh "${AUTHORIZED_MASTER:-}"
