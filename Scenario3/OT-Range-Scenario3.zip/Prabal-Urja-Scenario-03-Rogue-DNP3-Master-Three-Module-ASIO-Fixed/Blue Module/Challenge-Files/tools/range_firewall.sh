#!/usr/bin/env bash
set -Eeuo pipefail
NFT=/usr/sbin/nft
command -v "$NFT" >/dev/null 2>&1 || NFT="$(command -v nft)"
"$NFT" delete table inet prabal_s03 2>/dev/null || true
"$NFT" -f - <<'NFTABLES'
table inet prabal_s03 {
  chain input {
    type filter hook input priority -10; policy accept;
    iifname != "lo" tcp dport 20000 drop comment "Primary DNP3 listener is control-centre local only"
  }
}
NFTABLES
