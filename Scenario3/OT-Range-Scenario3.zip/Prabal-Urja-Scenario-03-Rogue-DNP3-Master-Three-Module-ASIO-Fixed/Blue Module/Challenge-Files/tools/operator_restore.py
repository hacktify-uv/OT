#!/usr/bin/env python3
from __future__ import annotations
import argparse
import grp
import json
import os
import pwd
import tempfile
from datetime import datetime, timezone
from pathlib import Path

parser = argparse.ArgumentParser(description="Request an authorised River Bend switching restoration")
parser.add_argument("--operator", default="Ananya Rao")
parser.add_argument("--reason", default="Restore approved normal switching configuration")
args = parser.parse_args()
run_dir = Path(os.environ.get("PRABAL_RUN_DIR", "/run/prabal-s03"))
path = run_dir / "restore.request"
if not path.parent.exists(): path.parent.mkdir(parents=True, exist_ok=True)
payload = {"requested_by": args.operator, "reason": args.reason, "timestamp": datetime.now(timezone.utc).isoformat()}
fd, tmp = tempfile.mkstemp(prefix=".restore.", dir=path.parent)
with os.fdopen(fd, "w", encoding="utf-8") as handle:
    json.dump(payload, handle)
    handle.write("\n")
os.replace(tmp, path)
os.chmod(path, 0o640)
try:
    os.chown(
        path,
        pwd.getpwnam("prabal-s03").pw_uid,
        grp.getgrnam("prabal-s03").gr_gid,
    )
except (KeyError, PermissionError):
    # Non-installed developer tests may not have the service group.
    pass
print("RESTORE_REQUESTED")
