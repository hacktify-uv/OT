#!/usr/bin/env bash
set -Eeuo pipefail
umask 0027
PCAP_DIR=/var/log/prabal-urja/scenario3/pcap
mkdir -p "$PCAP_DIR"
closed_capture="${1:-}"
if [[ -n "$closed_capture" && -f "$closed_capture" ]]; then
  chown root:prabal-s03 "$closed_capture" 2>/dev/null || true
  chmod 0640 "$closed_capture" 2>/dev/null || true
fi
# Keep the rolling evidence window bounded while preserving the active file.
find "$PCAP_DIR" -maxdepth 1 -type f -name 'dnp3-*.pcap' -mmin +1440 -delete
