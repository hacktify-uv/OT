#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
DEST="${1:-/var/tmp/prabal-s03-evidence-${STAMP}}"
mkdir -p "$DEST"
cp -a /var/log/prabal-urja/scenario3 "$DEST/logs" 2>/dev/null || true
cp -a /var/lib/prabal-urja/scenario3/state.json "$DEST/state.json" 2>/dev/null || true
journalctl -u prabal-dnp3-outstation -u prabal-dnp3-master -u prabal-dnp3-command-monitor \
  -u prabal-riverbend-process -u prabal-riverbend-console --no-pager > "$DEST/systemd-journal.txt"
ss -tnap > "$DEST/socket-state.txt"
/usr/sbin/nft list table inet prabal_s03 > "$DEST/firewall.txt" 2>&1 || true
(cd "$DEST" && find . -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 -r sha256sum > SHA256SUMS)
tar -C "$(dirname "$DEST")" -czf "${DEST}.tar.gz" "$(basename "$DEST")"
echo "EVIDENCE_ARCHIVE:${DEST}.tar.gz"
