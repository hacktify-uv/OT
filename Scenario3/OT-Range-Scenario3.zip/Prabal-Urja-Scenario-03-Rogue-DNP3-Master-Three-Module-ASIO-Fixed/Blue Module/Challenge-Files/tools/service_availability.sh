#!/usr/bin/env bash
set -u
ROOT=/opt/prabal-urja/scenario3
fail=0
summary=()
check_active(){ local unit="$1"; if [[ "$(systemctl is-active "$unit" 2>/dev/null)" == active ]]; then summary+=("${unit}:SYSTEMD_UP"); else summary+=("${unit}:SYSTEMD_DOWN"); fail=1; fi; }
check_port(){ local port="$1" label="$2"; if ss -ltn 2>/dev/null | awk '{print $4}' | grep -Eq "(^|:)${port}$"; then summary+=("${label}:PORT_${port}_UP"); else summary+=("${label}:PORT_${port}_DOWN"); fail=1; fi; }

check_active prabal-dnp3-outstation.service
check_port 20000 DNP3_PRIMARY
check_port 20001 DNP3_MAINTENANCE
DNP3_OUTPUT="$(timeout 20 "$ROOT/bin/prabal-dnp3-command" --host 127.0.0.1 --port 20001 --master 2 --outstation 10 --action scan 2>&1 || true)"
if grep -q 'SCAN_COMPLETED' <<<"$DNP3_OUTPUT"; then summary+=("DNP3:PROTOCOL_PROBE_UP"); else summary+=("DNP3:PROTOCOL_PROBE_DOWN"); fail=1; fi

check_active prabal-riverbend-process.service
check_port 8093 PROCESS_API
PROCESS_JSON="$(curl -fsS --max-time 5 http://127.0.0.1:8093/health 2>/dev/null || true)"
if jq -e '.status=="UP" and .heartbeat_age_seconds <= 3' >/dev/null 2>&1 <<<"$PROCESS_JSON"; then summary+=("PROCESS:FUNCTIONAL_PROBE_UP"); else summary+=("PROCESS:FUNCTIONAL_PROBE_DOWN"); fail=1; fi

check_active prabal-dnp3-command-monitor.service
check_port 8094 COMMAND_MONITOR
MONITOR_JSON="$(curl -fsS --max-time 5 http://127.0.0.1:8094/health 2>/dev/null || true)"
if jq -e '.status=="UP" and .tshark_alive==true' >/dev/null 2>&1 <<<"$MONITOR_JSON"; then summary+=("MONITOR:FUNCTIONAL_PROBE_UP"); else summary+=("MONITOR:FUNCTIONAL_PROBE_DOWN"); fail=1; fi

check_active prabal-riverbend-console.service
check_port 8092 OPERATOR_CONSOLE
CONSOLE_JSON="$(curl -fsS --max-time 5 http://127.0.0.1:8092/api/health 2>/dev/null || true)"
if jq -e '.status=="UP" and .process_current==true' >/dev/null 2>&1 <<<"$CONSOLE_JSON"; then summary+=("CONSOLE:FUNCTIONAL_PROBE_UP"); else summary+=("CONSOLE:FUNCTIONAL_PROBE_DOWN"); fail=1; fi

check_active prabal-dnp3-master.service
if ss -tn state established 2>/dev/null | grep -Eq '127\.0\.0\.1:20000'; then summary+=("LEGITIMATE_MASTER:SOCKET_UP"); else summary+=("LEGITIMATE_MASTER:SOCKET_DOWN"); fail=1; fi
if journalctl -u prabal-dnp3-master.service --since '-5 minutes' --no-pager 2>/dev/null | grep -q 'LEGITIMATE_MASTER_DATA'; then summary+=("LEGITIMATE_MASTER:FUNCTIONAL_PROBE_UP"); else summary+=("LEGITIMATE_MASTER:FUNCTIONAL_PROBE_DOWN"); fail=1; fi

if [[ $fail -eq 0 ]]; then
  echo "SERVICE_STATUS:UP | $(IFS=' | '; echo "${summary[*]}")"
  exit 0
fi
echo "SERVICE_STATUS:DOWN | $(IFS=' | '; echo "${summary[*]}")"
exit 1
