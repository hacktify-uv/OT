#!/usr/bin/env bash
set -Eeuo pipefail
HOST="${1:-127.0.0.1}"
PORT="${2:-20001}"
MASTER="${3:-2}"
exec /opt/prabal-urja/scenario3/bin/prabal-dnp3-command --host "$HOST" --port "$PORT" --master "$MASTER" --outstation 10 --action scan
