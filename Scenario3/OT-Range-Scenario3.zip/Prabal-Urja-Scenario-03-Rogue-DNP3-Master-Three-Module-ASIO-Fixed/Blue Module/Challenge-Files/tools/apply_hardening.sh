#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
AUTHORIZED_MASTER="${1:-}"
CONFIG_DIR=/etc/prabal-urja/scenario3
ENV_FILE="$CONFIG_DIR/hardening.env"
mkdir -p "$CONFIG_DIR"

if [[ -n "$AUTHORIZED_MASTER" ]]; then
  python3 - "$AUTHORIZED_MASTER" <<'PY_VALIDATE_IP' || {
import ipaddress
import sys
value = ipaddress.ip_address(sys.argv[1])
if value.version != 4:
    raise SystemExit(1)
PY_VALIDATE_IP
    echo "Usage: $0 [AUTHORISED_DNP3_MASTER_IPV4]" >&2
    exit 2
  }
fi

cat > "$ENV_FILE" <<ENV
AUTHORIZED_MASTER=${AUTHORIZED_MASTER}
ENV
chmod 0600 "$ENV_FILE"

/usr/sbin/nft delete table inet prabal_s03 2>/dev/null || true
if [[ -n "$AUTHORIZED_MASTER" ]]; then
  /usr/sbin/nft -f - <<NFTABLES
table inet prabal_s03 {
  chain input {
    type filter hook input priority -10; policy accept;
    iifname != "lo" tcp dport 20000 drop comment "Primary DNP3 listener restricted"
    ip saddr ${AUTHORIZED_MASTER} tcp dport 20001 accept comment "Authorised maintenance master"
    iifname != "lo" tcp dport 20001 drop comment "Reject unapproved DNP3 masters"
  }
}
NFTABLES
  echo "Hardening applied: TCP/20001 limited to ${AUTHORIZED_MASTER}; loopback remains available."
else
  /usr/sbin/nft -f - <<'NFTABLES'
table inet prabal_s03 {
  chain input {
    type filter hook input priority -10; policy accept;
    iifname != "lo" tcp dport { 20000, 20001 } drop comment "Close DNP3 listeners to remote masters"
  }
}
NFTABLES
  echo "Hardening applied: legacy maintenance listener closed to non-loopback sources."
fi
