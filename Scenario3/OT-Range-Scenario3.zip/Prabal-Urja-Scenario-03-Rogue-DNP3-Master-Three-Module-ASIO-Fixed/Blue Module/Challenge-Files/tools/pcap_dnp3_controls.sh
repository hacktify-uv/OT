#!/usr/bin/env bash
set -Eeuo pipefail
PCAP="${1:-$(ls -1t /var/log/prabal-urja/scenario3/pcap/*.pcap* 2>/dev/null | head -n1)}"
[[ -n "$PCAP" && -f "$PCAP" ]] || { echo "No DNP3 capture found" >&2; exit 1; }
tshark -n -d tcp.port==20001,dnp3 -r "$PCAP" \
  -Y 'dnp3.al.func == 3 || dnp3.al.func == 4 || dnp3.al.func == 5 || dnp3.al.func == 6' \
  -T fields -E header=y -E separator='|' \
  -e frame.time -e ip.src -e tcp.dstport -e dnp3.src -e dnp3.dst \
  -e dnp3.al.func -e dnp3.al.point_index -e dnp3.al.bocs -e dnp3.al.ctrlstatus
