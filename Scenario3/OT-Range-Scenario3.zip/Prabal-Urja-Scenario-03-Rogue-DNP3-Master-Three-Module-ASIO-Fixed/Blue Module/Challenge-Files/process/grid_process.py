#!/usr/bin/env python3
"""River Bend substation process model for Prabal Urja Scenario 03.

The model consumes accepted DNP3 OPERATE events emitted by the native
OpenDNP3 command handler. Network captures provide independent audit only. It exposes process health and state, produces the RTU point
file read by the native OpenDNP3 outstation, and preserves a detailed historian.
"""
from __future__ import annotations

import csv
import json
import os
import signal
import tempfile
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

RUN_DIR = Path(os.environ.get("PRABAL_RUN_DIR", "/run/prabal-s03"))
VAR_DIR = Path(os.environ.get("PRABAL_VAR_DIR", "/var/lib/prabal-urja/scenario3"))
LOG_DIR = Path(os.environ.get("PRABAL_LOG_DIR", "/var/log/prabal-urja/scenario3"))
COMMANDS_FILE = RUN_DIR / "accepted-commands.jsonl"
RTU_CSV = RUN_DIR / "rtu_state.csv"
STATE_FILE = VAR_DIR / "state.json"
INITIAL_FILE = Path(os.environ.get("PRABAL_INITIAL_STATE", "/opt/prabal-urja/scenario3/config/initial-state.json"))
RESTORE_REQUEST = RUN_DIR / "restore.request"
HISTORIAN = LOG_DIR / "process-historian.csv"
EVENTS = LOG_DIR / "process-events.jsonl"
HEALTH_HOST = os.environ.get("PRABAL_PROCESS_BIND", "0.0.0.0")
HEALTH_PORT = int(os.environ.get("PRABAL_PROCESS_PORT", "8093"))

STOP = threading.Event()
STATE_LOCK = threading.RLock()
STATE: dict[str, Any] = {}
LAST_COMMAND_OFFSET = 0
ROGUE_TIE_CLOSE_AT: float | None = None


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def atomic_json(path: Path, value: Any) -> None:
    if not path.parent.exists(): path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def atomic_text(path: Path, value: str) -> None:
    if not path.parent.exists(): path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(value)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def read_initial() -> dict[str, Any]:
    with INITIAL_FILE.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def load_state() -> dict[str, Any]:
    if STATE_FILE.exists():
        try:
            with STATE_FILE.open("r", encoding="utf-8") as handle:
                state = json.load(handle)
                if isinstance(state, dict):
                    return state
        except (OSError, json.JSONDecodeError):
            pass
    return read_initial()


def process_metrics(state: dict[str, Any]) -> None:
    a = bool(state["breakers"]["feeder_a_closed"])
    b = bool(state["breakers"]["feeder_b_closed"])
    tie = bool(state["breakers"]["bus_tie_closed"])

    if a and b and not tie:
        metrics = {
            "feeder_a_mw": 318.0,
            "feeder_b_mw": 302.0,
            "bus_voltage_kv": 218.7,
            "transformer_loading_pct": 84.2,
            "corridor_loading_pct": 78.6,
            "frequency_hz": 50.00,
        }
        state["scenario_state"] = "NORMAL_SWITCHING_CONFIGURATION"
        state["operational_summary"] = "Both feeders are carrying scheduled load; bus tie remains open."
    elif a and b and tie:
        metrics = {
            "feeder_a_mw": 310.0,
            "feeder_b_mw": 310.0,
            "bus_voltage_kv": 219.1,
            "transformer_loading_pct": 84.5,
            "corridor_loading_pct": 79.0,
            "frequency_hz": 50.00,
        }
        state["scenario_state"] = "PARALLEL_BUS_CONFIGURATION"
        state["operational_summary"] = "Bus sections are paralleled while both feeders remain closed."
    elif not a and b and tie:
        metrics = {
            "feeder_a_mw": 0.0,
            "feeder_b_mw": 620.0,
            "bus_voltage_kv": 215.8,
            "transformer_loading_pct": 101.4,
            "corridor_loading_pct": 96.8,
            "frequency_hz": 49.94,
        }
        if state.get("scenario_confirmed"):
            state["scenario_state"] = "ROGUE_MASTER_SWITCHING_CONFIRMED"
        else:
            state["scenario_state"] = "LOAD_TRANSFER_STRESSED"
        state["operational_summary"] = "Feeder A is open; Feeder B is carrying the transferred River Bend load."
    elif a and not b and tie:
        metrics = {
            "feeder_a_mw": 620.0,
            "feeder_b_mw": 0.0,
            "bus_voltage_kv": 215.6,
            "transformer_loading_pct": 101.6,
            "corridor_loading_pct": 97.1,
            "frequency_hz": 49.93,
        }
        state["scenario_state"] = "REVERSE_LOAD_TRANSFER_STRESSED"
        state["operational_summary"] = "Feeder B is open; Feeder A is carrying the transferred River Bend load."
    elif not a and b and not tie:
        metrics = {
            "feeder_a_mw": 0.0,
            "feeder_b_mw": 302.0,
            "bus_voltage_kv": 209.0,
            "transformer_loading_pct": 71.2,
            "corridor_loading_pct": 63.5,
            "frequency_hz": 49.82,
        }
        state["scenario_state"] = "FEEDER_A_LOAD_LOSS"
        state["operational_summary"] = "Feeder A load is de-energised because the bus tie is open."
    elif a and not b and not tie:
        metrics = {
            "feeder_a_mw": 318.0,
            "feeder_b_mw": 0.0,
            "bus_voltage_kv": 208.6,
            "transformer_loading_pct": 72.0,
            "corridor_loading_pct": 64.1,
            "frequency_hz": 49.81,
        }
        state["scenario_state"] = "FEEDER_B_LOAD_LOSS"
        state["operational_summary"] = "Feeder B load is de-energised because the bus tie is open."
    else:
        metrics = {
            "feeder_a_mw": 0.0,
            "feeder_b_mw": 0.0,
            "bus_voltage_kv": 0.0,
            "transformer_loading_pct": 0.0,
            "corridor_loading_pct": 0.0,
            "frequency_hz": 0.0,
        }
        state["scenario_state"] = "RIVER_BEND_DEENERGISED"
        state["operational_summary"] = "Both outgoing feeders are open."

    state["metrics"] = metrics
    state["alarms"] = {
        "corridor_overload": metrics["corridor_loading_pct"] >= 90.0,
        "transformer_overload": metrics["transformer_loading_pct"] >= 95.0,
        "low_bus_voltage": 0.0 < metrics["bus_voltage_kv"] < 213.0,
        "load_loss": "LOAD_LOSS" in state["scenario_state"] or state["scenario_state"] == "RIVER_BEND_DEENERGISED",
    }
    state["updated_at"] = utc_now()
    state["heartbeat"] = int(time.time())


def append_jsonl(path: Path, record: dict[str, Any]) -> None:
    if not path.parent.exists(): path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, sort_keys=True) + "\n")


def write_historian_header() -> None:
    if HISTORIAN.exists() and HISTORIAN.stat().st_size > 0:
        return
    if not HISTORIAN.parent.exists(): HISTORIAN.parent.mkdir(parents=True, exist_ok=True)
    with HISTORIAN.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "timestamp", "scenario_state", "feeder_a_closed", "bus_tie_closed",
            "feeder_b_closed", "feeder_a_mw", "feeder_b_mw", "bus_voltage_kv",
            "transformer_loading_pct", "corridor_loading_pct", "frequency_hz",
            "accepted_operations", "last_command_source"
        ])


def persist_state(write_history: bool = True) -> None:
    process_metrics(STATE)
    atomic_json(STATE_FILE, STATE)
    b = STATE["breakers"]
    m = STATE["metrics"]
    csv_line = ",".join([
        "1" if b["feeder_a_closed"] else "0",
        "1" if b["bus_tie_closed"] else "0",
        "1" if b["feeder_b_closed"] else "0",
        "1" if STATE.get("remote_control_enabled", True) else "0",
        "1" if STATE["alarms"]["corridor_overload"] else "0",
        "1" if STATE.get("command_lockout", False) else "0",
        f"{m['feeder_a_mw']:.2f}", f"{m['feeder_b_mw']:.2f}",
        f"{m['bus_voltage_kv']:.2f}", f"{m['transformer_loading_pct']:.2f}",
        f"{m['corridor_loading_pct']:.2f}", f"{m['frequency_hz']:.3f}",
        str(int(STATE.get("accepted_operations", 0))),
    ]) + "\n"
    atomic_text(RTU_CSV, csv_line)

    if write_history:
        write_historian_header()
        with HISTORIAN.open("a", newline="", encoding="utf-8") as handle:
            csv.writer(handle).writerow([
                STATE["updated_at"], STATE["scenario_state"], int(b["feeder_a_closed"]),
                int(b["bus_tie_closed"]), int(b["feeder_b_closed"]),
                m["feeder_a_mw"], m["feeder_b_mw"], m["bus_voltage_kv"],
                m["transformer_loading_pct"], m["corridor_loading_pct"],
                m["frequency_hz"], STATE.get("accepted_operations", 0),
                STATE.get("last_command_source", "none"),
            ])


def apply_command(command: dict[str, Any]) -> None:
    global ROGUE_TIE_CLOSE_AT
    point = int(command.get("point", -1))
    desired = bool(command.get("desired_closed"))
    if command.get("execute_origin") != "native_opendnp3_handler":
        append_jsonl(EVENTS, {"timestamp": utc_now(), "event": "COMMAND_REJECTED_INVALID_ORIGIN", **command})
        return
    source_channel = str(command.get("source_channel", "unknown"))
    if source_channel != "maintenance":
        append_jsonl(EVENTS, {"timestamp": utc_now(), "event": "COMMAND_REJECTED_WRONG_CHANNEL", **command})
        return
    # The native ICommandHandler does not expose the peer's IP. Do not fabricate it.
    source_ip = str(command.get("source_ip") or "unattributed")
    authorised = False

    if STATE.get("command_lockout", False):
        append_jsonl(EVENTS, {"timestamp": utc_now(), "event": "COMMAND_REJECTED_LOCKOUT", **command})
        return
    if not STATE.get("remote_control_enabled", True):
        append_jsonl(EVENTS, {"timestamp": utc_now(), "event": "COMMAND_REJECTED_REMOTE_DISABLED", **command})
        return

    mapping = {0: "feeder_a_closed", 1: "bus_tie_closed", 2: "feeder_b_closed"}
    if point not in mapping:
        append_jsonl(EVENTS, {"timestamp": utc_now(), "event": "COMMAND_REJECTED_BAD_POINT", **command})
        return

    STATE["breakers"][mapping[point]] = desired
    STATE["accepted_operations"] = int(STATE.get("accepted_operations", 0)) + 1
    STATE["last_command_source"] = "DNP3_MAINTENANCE_CHANNEL"
    STATE["last_command"] = {
        "timestamp": utc_now(), "source_ip": source_ip, "source_channel": source_channel, "point": point,
        "desired_closed": desired, "dnp3_master": command.get("dnp3_master"),
        "dnp3_function": command.get("dnp3_function"), "authorised_source": authorised,
    }

    now = time.time()
    if not authorised and point == 1 and desired:
        ROGUE_TIE_CLOSE_AT = now
    if not authorised and point == 0 and not desired and ROGUE_TIE_CLOSE_AT and now - ROGUE_TIE_CLOSE_AT <= 180:
        STATE["scenario_confirmed"] = True
        STATE["scenario_confirmed_at"] = utc_now()
        STATE["rogue_master_ip"] = None  # Check packet capture for observed peer IP.
        STATE["rogue_master_channel"] = source_channel

    append_jsonl(EVENTS, {"timestamp": utc_now(), "event": "DNP3_CONTROL_APPLIED", **command})
    persist_state(write_history=True)


def consume_commands() -> None:
    global LAST_COMMAND_OFFSET
    if not COMMANDS_FILE.parent.exists(): COMMANDS_FILE.parent.mkdir(parents=True, exist_ok=True)
    COMMANDS_FILE.touch(exist_ok=True)
    LAST_COMMAND_OFFSET = COMMANDS_FILE.stat().st_size
    while not STOP.wait(0.25):
        try:
            size = COMMANDS_FILE.stat().st_size
            if size < LAST_COMMAND_OFFSET:
                LAST_COMMAND_OFFSET = 0
            if size == LAST_COMMAND_OFFSET:
                continue
            with COMMANDS_FILE.open("r", encoding="utf-8") as handle:
                handle.seek(LAST_COMMAND_OFFSET)
                while True:
                    line = handle.readline()
                    if not line:
                        break
                    if not line.endswith("\n"):
                        break  # Wait for a complete JSONL event before advancing the cursor.
                    LAST_COMMAND_OFFSET = handle.tell()
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        command = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    with STATE_LOCK:
                        apply_command(command)
        except OSError:
            time.sleep(0.5)


def handle_restore() -> None:
    global STATE, ROGUE_TIE_CLOSE_AT
    try:
        request = json.loads(RESTORE_REQUEST.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        request = {"requested_by": "operator"}
    STATE = read_initial()
    STATE["last_restore"] = {"timestamp": utc_now(), **request}
    ROGUE_TIE_CLOSE_AT = None
    append_jsonl(EVENTS, {"timestamp": utc_now(), "event": "OPERATOR_RESTORE", **request})
    persist_state(write_history=True)
    RESTORE_REQUEST.unlink(missing_ok=True)


def heartbeat_loop() -> None:
    while not STOP.wait(1.0):
        with STATE_LOCK:
            if RESTORE_REQUEST.exists():
                handle_restore()
            persist_state(write_history=False)
            if int(time.time()) % 5 == 0:
                persist_state(write_history=True)


class ApiHandler(BaseHTTPRequestHandler):
    server_version = "PrabalRiverBendProcess/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        return

    def send_json(self, status: int, payload: Any) -> None:
        body = json.dumps(payload, sort_keys=True).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:  # noqa: N802
        with STATE_LOCK:
            snapshot = json.loads(json.dumps(STATE))
        if self.path == "/health":
            age = max(0, int(time.time()) - int(snapshot.get("heartbeat", 0)))
            self.send_json(200 if age <= 3 else 503, {
                "status": "UP" if age <= 3 else "DOWN",
                "component": "river-bend-process",
                "heartbeat_age_seconds": age,
                "scenario_state": snapshot.get("scenario_state"),
                "rtu_state_file": str(RTU_CSV),
            })
        elif self.path == "/state":
            self.send_json(200, snapshot)
        else:
            self.send_json(404, {"error": "not found"})


def shutdown(_signum: int, _frame: Any) -> None:
    STOP.set()


def main() -> int:
    global STATE
    for path in (RUN_DIR, VAR_DIR, LOG_DIR):
        if not path.exists(): path.mkdir(parents=True, exist_ok=True)
    STATE = load_state()
    STATE.setdefault("breakers", {"feeder_a_closed": True, "bus_tie_closed": False, "feeder_b_closed": True})
    STATE.setdefault("accepted_operations", 0)
    STATE.setdefault("remote_control_enabled", True)
    STATE.setdefault("command_lockout", False)
    STATE.setdefault("scenario_confirmed", False)
    persist_state(write_history=True)

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)
    threading.Thread(target=consume_commands, name="dnp3-command-consumer", daemon=True).start()
    threading.Thread(target=heartbeat_loop, name="process-heartbeat", daemon=True).start()

    server = ThreadingHTTPServer((HEALTH_HOST, HEALTH_PORT), ApiHandler)
    server.timeout = 0.5
    while not STOP.is_set():
        server.handle_request()
    server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
