#!/usr/bin/env python3
"""Observe DNP3 traffic for evidence only; never execute breaker controls."""
from __future__ import annotations

import json
import os
import signal
import subprocess
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

RUN_DIR = Path(os.environ.get("PRABAL_RUN_DIR", "/run/prabal-s03"))
LOG_DIR = Path(os.environ.get("PRABAL_LOG_DIR", "/var/log/prabal-urja/scenario3"))
COMMANDS_FILE = RUN_DIR / "accepted-commands.jsonl"
AUDIT_FILE = LOG_DIR / "dnp3-commands.jsonl"
HEALTH_HOST = os.environ.get("PRABAL_MONITOR_BIND", "0.0.0.0")
HEALTH_PORT = int(os.environ.get("PRABAL_MONITOR_PORT", "8094"))
STOP = threading.Event()
LOCK = threading.RLock()
PROCESS: subprocess.Popen[str] | None = None
SELECTS: dict[tuple[str, str, int], dict[str, Any]] = {}
HEALTH: dict[str, Any] = {
    "status": "STARTING", "tshark_alive": False, "last_packet_at": None,
    "last_control_at": None, "observed_control_frames": 0, "accepted_operations": 0,
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def append_jsonl(path: Path, record: dict[str, Any]) -> None:
    if not path.parent.exists(): path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, sort_keys=True) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def first(value: str) -> str:
    return value.split(",", 1)[0].strip()


def parse_int(value: str, default: int = -1) -> int:
    text = first(value)
    try:
        return int(text, 0)
    except (TypeError, ValueError):
        try:
            return int(float(text))
        except (TypeError, ValueError):
            return default


def desired_closed(raw: str) -> bool | None:
    text = first(raw).strip().lower()
    if not text:
        return None
    if text in {"true", "yes", "set"}:
        return True
    if text in {"false", "no", "unset"}:
        return False
    if any(token in text for token in ("latch_on", "close", "closed")):
        return True
    if any(token in text for token in ("latch_off", "trip", "open")):
        return False
    numeric = parse_int(text, -1)
    if numeric == 1:
        return True
    if numeric == 0:
        return False
    # DNP3 control-code low nibble: 3=LATCH_ON, 4=LATCH_OFF.
    if numeric & 0x0F == 3:
        return True
    if numeric & 0x0F == 4:
        return False
    return None


def purge_selects(now: float) -> None:
    expired = [key for key, value in SELECTS.items() if now - float(value["epoch"]) > 15]
    for key in expired:
        SELECTS.pop(key, None)


def process_record(line: str) -> None:
    fields = line.rstrip("\n").split("|")
    if len(fields) < 10:
        return
    epoch_raw, source_ip, destination_port, dnp3_src, dnp3_dst, function_raw, object_raw, point_raw, bocs_raw, status_raw = fields[:10]
    function = parse_int(function_raw)
    point = parse_int(point_raw)
    if function not in {3, 4, 5, 6} or point < 0:
        return
    try:
        epoch = float(first(epoch_raw))
    except ValueError:
        epoch = time.time()
    state = desired_closed(bocs_raw)
    if state is None:
        return

    record = {
        "timestamp": utc_now(), "epoch": epoch, "source_ip": first(source_ip) or "unknown",
        "destination_port": parse_int(destination_port), "dnp3_master": parse_int(dnp3_src),
        "dnp3_outstation": parse_int(dnp3_dst), "dnp3_function": function,
        "object": first(object_raw), "point": point, "desired_closed": state,
        "control_status": first(status_raw),
    }
    now = time.time()
    key = (record["source_ip"], str(record["dnp3_master"]), point)
    with LOCK:
        purge_selects(now)
        HEALTH["last_packet_at"] = record["timestamp"]
        HEALTH["last_control_at"] = record["timestamp"]
        HEALTH["observed_control_frames"] = int(HEALTH["observed_control_frames"]) + 1

        if function == 3:  # SELECT
            SELECTS[key] = {"epoch": epoch, "desired_closed": state}
            append_jsonl(AUDIT_FILE, {"event": "DNP3_SELECT_OBSERVED", **record})
            return

        # A packet tap cannot know whether the RTU actually executed the control.
        # Execution events are issued only by native OpenDNP3 ICommandHandler.
        SELECTS.pop(key, None)
        append_jsonl(AUDIT_FILE, {"event": "DNP3_OPERATION_OBSERVED_UNVERIFIED", **record})


def monitor_loop() -> None:
    global PROCESS
    command = [
        "tshark", "-l", "-n", "-i", "any", "-d", "tcp.port==20001,dnp3",
        "-f", "tcp port 20000 or tcp port 20001",
        "-Y", "(dnp3.al.func == 3 || dnp3.al.func == 4 || dnp3.al.func == 5 || dnp3.al.func == 6) && dnp3.al.point_index",
        "-T", "fields", "-E", "separator=|", "-E", "occurrence=f",
        "-e", "frame.time_epoch", "-e", "ip.src", "-e", "tcp.dstport",
        "-e", "dnp3.src", "-e", "dnp3.dst", "-e", "dnp3.al.func",
        "-e", "dnp3.al.obj", "-e", "dnp3.al.point_index", "-e", "dnp3.al.bocs",
        "-e", "dnp3.al.ctrlstatus",
    ]
    while not STOP.is_set():
        try:
            PROCESS = subprocess.Popen(
                command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                text=True, bufsize=1,
            )
            with LOCK:
                HEALTH["status"] = "UP"
                HEALTH["tshark_alive"] = True
            assert PROCESS.stdout is not None
            for line in PROCESS.stdout:
                if STOP.is_set():
                    break
                process_record(line)
            return_code = PROCESS.poll()
            with LOCK:
                HEALTH["tshark_alive"] = False
                HEALTH["status"] = "DOWN"
                HEALTH["last_error"] = f"tshark exited with {return_code}"
        except (OSError, subprocess.SubprocessError) as exc:
            with LOCK:
                HEALTH["tshark_alive"] = False
                HEALTH["status"] = "DOWN"
                HEALTH["last_error"] = str(exc)
        if not STOP.wait(2):
            continue


class Handler(BaseHTTPRequestHandler):
    server_version = "PrabalDNP3Monitor/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        return

    def do_GET(self) -> None:  # noqa: N802
        if self.path != "/health":
            self.send_response(404)
            self.end_headers()
            return
        with LOCK:
            snapshot = dict(HEALTH)
            alive = bool(PROCESS and PROCESS.poll() is None)
            snapshot["tshark_alive"] = alive
            snapshot["status"] = "UP" if alive else "DOWN"
        body = json.dumps(snapshot, sort_keys=True).encode("utf-8")
        self.send_response(200 if alive else 503)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)


def shutdown(_signum: int, _frame: Any) -> None:
    STOP.set()
    if PROCESS and PROCESS.poll() is None:
        PROCESS.terminate()


def main() -> int:
    if not RUN_DIR.exists(): RUN_DIR.mkdir(parents=True, exist_ok=True)
    if not LOG_DIR.exists(): LOG_DIR.mkdir(parents=True, exist_ok=True)
    COMMANDS_FILE.touch(exist_ok=True)
    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)
    threading.Thread(target=monitor_loop, name="tshark-monitor", daemon=True).start()
    server = ThreadingHTTPServer((HEALTH_HOST, HEALTH_PORT), Handler)
    server.timeout = 0.5
    while not STOP.is_set():
        server.handle_request()
    server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
