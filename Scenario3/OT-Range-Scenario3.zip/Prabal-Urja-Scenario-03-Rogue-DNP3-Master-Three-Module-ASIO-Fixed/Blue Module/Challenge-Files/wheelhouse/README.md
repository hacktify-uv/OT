No Python wheels are required for Scenario 03. The process model, command monitor and operator console use only the Ubuntu Python standard library.
