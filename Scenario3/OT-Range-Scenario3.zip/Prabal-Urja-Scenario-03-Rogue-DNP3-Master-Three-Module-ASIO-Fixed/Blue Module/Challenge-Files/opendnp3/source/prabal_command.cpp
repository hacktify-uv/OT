#include <asiopal/UTCTimeSource.h>
#include <opendnp3/LogLevels.h>
#include <opendnp3/master/ISOEHandler.h>
#include <asiodnp3/ConsoleLogger.h>
#include <asiodnp3/DNP3Manager.h>
#include <asiodnp3/DefaultMasterApplication.h>
#include <asiodnp3/PrintingChannelListener.h>

#include <atomic>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <memory>
#include <string>
#include <thread>

using namespace asiodnp3;
using namespace asiopal;
using namespace opendnp3;
using namespace openpal;

class CountingSOEHandler final : public ISOEHandler {
public:
    static std::shared_ptr<CountingSOEHandler> Create() {
        return std::make_shared<CountingSOEHandler>();
    }

    size_t Count() const { return count.load(); }

    void Process(const HeaderInfo&, const ICollection<Indexed<Binary>>& values) override {
        values.ForeachItem([&](const Indexed<Binary>& pair) {
            ++count;
            std::cout << "Binary[" << pair.index << "]=" << (pair.value.value ? 1 : 0) << std::endl;
        });
    }
    void Process(const HeaderInfo&, const ICollection<Indexed<DoubleBitBinary>>& values) override {
        CountIndexed("DoubleBitBinary", values);
    }
    void Process(const HeaderInfo&, const ICollection<Indexed<Analog>>& values) override {
        values.ForeachItem([&](const Indexed<Analog>& pair) {
            ++count;
            std::cout << "Analog[" << pair.index << "]=" << pair.value.value << std::endl;
        });
    }
    void Process(const HeaderInfo&, const ICollection<Indexed<Counter>>& values) override {
        values.ForeachItem([&](const Indexed<Counter>& pair) {
            ++count;
            std::cout << "Counter[" << pair.index << "]=" << pair.value.value << std::endl;
        });
    }
    void Process(const HeaderInfo&, const ICollection<Indexed<FrozenCounter>>& values) override {
        CountIndexed("FrozenCounter", values);
    }
    void Process(const HeaderInfo&, const ICollection<Indexed<BinaryOutputStatus>>& values) override {
        CountIndexed("BinaryOutputStatus", values);
    }
    void Process(const HeaderInfo&, const ICollection<Indexed<AnalogOutputStatus>>& values) override {
        CountIndexed("AnalogOutputStatus", values);
    }
    void Process(const HeaderInfo&, const ICollection<Indexed<OctetString>>& values) override {
        CountIndexed("OctetString", values);
    }
    void Process(const HeaderInfo&, const ICollection<Indexed<TimeAndInterval>>& values) override {
        CountIndexed("TimeAndInterval", values);
    }
    void Process(const HeaderInfo&, const ICollection<Indexed<BinaryCommandEvent>>& values) override {
        CountIndexed("BinaryCommandEvent", values);
    }
    void Process(const HeaderInfo&, const ICollection<Indexed<AnalogCommandEvent>>& values) override {
        CountIndexed("AnalogCommandEvent", values);
    }
    void Process(const HeaderInfo&, const ICollection<Indexed<SecurityStat>>& values) override {
        CountIndexed("SecurityStat", values);
    }
    void Process(const HeaderInfo&, const ICollection<DNPTime>& values) override {
        values.ForeachItem([&](const DNPTime& value) {
            ++count;
            std::cout << "DNPTime=" << value.value << std::endl;
        });
    }

protected:
    void Start() final {}
    void End() final {}

private:
    template<class T>
    void CountIndexed(const char* label, const ICollection<Indexed<T>>& values) {
        values.ForeachItem([&](const Indexed<T>& pair) {
            ++count;
            std::cout << label << "[" << pair.index << "]" << std::endl;
        });
    }

    std::atomic<size_t> count{0};
};

struct Arguments {
    std::string host = "127.0.0.1";
    uint16_t port = 20001;
    uint16_t master = 2;
    uint16_t outstation = 10;
    std::string action = "scan";
    uint16_t point = 0;
};

Arguments parse_args(int argc, char* argv[]) {
    Arguments args;
    for (int i = 1; i < argc; ++i) {
        std::string key = argv[i];
        if (key == "--host" && i + 1 < argc) args.host = argv[++i];
        else if (key == "--port" && i + 1 < argc) args.port = static_cast<uint16_t>(std::stoi(argv[++i]));
        else if (key == "--master" && i + 1 < argc) args.master = static_cast<uint16_t>(std::stoi(argv[++i]));
        else if (key == "--outstation" && i + 1 < argc) args.outstation = static_cast<uint16_t>(std::stoi(argv[++i]));
        else if (key == "--action" && i + 1 < argc) args.action = argv[++i];
        else if (key == "--point" && i + 1 < argc) args.point = static_cast<uint16_t>(std::stoi(argv[++i]));
        else if (key == "--help") {
            std::cout << "Usage: prabal-dnp3-command --host HOST --port PORT --master ADDR "
                         "--action scan|open|close [--point INDEX]\n";
            std::exit(0);
        }
    }
    return args;
}

int main(int argc, char* argv[]) {
    const auto args = parse_args(argc, argv);
    if (args.action != "scan" && args.action != "open" && args.action != "close") {
        std::cerr << "Unsupported action\n";
        return 2;
    }

    DNP3Manager manager(1, ConsoleLogger::Create());
    auto channel = manager.AddTCPClient(
        "prabal-command-client", levels::NORMAL,
        ChannelRetry::Default(), {IPEndpoint(args.host, args.port)}, "0.0.0.0",
        PrintingChannelListener::Create());

    MasterStackConfig config;
    config.master.responseTimeout = TimeDuration::Seconds(3);
    config.master.disableUnsolOnStartup = true;
    config.link.LocalAddr = args.master;
    config.link.RemoteAddr = args.outstation;

    auto handler = CountingSOEHandler::Create();
    auto master = channel->AddMaster(
        "prabal-field-command", handler,
        DefaultMasterApplication::Create(), config);
    auto scan = master->AddClassScan(ClassField::AllClasses(), TimeDuration::Minutes(60));
    master->Enable();
    std::this_thread::sleep_for(std::chrono::seconds(2));

    if (args.action == "scan") {
        const auto before = handler->Count();
        scan->Demand();
        for (int i = 0; i < 50 && handler->Count() == before; ++i) {
            std::this_thread::sleep_for(std::chrono::milliseconds(200));
        }
        const auto received = handler->Count() - before;
        if (received == 0) {
            std::cerr << "SCAN_FAILED no DNP3 point response received" << std::endl;
            return 1;
        }
        std::cout << "SCAN_COMPLETED points=" << received << " host=" << args.host
                  << " port=" << args.port << " master=" << args.master << std::endl;
        return 0;
    }

    std::atomic<bool> completed{false};
    std::atomic<bool> successful{true};
    auto callback = [&](const ICommandTaskResult& result) {
        if (result.summary != TaskCompletion::SUCCESS) successful = false;
        result.ForeachItem([&](const CommandPointResult& point) {
            std::cout << "COMMAND_RESULT index=" << point.index
                      << " state=" << CommandPointStateToString(point.state)
                      << " status=" << CommandStatusToString(point.status) << std::endl;
            if (point.state != CommandPointState::SUCCESS || point.status != CommandStatus::SUCCESS) {
                successful = false;
            }
        });
        completed = true;
    };

    const ControlCode code = args.action == "close" ? ControlCode::LATCH_ON : ControlCode::LATCH_OFF;
    ControlRelayOutputBlock command(code);
    master->SelectAndOperate(command, args.point, callback);

    for (int i = 0; i < 50 && !completed; ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(200));
    }
    if (!completed || !successful) {
        std::cerr << "COMMAND_FAILED action=" << args.action << " point=" << args.point << std::endl;
        return 1;
    }
    std::cout << "COMMAND_SUBMITTED action=" << args.action << " point=" << args.point
              << " host=" << args.host << " port=" << args.port
              << " master=" << args.master << std::endl;
    return 0;
}
