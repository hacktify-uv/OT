#include <asiopal/UTCTimeSource.h>
#include <opendnp3/LogLevels.h>
#include <opendnp3/master/ISOEHandler.h>
#include <asiodnp3/ConsoleLogger.h>
#include <asiodnp3/DNP3Manager.h>
#include <asiodnp3/DefaultMasterApplication.h>
#include <asiodnp3/PrintingChannelListener.h>

#include <atomic>
#include <fstream>
#include <ctime>
#include <cstdio>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <csignal>
#include <iostream>
#include <memory>
#include <string>
#include <thread>

using namespace asiodnp3;
using namespace asiopal;
using namespace opendnp3;
using namespace openpal;

namespace {
std::atomic<bool> running{true};
void handle_signal(int) { running = false; }
void publish_master_identity(uint16_t local, uint16_t remote) {
    const std::string temp = "/run/prabal-s03/.master-identity.tmp";
    std::ofstream f(temp, std::ios::trunc);
    if (!f.good()) return;
    f << "{\"master_stack_name\":\"PU-LDC-DNP3-MASTER-01\","
      << "\"local_link_address\":" << local << ","
      << "\"outstation_link_address\":" << remote << ","
      << "\"updated_epoch\":" << std::time(nullptr) << "}\n";
    f.close();
    if (f.good()) std::rename(temp.c_str(), "/run/prabal-s03/master-identity.json");
}

class HealthSOEHandler final : public ISOEHandler {
public:
    static std::shared_ptr<HealthSOEHandler> Create() {
        return std::make_shared<HealthSOEHandler>();
    }

    void Process(const HeaderInfo&, const ICollection<Indexed<Binary>>& values) override { Count(values); }
    void Process(const HeaderInfo&, const ICollection<Indexed<DoubleBitBinary>>& values) override { Count(values); }
    void Process(const HeaderInfo&, const ICollection<Indexed<Analog>>& values) override { Count(values); }
    void Process(const HeaderInfo&, const ICollection<Indexed<Counter>>& values) override { Count(values); }
    void Process(const HeaderInfo&, const ICollection<Indexed<FrozenCounter>>& values) override { Count(values); }
    void Process(const HeaderInfo&, const ICollection<Indexed<BinaryOutputStatus>>& values) override { Count(values); }
    void Process(const HeaderInfo&, const ICollection<Indexed<AnalogOutputStatus>>& values) override { Count(values); }
    void Process(const HeaderInfo&, const ICollection<Indexed<OctetString>>& values) override { Count(values); }
    void Process(const HeaderInfo&, const ICollection<Indexed<TimeAndInterval>>& values) override { Count(values); }
    void Process(const HeaderInfo&, const ICollection<Indexed<BinaryCommandEvent>>& values) override { Count(values); }
    void Process(const HeaderInfo&, const ICollection<Indexed<AnalogCommandEvent>>& values) override { Count(values); }
    void Process(const HeaderInfo&, const ICollection<Indexed<SecurityStat>>& values) override { Count(values); }
    void Process(const HeaderInfo&, const ICollection<DNPTime>& values) override {
        values.ForeachItem([&](const DNPTime&) { ++pending; });
    }

protected:
    void Start() final { pending = 0; }
    void End() final {
        const auto points = pending.exchange(0);
        if (points > 0) {
            const auto cumulative = total.fetch_add(points) + points;
            std::cout << "LEGITIMATE_MASTER_DATA points=" << points
                      << " total=" << cumulative << std::endl;
        }
    }

private:
    template<class T>
    void Count(const ICollection<Indexed<T>>& values) {
        values.ForeachItem([&](const Indexed<T>&) { ++pending; });
    }

    std::atomic<size_t> pending{0};
    std::atomic<size_t> total{0};
};
} // namespace

int main(int argc, char* argv[]) {
    const std::string host = argc > 1 ? argv[1] : "127.0.0.1";
    const uint16_t port = argc > 2 ? static_cast<uint16_t>(std::stoi(argv[2])) : 20000;
    const uint16_t local = argc > 3 ? static_cast<uint16_t>(std::stoi(argv[3])) : 1;
    const uint16_t remote = argc > 4 ? static_cast<uint16_t>(std::stoi(argv[4])) : 10;

    std::signal(SIGINT, handle_signal);
    std::signal(SIGTERM, handle_signal);

    DNP3Manager manager(1, ConsoleLogger::Create());
    auto channel = manager.AddTCPClient(
        "prabal-control-centre-master", levels::NORMAL | levels::ALL_APP_COMMS,
        ChannelRetry::Default(), {IPEndpoint(host, port)}, "0.0.0.0",
        PrintingChannelListener::Create());

    MasterStackConfig config;
    config.master.responseTimeout = TimeDuration::Seconds(3);
    config.master.disableUnsolOnStartup = true;
    config.link.LocalAddr = local;
    config.link.RemoteAddr = remote;

    auto master = channel->AddMaster(
        "PU-LDC-DNP3-MASTER-01", HealthSOEHandler::Create(),
        DefaultMasterApplication::Create(), config);
    auto integrity = master->AddClassScan(ClassField::AllClasses(), TimeDuration::Minutes(1));
    master->AddClassScan(ClassField(ClassField::CLASS_1), TimeDuration::Seconds(2));
    master->Enable();

    std::cout << "LEGITIMATE_MASTER_READY master=PU-LDC-DNP3-MASTER-01 host=" << host << " port=" << port << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(2));
    integrity->Demand();

    while (running) { publish_master_identity(local, remote); std::this_thread::sleep_for(std::chrono::seconds(2)); }
    std::remove("/run/prabal-s03/master-identity.json");
    return 0;
}
