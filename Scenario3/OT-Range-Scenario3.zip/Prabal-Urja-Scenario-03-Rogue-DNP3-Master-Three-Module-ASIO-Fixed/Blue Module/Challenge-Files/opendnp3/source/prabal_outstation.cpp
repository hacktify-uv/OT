#include <asiopal/UTCTimeSource.h>
#include <opendnp3/LogLevels.h>
#include <opendnp3/outstation/IUpdateHandler.h>
#include <opendnp3/outstation/ICommandHandler.h>
#include <asiodnp3/ConsoleLogger.h>
#include <opendnp3/outstation/IOutstationApplication.h>
#include <asiodnp3/DNP3Manager.h>
#include <asiodnp3/PrintingChannelListener.h>
#include <asiodnp3/UpdateBuilder.h>

#include <atomic>
#include <fcntl.h>
#include <unistd.h>
#include <ctime>
#include <mutex>
#include <chrono>
#include <cstdint>
#include <csignal>
#include <fstream>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

using namespace asiodnp3;
using namespace opendnp3;
using namespace openpal;

namespace {
std::atomic<bool> running{true};

void handle_signal(int) { running = false; }

struct ProcessState {
    bool feeder_a_closed = true;
    bool bus_tie_closed = false;
    bool feeder_b_closed = true;
    bool remote_control = true;
    bool overload_alarm = false;
    bool command_lockout = false;
    double feeder_a_mw = 318.0;
    double feeder_b_mw = 302.0;
    double bus_voltage_kv = 218.7;
    double transformer_loading = 84.2;
    double corridor_loading = 78.6;
    double frequency_hz = 50.0;
    uint32_t accepted_operations = 0;
};

bool parse_bool(const std::string& value) {
    return value == "1" || value == "true" || value == "TRUE";
}

bool load_state(const std::string& path, ProcessState& state) {
    std::ifstream input(path);
    if (!input.good()) return false;
    std::string line;
    if (!std::getline(input, line)) return false;
    std::vector<std::string> fields;
    std::stringstream stream(line);
    std::string field;
    while (std::getline(stream, field, ',')) fields.push_back(field);
    if (fields.size() < 13) return false;
    try {
        state.feeder_a_closed = parse_bool(fields[0]);
        state.bus_tie_closed = parse_bool(fields[1]);
        state.feeder_b_closed = parse_bool(fields[2]);
        state.remote_control = parse_bool(fields[3]);
        state.overload_alarm = parse_bool(fields[4]);
        state.command_lockout = parse_bool(fields[5]);
        state.feeder_a_mw = std::stod(fields[6]);
        state.feeder_b_mw = std::stod(fields[7]);
        state.bus_voltage_kv = std::stod(fields[8]);
        state.transformer_loading = std::stod(fields[9]);
        state.corridor_loading = std::stod(fields[10]);
        state.frequency_hz = std::stod(fields[11]);
        state.accepted_operations = static_cast<uint32_t>(std::stoul(fields[12]));
        return true;
    } catch (...) {
        return false;
    }
}

void apply_state(const std::shared_ptr<IOutstation>& outstation, const ProcessState& state) {
    UpdateBuilder builder;
    builder.Update(Binary(state.feeder_a_closed), 0);
    builder.Update(Binary(state.bus_tie_closed), 1);
    builder.Update(Binary(state.feeder_b_closed), 2);
    builder.Update(Binary(state.remote_control), 3);
    builder.Update(Binary(state.overload_alarm), 4);
    builder.Update(Binary(state.command_lockout), 5);
    builder.Update(Analog(state.feeder_a_mw), 0);
    builder.Update(Analog(state.feeder_b_mw), 1);
    builder.Update(Analog(state.bus_voltage_kv), 2);
    builder.Update(Analog(state.transformer_loading), 3);
    builder.Update(Analog(state.corridor_loading), 4);
    builder.Update(Analog(state.frequency_hz), 5);
    builder.Update(Counter(state.accepted_operations), 0);
    outstation->Apply(builder.Build());
}


// This handler records a control only from the actual OpenDNP3 Operate callback.
// Packet capture is audit-only and never drives simulated breaker state.
class OperationalCommandHandler final : public ICommandHandler {
public:
    explicit OperationalCommandHandler(const std::string& state_path, bool maintenance)
      : state_path(state_path), maintenance(maintenance) {}

    CommandStatus Select(const ControlRelayOutputBlock& cmd, uint16_t index) override {
        return validate(cmd, index);
    }
    CommandStatus Operate(const ControlRelayOutputBlock& cmd, uint16_t index, OperateType type) override {
        const auto status = validate(cmd, index);
        if (status != CommandStatus::SUCCESS) return status;
        const bool closed = cmd.functionCode == ControlCode::LATCH_ON;
        const int function = type == OperateType::SelectBeforeOperate ? 4 :
                             type == OperateType::DirectOperate ? 5 : 6;
        std::lock_guard<std::mutex> lock(mutex);
        std::ostringstream event;
        event << "{\"execute_origin\":\"native_opendnp3_handler\","
              << "\"source_channel\":\"maintenance\","
              << "\"source_ip\":\"unattributed\","
              << "\"dnp3_master\":2,\"dnp3_outstation\":10,"
              << "\"dnp3_function\":" << function << ",\"point\":" << index
              << ",\"desired_closed\":" << (closed ? "true" : "false")
              << ",\"control_status\":\"SUCCESS\","
              << "\"epoch\":" << std::time(nullptr) << "}\n";
        const std::string payload = event.str();
        const int fd = ::open("/run/prabal-s03/accepted-commands.jsonl", O_WRONLY | O_APPEND | O_CLOEXEC);
        if (fd < 0) return CommandStatus::HARDWARE_ERROR;
        const ssize_t wrote = ::write(fd, payload.data(), payload.size());
        const bool queued = wrote == static_cast<ssize_t>(payload.size()) && ::fsync(fd) == 0;
        ::close(fd);
        if (!queued) return CommandStatus::HARDWARE_ERROR;
        std::cout << "NATIVE_DNP3_CONTROL_QUEUED point=" << index
                  << " closed=" << closed << " mode=" << function << std::endl;
        return CommandStatus::SUCCESS;
    }
    CommandStatus Select(const AnalogOutputInt16&, uint16_t) override { return CommandStatus::NOT_SUPPORTED; }
    CommandStatus Select(const AnalogOutputInt32&, uint16_t) override { return CommandStatus::NOT_SUPPORTED; }
    CommandStatus Select(const AnalogOutputFloat32&, uint16_t) override { return CommandStatus::NOT_SUPPORTED; }
    CommandStatus Select(const AnalogOutputDouble64&, uint16_t) override { return CommandStatus::NOT_SUPPORTED; }
    CommandStatus Operate(const AnalogOutputInt16&, uint16_t, OperateType) override { return CommandStatus::NOT_SUPPORTED; }
    CommandStatus Operate(const AnalogOutputInt32&, uint16_t, OperateType) override { return CommandStatus::NOT_SUPPORTED; }
    CommandStatus Operate(const AnalogOutputFloat32&, uint16_t, OperateType) override { return CommandStatus::NOT_SUPPORTED; }
    CommandStatus Operate(const AnalogOutputDouble64&, uint16_t, OperateType) override { return CommandStatus::NOT_SUPPORTED; }
protected:
    void Start() override {}
    void End() override {}
private:
    CommandStatus validate(const ControlRelayOutputBlock& cmd, uint16_t index) const {
        if (!maintenance) return CommandStatus::NOT_AUTHORIZED;
        if (index > 2) return CommandStatus::NOT_SUPPORTED;
        if (cmd.functionCode != ControlCode::LATCH_ON && cmd.functionCode != ControlCode::LATCH_OFF)
            return CommandStatus::NOT_SUPPORTED;
        ProcessState state;
        if (!load_state(state_path, state)) return CommandStatus::HARDWARE_ERROR;
        if (!state.remote_control) return CommandStatus::LOCAL;
        if (state.command_lockout) return CommandStatus::BLOCKED;
        return CommandStatus::SUCCESS;
    }
    const std::string state_path;
    const bool maintenance;
    std::mutex mutex;
};

OutstationStackConfig make_config(uint16_t remote_master, bool any_master) {
    OutstationStackConfig config(DatabaseSizes::AllTypes(16));
    config.outstation.eventBufferConfig = EventBufferConfig::AllTypes(100);
    config.outstation.params.allowUnsolicited = true;
    config.outstation.params.respondToAnyMaster = any_master;
    config.link.LocalAddr = 10;
    config.link.RemoteAddr = remote_master;
    config.link.KeepAliveTimeout = TimeDuration::Max();
    return config;
}
} // namespace

int main(int argc, char* argv[]) {
    const std::string state_path = argc > 1 ? argv[1] : "/run/prabal-s03/rtu_state.csv";
    const uint16_t primary_port = argc > 2 ? static_cast<uint16_t>(std::stoi(argv[2])) : 20000;
    const uint16_t maintenance_port = argc > 3 ? static_cast<uint16_t>(std::stoi(argv[3])) : 20001;

    std::signal(SIGINT, handle_signal);
    std::signal(SIGTERM, handle_signal);

    DNP3Manager manager(2, ConsoleLogger::Create());
    const auto filters = levels::NORMAL | levels::ALL_COMMS;

    auto primary_channel = manager.AddTCPServer(
        "riverbend-primary", filters, ServerAcceptMode::CloseExisting,
        "0.0.0.0", primary_port, PrintingChannelListener::Create());
    auto maintenance_channel = manager.AddTCPServer(
        "riverbend-maintenance", filters, ServerAcceptMode::CloseExisting,
        "0.0.0.0", maintenance_port, PrintingChannelListener::Create());

    auto primary = primary_channel->AddOutstation(
        "PU-RB-RTU-07-primary", std::make_shared<OperationalCommandHandler>(state_path, false),
        DefaultOutstationApplication::Create(), make_config(1, false));
    auto maintenance = maintenance_channel->AddOutstation(
        "PU-RB-RTU-07-maintenance", std::make_shared<OperationalCommandHandler>(state_path, true),
        DefaultOutstationApplication::Create(), make_config(2, true));

    primary->Enable();
    maintenance->Enable();
    std::cout << "PRABAL_DNP3_OUTSTATION_READY primary=" << primary_port
              << " maintenance=" << maintenance_port << std::endl;

    ProcessState state;
    while (running) {
        if (load_state(state_path, state)) {
            apply_state(primary, state);
            apply_state(maintenance, state);
        }
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
    return 0;
}
