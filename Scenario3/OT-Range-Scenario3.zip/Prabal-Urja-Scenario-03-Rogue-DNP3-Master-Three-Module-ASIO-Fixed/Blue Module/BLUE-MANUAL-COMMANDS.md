# Blue Manual Commands

```bash
sudo ./Blue-Investigation.sh
sudo ./Blue-Containment.sh
```

To retain one approved maintenance source:

```bash
sudo ./Blue-Containment.sh <AUTHORISED_MAINTENANCE_IPV4>
```

Confirm `SERVICE_STATUS:UP` and `NORMAL_SWITCHING_CONFIGURATION`.
