# Incident Notification Report (INREP)

**Cyber Exercise — Operation PRABAL PRAHARI**  
**Scenario 03 — Rogue DNP3 Master at River Bend Substation**  
**Version 1.0**

---

**Date:** [YYYY-MM-DD]  
**Time:** [Time of Incident in IST]  
**Report ID:** IN-PU-S03-DNP3  
**Classification:** TRAINING

---

## 1. Current Situation

**Description:** River Bend RTU `PU-RB-RTU-07` accepted unauthorised DNP3 switching commands through a retained maintenance listener. A second DNP3 master issued a bus-tie close command followed by a Feeder A open command. The resulting topology transferred River Bend load onto Feeder B while the legitimate load-dispatch master and RTU remained operational.

**Threat Level:** High

**Operational Condition:**

- Feeder A breaker `RB-FDR-A-52A`: [Open/Closed]
- Bus-tie breaker `RB-BT-52B`: [Open/Closed]
- Feeder B breaker `RB-FDR-B-52C`: [Open/Closed]
- Feeder B loading: [Observed MW]
- Northern-corridor loading: [Observed %]
- Transformer loading: [Observed %]
- Legitimate DNP3 master: [Connected/Disconnected]
- Unauthorised source IP: [ATTACKER_IP]
- Unauthorised DNP3 master address: [MASTER_ADDRESS]

**Areas of Concern:**

- Valid DNP3 controls were accepted from a non-approved master.
- The maintenance listener on TCP 20001 is reachable outside a documented maintenance window.
- The outstation responds to DNP3 source addresses beyond the authorised maintenance master.
- The load transfer has reduced corridor and transformer thermal margin.
- Additional field controls may be exposed through the same unauthorised relationship.
- Upstream control-centre command authorisation must be reviewed for similar trust assumptions.

---

## 2. Threat Intelligence and Initial Evidence

**Primary evidence sources:**

- DNP3 command audit: `/var/log/prabal-urja/scenario3/dnp3-commands.jsonl`
- Process event log: `/var/log/prabal-urja/scenario3/process-events.jsonl`
- Process historian: `/var/log/prabal-urja/scenario3/process-historian.csv`
- Packet captures: `/var/log/prabal-urja/scenario3/pcap/`
- Authoritative process state: `/var/lib/prabal-urja/scenario3/state.json`
- Outstation journal: `journalctl -u prabal-dnp3-outstation.service`
- Legitimate master journal: `journalctl -u prabal-dnp3-master.service`

**Indicators of Compromise:**

- Remote TCP session to `PU-RB-RTU-07:20001` outside an approved maintenance activity.
- DNP3 link-layer source address other than the expected master relationship.
- Application function code sequence containing SELECT followed by OPERATE.
- Binary-output point `1` commanded closed.
- Binary-output point `0` commanded open.
- `source_ip` in `dnp3-commands.jsonl` does not match the approved master.
- Process state `ROGUE_MASTER_SWITCHING_CONFIRMED`.

**Initial evidence command:**

```bash
sudo jq -c 'select(.event=="DNP3_OPERATION_ACCEPTED")' \
  /var/log/prabal-urja/scenario3/dnp3-commands.jsonl
```

**Log entry identified:**

```text
[Paste accepted SELECT/OPERATE entries with timestamp, source IP, DNP3 source,
point index and requested state]
```

---

## 3. Vulnerability Identification

**Vulnerability:** Unauthorised second DNP3 master accepted through retained maintenance channel

**Affected interface:**

```text
DNP3/TCP maintenance listener — TCP 20001
Outstation link address — 10
Expected maintenance master — 2
```

**Description:** The River Bend maintenance DNP3 channel remains reachable from a broad OT segment and does not authenticate the remote operator. The outstation is configured to respond to master addresses beyond the expected maintenance master. A protocol-correct client can perform integrity reads and valid Select-Before-Operate controls without an independent operational approval.

**Patch status:** Containment ongoing. Network allowlisting, maintenance-path closure and command-source validation are required.

---

## 4. Security Operations

### Immediate actions

1. Preserve DNP3 packet capture, socket state, logs and current breaker state.
2. Identify the unauthorised source IP and DNP3 master address.
3. Confirm the authorised primary master remains connected on TCP 20000.
4. Block non-approved remote access to TCP 20001 without interrupting loopback or TCP 20000.
5. Restore Feeder A before reopening the bus tie.
6. Validate normal loading, alarms and telemetry.
7. Notify the OT incident commander and shift controller.

### Containment command

Close the retained maintenance channel to all non-loopback clients:

```bash
sudo /opt/prabal-urja/scenario3/tools/apply_hardening.sh
sudo systemctl enable prabal-s03-hardening.service
```

Or allow one approved maintenance source:

```bash
sudo /opt/prabal-urja/scenario3/tools/apply_hardening.sh <AUTHORISED_MASTER_IP>
sudo systemctl enable prabal-s03-hardening.service
```

### Approved restoration

```bash
sudo /opt/prabal-urja/scenario3/tools/operator_restore.py \
  --operator "[SHIFT_CONTROLLER]" \
  --reason "Unauthorised DNP3 control contained; restore approved topology"
```

### Validation

```bash
sudo /opt/prabal-urja/scenario3/tools/service_availability.sh
sudo jq '{scenario_state,breakers,metrics,alarms}' \
  /var/lib/prabal-urja/scenario3/state.json
```

---

## 5. Additional Notes

This event is the third stage of the Prabal Urja interconnected Red-vs-Blue exercise. Scenario 2’s elevated generation condition increases the operational impact of the River Bend load transfer. Evidence should be reviewed for similar command-authorisation assumptions in upstream control-centre services before progressing to Scenario 4.

**Connected systems at risk:**

- Prabal Urja Unit-2 generation corridor
- River Bend Feeder A and Feeder B
- Northern Power Corridor loads
- Control-centre telecontrol services
- Future IEC-104 command environment represented in Scenario 4

---

## 6. Communication

**Internal notification:**

- OT Incident Commander: Immediate
- River Bend Shift Controller: Immediate
- Load Dispatch Operations: Immediate
- Blue Team Lead / SOC: Immediate
- Power System Engineering: Within 15 minutes
- Exercise Control: Per exercise communication plan

**Update frequency:** Every 30 minutes until unauthorised access is contained and switching is restored.

**Primary channel:** Approved exercise incident-management channel and encrypted operational communication.

---

## 7. POC and Attachments

Attach:

1. screenshot of unexpected TCP 20001 session;
2. packet decode showing DNP3 source, destination, SELECT, OPERATE and point index;
3. `dnp3-commands.jsonl` accepted-operation entries;
4. operator-console breaker state and loading alarms;
5. historian values before and after the transfer;
6. firewall containment rules;
7. post-recovery service-health output.

---

## 8. Submission

**Prepared By:** [Blue Team Analyst Name]  
**Reviewed By:** [Blue Team Lead / OT Incident Commander]  
**Status:** [Initial / Updated / Final]
