# SITREP Report (SITREP)

**Cyber Exercise — Operation PRABAL PRAHARI**  
**Scenario 03 — Rogue DNP3 Master at River Bend Substation**  
**Version 1.0**

---

**Date:** [YYYY-MM-DD]  
**Time:** [Time of Detection in IST]  
**Incident ID:** SITREP-PU-S03-DNP3  
**Classification:** TRAINING

---

## 1. Incident Overview

**Description:**

An unauthorised DNP3 master connected to the retained maintenance listener on River Bend RTU `PU-RB-RTU-07`. The source performed DNP3 point discovery and issued protocol-valid Select-Before-Operate controls. The observed sequence closed bus-tie breaker `RB-BT-52B` and opened Feeder A breaker `RB-FDR-A-52A`, transferring load to Feeder B.

**Severity Level:** High

**Impact:**

- River Bend topology changed outside the approved switching schedule.
- Feeder B assumed approximately 620 MW in the modeled condition.
- Northern-corridor loading increased to approximately 96.8%.
- Transformer loading increased to approximately 101.4%.
- Overload alarms activated.
- Legitimate DNP3 polling remained available, which could make the event appear operationally valid.
- No host crash or protocol outage was required.

**Affected System:**

```text
PU-RB-RTU-07 — River Bend 220/132 kV Substation
DNP3/TCP primary listener: 20000
DNP3/TCP maintenance listener: 20001
DNP3 outstation address: 10
```

---

## 2. Incident Details

### Detection method

The event was detected through correlation of:

- breaker-state and loading changes on the River Bend operator display;
- a second TCP session to the maintenance listener;
- DNP3 SELECT and OPERATE commands from an unapproved network source;
- accepted control events in the DNP3 command audit;
- a process-historian transition from normal split loading to single-feeder transfer.

### Primary IOC queries

```bash
sudo ss -tnap '( sport = :20001 or dport = :20001 )'
```

```bash
sudo jq -c 'select(.event=="DNP3_OPERATION_ACCEPTED")' \
  /var/log/prabal-urja/scenario3/dnp3-commands.jsonl
```

```bash
sudo tshark -n -i any -d tcp.port==20001,dnp3 \
  -f 'tcp port 20001' \
  -Y 'dnp3.al.func == 3 || dnp3.al.func == 4 || dnp3.al.func == 5 || dnp3.al.func == 6' \
  -T fields -E header=y -E separator='|' \
  -e frame.time -e ip.src -e dnp3.src -e dnp3.dst \
  -e dnp3.al.func -e dnp3.al.point_index -e dnp3.al.bocs -e dnp3.al.ctrlstatus
```

### Confirmed IOC values

| Indicator | Observed value |
|---|---|
| Unauthorised source IP | `[ATTACKER_IP]` |
| Source TCP port | `[SOURCE_PORT]` |
| Destination TCP port | `20001` |
| DNP3 source/master address | `[MASTER_ADDRESS]` |
| DNP3 destination/outstation address | `10` |
| First controlled point | `1 — bus tie` |
| First action | `Close / LATCH_ON` |
| Second controlled point | `0 — Feeder A` |
| Second action | `Open / LATCH_OFF` |
| Initial detection time | `[TIMESTAMP]` |
| Scenario confirmation time | `[TIMESTAMP]` |

### Attack vector

Unauthorised DNP3 master session through a legacy maintenance listener with no source authentication and permissive master-address handling.

---

## 3. Response Actions Taken

### Evidence preservation

- Captured active TCP sessions and listening ports.
- Preserved rolling PCAP files.
- Collected systemd journals for outstation, master, monitor, process and console services.
- Exported command-audit and process-event logs.
- Recorded current breaker positions and electrical measurements.
- Created a checksummed evidence archive.

Command:

```bash
sudo /opt/prabal-urja/scenario3/tools/collect_evidence.sh
```

### Containment

- Restricted TCP 20001 to the approved maintenance source or closed it to all non-loopback sources.
- Preserved the legitimate master session on TCP 20000.
- Verified that the unauthorised session terminated.
- Continued process and telemetry monitoring during containment.

Command used:

```bash
sudo /opt/prabal-urja/scenario3/tools/apply_hardening.sh [AUTHORISED_MASTER_IP]
sudo systemctl enable prabal-s03-hardening.service
```

### Eradication

- Removed broad network access to the retained maintenance channel.
- Reviewed and documented the permissive master-address setting.
- Confirmed no unapproved persistent service or account was introduced.
- Reviewed connected OT systems for additional DNP3 listeners and similar maintenance routes.

### Recovery

- Closed Feeder A before opening the bus tie.
- Restored the approved Feeder A closed / bus tie open / Feeder B closed configuration.
- Verified corridor and transformer loading returned to baseline.
- Confirmed the legitimate master remained connected.
- Ran the full service-availability validation.

```bash
sudo /opt/prabal-urja/scenario3/tools/operator_restore.py \
  --operator "[SHIFT_CONTROLLER]" \
  --reason "Incident containment and approved restoration"

sudo /opt/prabal-urja/scenario3/tools/service_availability.sh
```

### Lessons learned

- Healthy telemetry does not prove that control commands are authorised.
- DNP3 link addresses are identifiers, not authentication controls.
- Maintenance listeners must be removed or strictly time-bound and allowlisted.
- Detection must inspect DNP3 command semantics and master relationships.
- Containment must preserve the authorised master and avoid a broad OT outage.
- Switching restoration order must be validated by power-system operations.

---

## 4. Technical Analysis

### Evidence locations

```text
/var/log/prabal-urja/scenario3/dnp3-commands.jsonl
/var/log/prabal-urja/scenario3/process-events.jsonl
/var/log/prabal-urja/scenario3/process-historian.csv
/var/log/prabal-urja/scenario3/pcap/
/var/lib/prabal-urja/scenario3/state.json
```

### Protocol sequence

```text
Unexpected master -> TCP 20001
DNP3 integrity/class read -> point model returned
SELECT point 1 / CLOSE -> accepted
OPERATE point 1 / CLOSE -> bus tie closes
SELECT point 0 / OPEN -> accepted
OPERATE point 0 / OPEN -> Feeder A opens
Process model -> load transfers to Feeder B
```

### Process sequence

| Time | Feeder A | Bus tie | Feeder B | Feeder B MW | Corridor % | Transformer % |
|---|---|---|---|---:|---:|---:|
| `[T0]` | Closed | Open | Closed | 302 | 78.6 | 84.2 |
| `[T1]` | Closed | Closed | Closed | 310 | 79.0 | 84.5 |
| `[T2]` | Open | Closed | Closed | 620 | 96.8 | 101.4 |
| `[T3]` | Closed | Open | Closed | 302 | 78.6 | 84.2 |

### MITRE ATT&CK for ICS

**T1692.001 — Unauthorized Message: Command Message**  
An unauthorised master generated valid DNP3 control messages accepted by the outstation.

**T0831 — Manipulation of Control**  
The adversary altered breaker states to redirect electrical load.

**T0836 — Modify Parameter**  
The switching configuration and resulting process state were modified without operational approval.

### Mitigation recommendations

- Decommission the retained maintenance listener when not required.
- Restrict DNP3 sessions by source IP, interface and expected master address.
- Implement DNP3 Secure Authentication where supported.
- Require approved maintenance windows and jump-host access.
- Alert on concurrent or unexpected DNP3 masters.
- Monitor SELECT, OPERATE and DIRECT_OPERATE commands with point context.
- Correlate control commands with operator work orders and process effects.
- Maintain independent process-safety limits and safe restoration runbooks.

---

## 5. Communication

**Internal notification:**

- OT security operations
- Load-dispatch control room
- River Bend shift controller
- Power-system engineering
- Incident commander
- Exercise control

**External notification:**

This is a training exercise. No external notification is required unless directed by exercise control. In a real event, reporting obligations should be evaluated under applicable national critical-infrastructure and incident-reporting requirements.

**Update frequency:** Every 30 minutes until containment, then hourly through recovery validation.

---

## 6. Current Status

| Activity | Status | Owner | Evidence |
|---|---|---|---|
| Unauthorised master identified | [Complete/Ongoing] | [Name] | [Reference] |
| Packet evidence preserved | [Complete/Ongoing] | [Name] | [Reference] |
| Maintenance listener contained | [Complete/Ongoing] | [Name] | [Reference] |
| Approved switching restored | [Complete/Ongoing] | [Name] | [Reference] |
| Legitimate master validated | [Complete/Ongoing] | [Name] | [Reference] |
| Full service health passed | [Complete/Ongoing] | [Name] | [Reference] |
| Scenario 4 risk review initiated | [Complete/Ongoing] | [Name] | [Reference] |

---

## 7. Submission

**Prepared By:** [Blue Team Analyst Name]  
**Reviewed By:** [Blue Team Lead]  
**Approved By:** [OT Incident Commander]

## 8. POC (Screenshots)

Attach screenshots of:

- unexpected master session;
- SELECT and OPERATE packet fields;
- command-audit records;
- breaker and loading changes;
- containment rule;
- restored state;
- `SERVICE_STATUS:UP` output.
