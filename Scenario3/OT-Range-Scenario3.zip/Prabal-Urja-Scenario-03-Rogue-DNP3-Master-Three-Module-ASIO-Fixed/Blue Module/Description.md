# Scenario 3 — Rogue DNP3 Master at River Bend Substation

Prabal Urja’s River Bend 220/132 kV substation is a legacy remote switching site that supports two transmission feeders serving the Northern Power Corridor. During an evening high-load period, the load-dispatch centre observes an unexpected change in the River Bend bus arrangement. The substation remains reachable and telemetry continues to arrive, but the new switching state places unusual demand on one feeder and reduces operating margin across the corridor.

A maintenance communication path retained from an earlier RTU support activity is still present in the station environment. Exercise participants must determine whether the event represents legitimate switching, equipment malfunction, communication error or unauthorised control activity. The response must protect grid continuity, preserve evidence and restore the approved switching arrangement without unnecessarily interrupting the authorised control-centre connection.

This scenario forms the third stage of the interconnected Prabal Urja campaign. Conditions created during the earlier generation-control event increase the significance of any River Bend switching change. Decisions taken in this stage influence the control-centre environment encountered later in the exercise.

**Classification:** Training Exercise  
**Sector:** Electric Power Transmission and Distribution  
**Difficulty:** Intermediate  
**Environment:** Shared Red-vs-Blue live-fire range
