# Blue Student Access

Provide defender access to the Scenario 03 target VM, logs, packet captures,
systemd journal and operator console. Keep the operator attack trigger outside
the participant account's readable paths.
