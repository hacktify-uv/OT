# Scenario 03 Build Validation

**Package:** Prabal-Urja-Scenario-03-Rogue-DNP3-Master  
**Validation date:** 2026-06-21  
**Target:** Ubuntu Server 22.04 LTS / 24.04 LTS  
**Deployment type:** Native systemd services; no Docker

## Validation scope

This record distinguishes checks completed in the artifact environment from
checks that must run on the target Ubuntu VM after installation.

## Completed static checks

- Required deliverable and challenge-file presence
- Bash syntax for setup, dependency, reset, validation, hardening, firewall,
  packet-capture, evidence and source-preparation scripts
- Python bytecode compilation in an isolated cache directory
- JavaScript syntax validation
- JSON parsing for the point map and initial process state
- YAML parsing where PyYAML was available
- Setup TTP to Service Availability TTP ID linkage
- Exact Setup TTP command: `echo "Setup Successfully"`
- Service Availability TTP coverage for systemd, socket/port and functional
  application-layer probes
- OpenDNP3 2.3.0 API-shape review against the pinned upstream examples
- Presence of a real OpenDNP3 integrity scan and Select-Before-Operate client
- systemd escaping for timestamped tcpdump output
- Runtime-directory recreation and restart-preservation controls
- Atomic operator-restoration request and service ownership
- Strict IPv4 validation for the Blue Team DNP3 allowlist
- Console event-output escaping
- Absence of Docker and PyPI runtime dependencies
- Absence of generated Python cache files in the deliverable

## Completed functional integration checks

The Python process, command-observation and console components were exercised
with temporary runtime, state and log directories.

| Check | Result |
|---|---|
| Normal River Bend switching baseline | PASS |
| Baseline state `NORMAL_SWITCHING_CONFIGURATION` | PASS |
| DNP3 SELECT and matching OPERATE parsing | PASS |
| Accepted-operation queue generation | PASS |
| Remote bus-tie close application | PASS |
| Remote Feeder A open application | PASS |
| State `ROGUE_MASTER_SWITCHING_CONFIRMED` | PASS |
| Northern corridor loading reaches 96.8% | PASS |
| Rogue source IP retained in process state | PASS |
| Historian and event propagation | PASS |
| Atomic operator restoration request | PASS |
| Restoration to approved breaker arrangement | PASS |
| Operator console health endpoint | PASS |
| Operator console state endpoint | PASS |
| Operator console static application delivery | PASS |
| Invalid IPv4 allowlist rejection | PASS |
| Closed PCAP permissions and 24-hour pruning | PASS |
| Package static validator | PASS |

## Deployment checks performed by `setup.sh` and `validate.sh --installed`

On the supported Ubuntu target, installation fails closed unless all of the
following succeed:

1. Ubuntu package installation.
2. Download or local-cache extraction of OpenDNP3 2.3.0.
3. Compilation of the native outstation, legitimate master and command client.
4. Creation and startup of every required systemd service.
5. TCP listeners on 20000, 20001, 8092, 8093 and 8094.
6. Established legitimate-master session to TCP 20000.
7. Real DNP3 integrity scan through the maintenance listener.
8. Process heartbeat and current RTU point-image generation.
9. Live tshark command-monitor health.
10. Current operator-console process telemetry.
11. Active rolling DNP3 packet capture.

## Environment limitation

The artifact environment was not an Ubuntu 22.04/24.04 systemd VM and could
not retrieve the OpenDNP3 archive through its restricted network. Therefore,
a complete upstream C++ compilation and service boot test was not claimed here.
The supplied installer performs those checks on the actual target and exits
with an error instead of reporting a successful setup when any stage fails.

For a disconnected installation, pre-stage the unmodified release archive as:

```text
Challenge-Files/vendor-cache/opendnp3-2.3.0.tar.gz
```

Ubuntu packages must also be available through an internal APT mirror or cache.
