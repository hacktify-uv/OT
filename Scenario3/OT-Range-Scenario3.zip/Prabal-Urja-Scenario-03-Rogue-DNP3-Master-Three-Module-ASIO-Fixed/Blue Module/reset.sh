#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
PRESERVE=0
[[ "${1:-}" == "--preserve-evidence" ]] && PRESERVE=1
[[ ${EUID} -eq 0 ]] || { echo "Run as root" >&2; exit 1; }
ROOT=/opt/prabal-urja/scenario3
[[ -d "$ROOT" ]] || { echo "Scenario 03 is not installed" >&2; exit 1; }

if [[ $PRESERVE -eq 1 ]]; then
  "$ROOT/tools/collect_evidence.sh"
fi

systemctl disable --now prabal-s03-hardening.service 2>/dev/null || true
rm -f /etc/prabal-urja/scenario3/hardening.env
systemctl stop prabal-dnp3-master prabal-dnp3-outstation prabal-dnp3-command-monitor \
  prabal-riverbend-console prabal-riverbend-process prabal-dnp3-capture || true

install -d -o prabal-s03 -g prabal-s03 -m 0770 /run/prabal-s03
install -m 0640 -o prabal-s03 -g prabal-s03 "$ROOT/config/initial-state.json" /var/lib/prabal-urja/scenario3/state.json
rm -f /run/prabal-s03/restore.request /run/prabal-s03/rtu_state.csv
: > /run/prabal-s03/accepted-commands.jsonl
chown prabal-s03:prabal-s03 /run/prabal-s03/accepted-commands.jsonl
chmod 0660 /run/prabal-s03/accepted-commands.jsonl
if [[ $PRESERVE -eq 0 ]]; then
  rm -f /var/log/prabal-urja/scenario3/process-historian.csv \
    /var/log/prabal-urja/scenario3/process-events.jsonl \
    /var/log/prabal-urja/scenario3/dnp3-commands.jsonl \
    /var/log/prabal-urja/scenario3/pcap/*.pcap*
  : > /var/log/prabal-urja/scenario3/process-events.jsonl
  : > /var/log/prabal-urja/scenario3/dnp3-commands.jsonl
  chown prabal-s03:prabal-s03 /var/log/prabal-urja/scenario3/process-events.jsonl
  chown root:prabal-s03 /var/log/prabal-urja/scenario3/dnp3-commands.jsonl
  chmod 0660 /var/log/prabal-urja/scenario3/*.jsonl
fi

"$ROOT/tools/range_firewall.sh"
systemctl restart prabal-s03-firewall.service prabal-riverbend-process.service
for _ in {1..20}; do [[ -s /run/prabal-s03/rtu_state.csv ]] && break; sleep 0.5; done
systemctl restart prabal-dnp3-command-monitor.service prabal-dnp3-outstation.service \
  prabal-dnp3-master.service prabal-riverbend-console.service prabal-dnp3-capture.service
sleep 4
"$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/validate.sh" --installed
echo "SCENARIO_RESET:COMPLETE"
