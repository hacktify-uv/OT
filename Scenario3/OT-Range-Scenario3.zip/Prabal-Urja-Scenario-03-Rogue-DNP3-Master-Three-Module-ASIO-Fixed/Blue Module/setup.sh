#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_ROOT=/opt/prabal-urja/scenario3
CHALLENGE="$SCRIPT_DIR/Challenge-Files"

fail() { echo "[ERROR] $*" >&2; exit 1; }
info() { echo "[+] $*"; }

[[ ${EUID} -eq 0 ]] || fail "Run as root: sudo bash setup.sh"
[[ -r /etc/os-release ]] || fail "Cannot identify operating system"
# shellcheck disable=SC1091
source /etc/os-release
[[ "${ID:-}" == "ubuntu" || "${ID:-}" == "arch" ]] || echo "[!] WARNING: Ubuntu Server or Arch Linux is required. Detected: ${ID:-unknown}"
if [[ "${ID:-}" == "ubuntu" ]]; then
  case "${VERSION_ID:-}" in 22.04|24.04) ;; *) echo "[!] WARNING: Supported releases are Ubuntu 22.04 and 24.04; found ${VERSION_ID:-unknown}" ;; esac
fi

info "Installing native build and monitoring dependencies"
bash "$SCRIPT_DIR/deps.sh"

if ! id prabal-s03 >/dev/null 2>&1; then
  useradd --system --home-dir /var/lib/prabal-urja/scenario3 --shell /usr/sbin/nologin prabal-s03
fi

info "Installing challenge files"
install -d -m 0755 /opt/prabal-urja "$INSTALL_ROOT"
rm -rf "$INSTALL_ROOT/config" "$INSTALL_ROOT/source" "$INSTALL_ROOT/process" "$INSTALL_ROOT/hmi" "$INSTALL_ROOT/tools" "$INSTALL_ROOT/vendor-cache" "$INSTALL_ROOT/wheelhouse"
install -d -m 0755 "$INSTALL_ROOT/source/opendnp3" "$INSTALL_ROOT/vendor-cache"
cp -a "$CHALLENGE/config" "$INSTALL_ROOT/"
cp -a "$CHALLENGE/opendnp3/source/." "$INSTALL_ROOT/source/opendnp3/"
cp -a "$CHALLENGE/process" "$INSTALL_ROOT/"
cp -a "$CHALLENGE/hmi" "$INSTALL_ROOT/"
cp -a "$CHALLENGE/tools" "$INSTALL_ROOT/"
cp -a "$CHALLENGE/wheelhouse" "$INSTALL_ROOT/"
if [[ -d "$CHALLENGE/vendor-cache" ]]; then cp -a "$CHALLENGE/vendor-cache/." "$INSTALL_ROOT/vendor-cache/"; fi
install -m 0755 "$CHALLENGE/vendor/prepare-opendnp3.sh" "$INSTALL_ROOT/prepare-opendnp3.sh"

info "Using system Python; no PyPI packages are required"
python3 -c 'import json, http.server, pathlib'

info "Building genuine OpenDNP3 2.3.0 components"
bash "$INSTALL_ROOT/prepare-opendnp3.sh" "$INSTALL_ROOT"
for binary in prabal-dnp3-outstation prabal-dnp3-master prabal-dnp3-command; do
  [[ -x "$INSTALL_ROOT/bin/$binary" ]] || fail "OpenDNP3 build did not produce $binary"
done

info "Preparing runtime, historian, and packet-capture storage"
install -d -o prabal-s03 -g prabal-s03 -m 0771 \
  /var/lib/prabal-urja/scenario3 /var/log/prabal-urja/scenario3
chmod 0755 /var/lib/prabal-urja /var/log/prabal-urja 2>/dev/null || true
chmod 0771 /var/lib/prabal-urja/scenario3 /var/log/prabal-urja/scenario3 2>/dev/null || true
install -d -o root -g prabal-s03 -m 0770 /var/log/prabal-urja/scenario3/pcap
install -d -o prabal-s03 -g prabal-s03 -m 0770 /run/prabal-s03
install -m 0640 -o prabal-s03 -g prabal-s03 "$INSTALL_ROOT/config/initial-state.json" /var/lib/prabal-urja/scenario3/state.json
: > /var/log/prabal-urja/scenario3/process-events.jsonl
: > /var/log/prabal-urja/scenario3/dnp3-commands.jsonl
: > /run/prabal-s03/accepted-commands.jsonl
chown prabal-s03:prabal-s03 /var/log/prabal-urja/scenario3/process-events.jsonl /run/prabal-s03/accepted-commands.jsonl
chown root:prabal-s03 /var/log/prabal-urja/scenario3/dnp3-commands.jsonl
chmod 0660 /var/log/prabal-urja/scenario3/*.jsonl /run/prabal-s03/accepted-commands.jsonl
chown -R root:root "$INSTALL_ROOT"
chmod -R a+rX "$INSTALL_ROOT"
chmod 0755 "$INSTALL_ROOT"/tools/* "$INSTALL_ROOT"/process/*.py "$INSTALL_ROOT"/hmi/operator_console.py

info "Installing systemd units"
for unit in "$CHALLENGE/systemd"/*.service; do
  install -m 0644 "$unit" "/etc/systemd/system/$(basename "$unit")"
done
systemctl daemon-reload
systemctl disable --now prabal-s03-hardening.service 2>/dev/null || true
rm -f /etc/prabal-urja/scenario3/hardening.env

systemctl enable --now prabal-s03-firewall.service
systemctl enable --now prabal-riverbend-process.service
for _ in {1..20}; do
  [[ -s /run/prabal-s03/rtu_state.csv ]] && break
  sleep 0.5
done
[[ -s /run/prabal-s03/rtu_state.csv ]] || fail "Process model did not publish RTU state"
systemctl enable --now prabal-dnp3-command-monitor.service
systemctl enable --now prabal-dnp3-outstation.service
systemctl enable --now prabal-dnp3-master.service
systemctl enable --now prabal-riverbend-console.service
systemctl enable --now prabal-dnp3-capture.service

info "Performing fail-closed acceptance checks"
bash "$SCRIPT_DIR/validate.sh" --installed

echo
printf '%s\n' "Scenario 03 installed successfully." \
  "DNP3 maintenance listener: tcp/20001" \
  "River Bend operator console: http://<SERVER-IP>:8092" \
  "Run: sudo $SCRIPT_DIR/validate.sh"

# S03_ROOT_ROBOTS_SETUP_BEGIN
python3 - <<'PY_S03_ROBOTS'
from pathlib import Path
import ast
import re

p = Path("/opt/prabal-urja/scenario3/hmi/operator_console.py")
robots = p.parent / "static" / "robots.txt"
content = 'User-agent: *\nDisallow: /static/engineering.json\n'
route = '# S03_ROOT_ROBOTS_ROUTE\nif path == "/robots.txt":\n    from pathlib import Path\n    try:\n        body = (Path(__file__).resolve().parent / "static" / "robots.txt").read_bytes()\n    except OSError:\n        self.send_error(404)\n        return\n    self.send_response(200)\n    self.send_header("Content-Type", "text/plain; charset=utf-8")\n    self.send_header("Content-Length", str(len(body)))\n    self.end_headers()\n    self.wfile.write(body)\n    return\n'

if p.is_file():
    text = p.read_text()
    if "# S03_ROOT_ROBOTS_ROUTE" not in text:
        lines = text.splitlines(keepends=True)
        matches = [i for i, line in enumerate(lines)
                   if 'if path.startswith("/static/"):' in line]
        if len(matches) != 1:
            raise SystemExit("Cannot locate the HMI static route")
        i = matches[0]
        indent = re.match(r"\s*", lines[i]).group()
        addition = "".join(indent + x + "\n"
                           for x in route.splitlines())
        updated = "".join(lines[:i]) + addition + "".join(lines[i:])
        ast.parse(updated)
        p.write_text(updated)
    robots.parent.mkdir(parents=True, exist_ok=True)
    robots.write_text(content)
    robots.chmod(0o644)
    # S03_ENGINEERING_DEPLOY
    import base64
    engineering = robots.parent / "engineering.json"
    engineering.write_bytes(base64.b64decode("ewogICJkb2N1bWVudCI6ICJSaXZlciBCZW5kIFJUVSBFbmdpbmVlcmluZyBQb2ludCBSZWdpc3RlciIsCiAgInN0YXRpb24iOiAiUml2ZXIgQmVuZCAyMjAvMTMyIGtWIFN1YnN0YXRpb24iLAogICJhc3NldCI6ICJQVS1SQi1SVFUtMDciLAogICJwcm90b2NvbCI6ICJETlAzL1RDUCIsCiAgImRucDNfY29ubmVjdGlvbiI6IHsKICAgICJvdXRzdGF0aW9uX2FkZHJlc3MiOiAxMCwKICAgICJtYWludGVuYW5jZV9tYXN0ZXJfYWRkcmVzcyI6IDIsCiAgICAibWFpbnRlbmFuY2VfcG9ydCI6IDIwMDAxCiAgfSwKICAiYmluYXJ5X2lucHV0cyI6IHsKICAgICIwIjogIlJCLUZEUi1BLTUyQSBicmVha2VyIGNsb3NlZCBpbmRpY2F0aW9uIiwKICAgICIxIjogIlJCLUJULTUyQiBidXMtdGllIGJyZWFrZXIgY2xvc2VkIGluZGljYXRpb24iLAogICAgIjIiOiAiUkItRkRSLUItNTJDIGJyZWFrZXIgY2xvc2VkIGluZGljYXRpb24iLAogICAgIjMiOiAiUmVtb3RlIGNvbnRyb2wgZW5hYmxlZCIsCiAgICAiNCI6ICJDb3JyaWRvciBvdmVybG9hZCBhbGFybSIsCiAgICAiNSI6ICJDb21tYW5kIGxvY2tvdXQgYWN0aXZlIgogIH0sCiAgImJpbmFyeV9vdXRwdXRzIjogewogICAgIjAiOiAiUkItRkRSLUEtNTJBIGJyZWFrZXIgY29tbWFuZCIsCiAgICAiMSI6ICJSQi1CVC01MkIgYnVzLXRpZSBicmVha2VyIGNvbW1hbmQiLAogICAgIjIiOiAiUkItRkRSLUItNTJDIGJyZWFrZXIgY29tbWFuZCIKICB9LAogICJhbmFsb2dfaW5wdXRzIjogewogICAgIjAiOiAiRmVlZGVyIEEgYWN0aXZlIHBvd2VyIE1XIiwKICAgICIxIjogIkZlZWRlciBCIGFjdGl2ZSBwb3dlciBNVyIsCiAgICAiMiI6ICJSaXZlciBCZW5kIGJ1cyB2b2x0YWdlIGtWIiwKICAgICIzIjogIlRyYW5zZm9ybWVyIGxvYWRpbmcgcGVyY2VudCIsCiAgICAiNCI6ICJOb3J0aGVybiBjb3JyaWRvciBsb2FkaW5nIHBlcmNlbnQiLAogICAgIjUiOiAiU3lzdGVtIGZyZXF1ZW5jeSBIeiIKICB9LAogICJjb3VudGVycyI6IHsKICAgICIwIjogIkFjY2VwdGVkIHN3aXRjaGluZy1vcGVyYXRpb24gY291bnQiCiAgfQp9Cg=="))
    engineering.chmod(0o644)
PY_S03_ROBOTS

if command -v systemctl >/dev/null 2>&1 &&
   systemctl is-active --quiet prabal-riverbend-console.service; then
    systemctl restart prabal-riverbend-console.service
fi
# S03_ROOT_ROBOTS_SETUP_END

