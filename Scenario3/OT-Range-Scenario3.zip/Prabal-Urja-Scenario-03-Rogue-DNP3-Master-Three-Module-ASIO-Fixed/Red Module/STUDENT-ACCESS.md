# Red Student Access

Provide only the dynamically assigned Scenario 03 target IP or routed target
segment and Red workstation access. Do not provide the DNP3 port, addresses,
point map or switching sequence.
