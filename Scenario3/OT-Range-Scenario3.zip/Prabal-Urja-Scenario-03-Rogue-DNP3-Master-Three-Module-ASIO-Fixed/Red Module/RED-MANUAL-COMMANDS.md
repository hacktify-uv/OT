# Red Manual Commands

```bash
export TARGET=<SCENARIO_3_IP>
export DNP3=/opt/prabal-red-tools/prabal-dnp3-command
./Red-Team-Attack-Script.sh "$TARGET"
```

Follow `Red-Writeup.md` for the investigation and evidence procedure. Do not
flood, fuzz, stop the legitimate master or open both feeders.
