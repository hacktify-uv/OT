# Scenario 03 — Red Team Module

This is a complete standalone deployment of the Rogue DNP3 Master at River Bend
Substation challenge for the **Red Team** workflow.

```bash
sudo bash deps.sh
sudo bash setup.sh
sudo bash validate.sh --installed
```

Operator console: `http://<DYNAMIC_TARGET_IP>:8092`

No deployment IP is hardcoded. The installer uses genuine OpenDNP3 2.3.0 and
automatically selects compatible ASIO headers on Ubuntu 22.04/24.04.
