#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
MODE="${1:-static}"
MODULE_NAME="Red-vs-Blue Module"
required=(
  setup.sh deps.sh reset.sh validate.sh README-FIRST.md Description.md PACKAGE.sha256
  TTP/Setup-TTP.yml TTP/Service-Availability-TTP.yml
  Challenge-Files/vendor/prepare-opendnp3.sh
  Challenge-Files/opendnp3/source/prabal_outstation.cpp
  Challenge-Files/opendnp3/source/prabal_master.cpp
  Challenge-Files/opendnp3/source/prabal_command.cpp
  Challenge-Files/process/grid_process.py
  Challenge-Files/process/dnp3_command_monitor.py
  Challenge-Files/hmi/operator_console.py
  Challenge-Files/tools/service_availability.sh
)
required+=(
  Red-Writeup.md
  Blue-Writeup.md
  Red-Team-Attack-Script.sh
  Blue-Investigation.sh
  Blue-Containment.sh
  Operator-Attack-Trigger.sh
  RED-MANUAL-COMMANDS.md
  BLUE-MANUAL-COMMANDS.md
  RED-STUDENT-ACCESS.md
  BLUE-STUDENT-ACCESS.md
  TTP/Attack-TTP.yml
)
for path in "${required[@]}"; do [[ -e "$SCRIPT_DIR/$path" ]] || { echo "MISSING:$path" >&2; exit 1; }; done
bash -n "$SCRIPT_DIR/setup.sh" "$SCRIPT_DIR/deps.sh" "$SCRIPT_DIR/reset.sh" "$SCRIPT_DIR/validate.sh"
find "$SCRIPT_DIR" -type f -name '*.sh' ! -path '*/vendor/*' -print0 | xargs -0 -r -n1 bash -n
PYCACHE_TMP="$(mktemp -d)"; trap 'rm -rf "$PYCACHE_TMP"' EXIT
PYTHONPYCACHEPREFIX="$PYCACHE_TMP" python3 -m py_compile "$SCRIPT_DIR/Challenge-Files/process/grid_process.py" "$SCRIPT_DIR/Challenge-Files/process/dnp3_command_monitor.py" "$SCRIPT_DIR/Challenge-Files/hmi/operator_console.py" "$SCRIPT_DIR/Challenge-Files/tools/operator_restore.py"
python3 - "$SCRIPT_DIR" <<'PYJSON'
import json, sys
from pathlib import Path
root=Path(sys.argv[1])
for path in root.rglob('*.json'): json.loads(path.read_text())
print('JSON_VALID')
PYJSON
if python3 -c 'import yaml' >/dev/null 2>&1; then
python3 - "$SCRIPT_DIR" <<'PYYAML'
import sys, yaml
from pathlib import Path
root=Path(sys.argv[1])
for path in (root/'TTP').glob('*.yml'): yaml.safe_load(path.read_text())
print('YAML_VALID')
PYYAML
fi
grep -Fq 'ASIO_COMPAT_VERSION=101202' "$SCRIPT_DIR/Challenge-Files/vendor/prepare-opendnp3.sh" || { echo ASIO_COMPAT_VERSION_MISSING >&2; exit 1; }
grep -Fq '"$ASIO_VER" -gt "$ASIO_COMPAT_VERSION"' "$SCRIPT_DIR/Challenge-Files/vendor/prepare-opendnp3.sh" || { echo ASIO_COMPAT_SELECTION_INVALID >&2; exit 1; }
if [[ -f "$SCRIPT_DIR/Challenge-Files/vendor-cache/opendnp3-2.3.0.tar.gz" ]]; then tar -tzf "$SCRIPT_DIR/Challenge-Files/vendor-cache/opendnp3-2.3.0.tar.gz" 'opendnp3-2.3.0/CMakeLists.txt' >/dev/null || { echo OPENDNP3_CACHE_INVALID >&2; exit 1; }; fi
if [[ "$MODE" == --installed ]]; then [[ ${EUID} -eq 0 ]] || { echo "Installed validation requires root" >&2; exit 1; }; TTP_CMD="$(sed -n '/^    command: >-/{n;s/^      //;p;q;}' "$SCRIPT_DIR/TTP/Service-Availability-TTP.yml")"; [[ -n "$TTP_CMD" ]] || { echo INLINE_TTP_MISSING >&2; exit 1; }; bash -c "$TTP_CMD"; jq -e '.scenario_state != null' /var/lib/prabal-urja/scenario3/state.json >/dev/null; fi
echo "VALIDATION:PASS module=$MODULE_NAME"
