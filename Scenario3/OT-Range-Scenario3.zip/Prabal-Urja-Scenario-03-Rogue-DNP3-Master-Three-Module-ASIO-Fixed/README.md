# Prabal Urja Scenario 03 — Rogue DNP3 Master

This release contains three independently runnable challenge directories:

- `Red Module/` — Red deployment, attack tooling and Red writeup.
- `Blue Module/` — Blue deployment, investigation/containment tooling and an operator-only attack trigger.
- `Red-vs-Blue Module/` — combined live-fire deployment with both role workflows.

Every module includes its own `setup.sh`, `deps.sh`, `reset.sh`, `validate.sh`,
`Challenge-Files/`, TTP files and integrity manifest.

The OpenDNP3 2.3.0 build logic includes the Ubuntu 22.04/24.04 ASIO compatibility
fix. If the system ASIO headers are newer than 1.12.2, setup automatically uses
pinned ASIO 1.12.2 headers.

## Installation

Choose exactly one module on a clean supported VM:

```bash
cd "Red Module"                 # or Blue Module / Red-vs-Blue Module
sudo bash setup.sh
sudo bash validate.sh --installed
```

Do not install multiple modules on the same VM simultaneously because all three
use the same Scenario 03 service names and runtime paths.
