# Changelog

## Three-module ASIO-fixed release

- Added complete Red, Blue and Red-vs-Blue module directories.
- Applied the OpenDNP3 2.3.0 fallback for newer standalone ASIO releases.
- Added independent setup, reset, validation, TTP and checksum files to each module.
- Added Red attack and Blue investigation/containment helpers.
- Removed development build output from the release package.
