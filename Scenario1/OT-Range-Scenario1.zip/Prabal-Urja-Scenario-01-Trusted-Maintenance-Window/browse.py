import asyncio
from asyncua import Client

async def walk(node, namespace_index, depth=0, max_depth=8):
    if depth > max_depth: return
    try:
        browse_name = await node.read_browse_name()
        print("  " * depth + f"{node.nodeid.to_string()} | {browse_name.Name}")
    except: return
    for child in await node.get_children():
        if child.nodeid.NamespaceIndex == namespace_index:
            await walk(child, namespace_index, depth + 1, max_depth)

async def main():
    # YOUR EXACT IP HARDCODED HERE
    endpoint = "opc.tcp://192.168.52.129:4840"
    async with Client(url=endpoint, timeout=5) as client:
        idx = await client.get_namespace_index("urn:prabal-urja:hydro:unit2")
        await walk(client.nodes.objects, idx)

asyncio.run(main())
