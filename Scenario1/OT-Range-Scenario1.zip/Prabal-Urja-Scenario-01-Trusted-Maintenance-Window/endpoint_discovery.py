import asyncio
import os
from asyncua import Client

async def main():
    endpoint = f"opc.tcp://{os.environ['TARGET_IP']}:4840"
    client = Client(url=endpoint, timeout=5)
    endpoints = await client.connect_and_get_server_endpoints()

    for item in endpoints:
        print("EndpointURL:", item.EndpointUrl)
        print("SecurityPolicyUri:", item.SecurityPolicyUri)
        print("SecurityMode:", item.SecurityMode)
        print("UserIdentityTokens:", [token.TokenType for token in item.UserIdentityTokens])
        print("---")

asyncio.run(main())
