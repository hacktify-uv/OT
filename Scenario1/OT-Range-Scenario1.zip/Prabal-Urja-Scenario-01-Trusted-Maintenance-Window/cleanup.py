import asyncio
from asyncua import Client, ua

NS_URI = "urn:prabal-urja:hydro:unit2"
BASE = "PrabalUrja/HydroPlant/Unit2/TelemetryGateway"

async def main():
    endpoint = "opc.tcp://192.168.52.129:4840"
    async with Client(url=endpoint, timeout=5) as client:
        idx = await client.get_namespace_index(NS_URI)
        changes = [
            ("AlarmSuppression", False, ua.VariantType.Boolean),
            ("FreezeTelemetry", False, ua.VariantType.Boolean),
            ("MaintenanceMode", False, ua.VariantType.Boolean),
            ("MaintenanceTicket", "", ua.VariantType.String),
        ]
        print("[*] Rolling back maintenance overrides...")
        for name, value, kind in changes:
            node = client.get_node(f"ns={idx};s={BASE}/{name}")
            await node.write_value(ua.Variant(value, kind))
            print(f"[+] Reverted {name}")
        print("[+] Telemetry restored to NORMAL_OPERATION.")

asyncio.run(main())
