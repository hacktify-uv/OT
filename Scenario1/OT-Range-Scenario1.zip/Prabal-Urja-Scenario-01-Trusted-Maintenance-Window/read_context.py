import asyncio
import os
from asyncua import Client

NS_URI = "urn:prabal-urja:hydro:unit2"
BASE = "PrabalUrja/HydroPlant/Unit2"

NODES = {
    "work_order": f"{BASE}/EngineeringMetadata/LastApprovedWorkOrder",
    "downstream_controller": f"{BASE}/EngineeringMetadata/DownstreamController",
    "southbound_protocol": f"{BASE}/EngineeringMetadata/SouthboundProtocol",
    "maintenance_mode": f"{BASE}/TelemetryGateway/MaintenanceMode",
    "freeze_telemetry": f"{BASE}/TelemetryGateway/FreezeTelemetry",
    "alarm_suppression": f"{BASE}/TelemetryGateway/AlarmSuppression",
    "ticket": f"{BASE}/TelemetryGateway/MaintenanceTicket",
    "override_accepted": f"{BASE}/TelemetryGateway/OverrideAccepted",
    "scenario_state": f"{BASE}/Health/ScenarioState",
}

async def main():
    endpoint = f"opc.tcp://{os.environ['TARGET_IP']}:4840"

    async with Client(url=endpoint, timeout=5) as client:
        idx = await client.get_namespace_index(NS_URI)

        for label, node_id in NODES.items():
            node = client.get_node(f"ns={idx};s={node_id}")
            value = await node.read_value()

            try:
                access = await node.get_access_level()
            except Exception as exc:
                access = f"access-read-error: {exc}"

            print(f"{label}: value={value!r} access={access}")

asyncio.run(main())
