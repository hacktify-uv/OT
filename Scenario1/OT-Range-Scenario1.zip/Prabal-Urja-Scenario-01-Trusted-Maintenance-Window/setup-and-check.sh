#!/usr/bin/env bash
set -Eeuo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
[[ -x "$HERE/setup.sh" ]] || { echo 'Original setup.sh not executable; inspect before running' >&2; exit 3; }
echo 'Running original scenario installation; review its effects and use an isolated VM.'
"$HERE/setup.sh"
if [[ -x "$HERE/validate.sh" ]]; then "$HERE/validate.sh"; else echo 'NO ROOT VALIDATE: check module-specific validator'; fi
echo 'Installer exited. Real protocol operation and cross-scenario continuity still require testing.'
