#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

ENV_FILE=/etc/prabal-urja/scenario1.env
[[ -r "$ENV_FILE" ]] || { echo "VALIDATION:FAIL missing=$ENV_FILE"; exit 1; }
# shellcheck disable=SC1091
source "$ENV_FILE"

FAIL=0
check() {
  local name="$1"
  shift
  if "$@"; then
    echo "[PASS] $name"
  else
    echo "[FAIL] $name"
    FAIL=1
  fi
}

check "OPC UA systemd service" systemctl is-active --quiet prabal-opcua.service
check "HMI systemd service" systemctl is-active --quiet prabal-hmi.service
check "Packet capture systemd service" systemctl is-active --quiet prabal-opcua-capture.service
check "OPC UA listening port $OPCUA_PORT" bash -c "ss -ltn | grep -Eq ':${OPCUA_PORT}[[:space:]]'"
check "HMI listening port $HMI_PORT" bash -c "ss -ltn | grep -Eq ':${HMI_PORT}[[:space:]]'"
check "Protocol-aware OPC UA read" /opt/prabal-urja/scenario1/venv/bin/python /opt/prabal-urja/scenario1/tools/opcua_probe.py --endpoint "opc.tcp://127.0.0.1:${OPCUA_PORT}" --timeout 4
check "HMI functional health endpoint" bash -c "curl -fsS --connect-timeout 3 --max-time 6 http://127.0.0.1:${HMI_PORT}/api/health | jq -e '.status == \"up\" and .opcua_connected == true' >/dev/null"
check "HMI webroot presentation" bash -c "curl -fsS --connect-timeout 3 --max-time 6 http://127.0.0.1:${HMI_PORT}/ | grep -Fq 'Prabal Urja'"

if (( FAIL != 0 )); then
  echo "VALIDATION:FAIL"
  exit 1
fi
echo "VALIDATION:PASS"
