# The Trusted Maintenance Window

Prabal Urja Hydroelectric Power Station is operating Unit-2 during a period of elevated regional demand. A scheduled vendor maintenance window was recently approved to investigate intermittent telemetry quality from the unit's engineering data gateway.

Shift supervisor **Ananya Rao** has reported that the operator display remains stable, but field staff have observed small differences between locally indicated conditions and values presented in the control room. Maintenance engineer **Raghav Menon** has been asked to verify whether the approved work was completed correctly and whether any connected system has been used outside its intended purpose.

Red and Blue teams operate on the same live exercise infrastructure. The Red Team must assess whether the maintenance pathway can be used to create an unauthorised operational effect while preserving service availability. The Blue Team must identify abnormal activity, determine the true process condition, contain the incident with minimal operational interruption, and return the unit to a trusted state.

This is an intermediate OT live-fire scenario. Actions that indiscriminately disrupt the operating system, flood the network, or crash industrial services are outside the rules of engagement.
