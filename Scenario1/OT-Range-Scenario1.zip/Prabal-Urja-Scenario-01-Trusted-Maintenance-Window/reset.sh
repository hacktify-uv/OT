#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

PRESERVE=0
if [[ "${1:-}" == "--preserve-evidence" ]]; then
  PRESERVE=1
elif [[ $# -gt 0 ]]; then
  echo "Usage: sudo ./reset.sh [--preserve-evidence]" >&2
  exit 2
fi

if [[ $EUID -ne 0 ]]; then
  echo "Run as root." >&2
  exit 1
fi

ENV_FILE=/etc/prabal-urja/scenario1.env
[[ -f "$ENV_FILE" ]] || { echo "Scenario is not installed." >&2; exit 1; }
# shellcheck disable=SC1091
source "$ENV_FILE"

if (( PRESERVE == 1 )); then
  /opt/prabal-urja/scenario1/tools/collect_evidence.sh /var/tmp/prabal-s01-pre-reset
fi

systemctl stop prabal-hmi.service prabal-opcua-capture.service prabal-opcua.service
sed -i 's/^OPCUA_ALLOW_REMOTE_WRITE=.*/OPCUA_ALLOW_REMOTE_WRITE=1/' "$ENV_FILE"
nft delete table inet prabal_s01 2>/dev/null || true

rm -f /var/log/prabal-urja/pcap/*.pcap* 2>/dev/null || true
install -o prabalot -g prabalot -m 0640 /dev/null /var/log/prabal-urja/opcua-audit.log
install -o prabalot -g prabalot -m 0640 /dev/null /var/log/prabal-urja/process-actual.log

systemctl start prabal-opcua.service
sleep 2
systemctl start prabal-hmi.service prabal-opcua-capture.service
sleep 4
"$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/validate.sh"
echo "RESET_COMPLETE scenario=Prabal-Urja-S01 vulnerable_state=restored"
