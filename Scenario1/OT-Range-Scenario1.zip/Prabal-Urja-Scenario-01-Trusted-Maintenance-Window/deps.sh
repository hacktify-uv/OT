#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

if [[ $EUID -ne 0 ]]; then
  echo "Run deps.sh as root: sudo bash deps.sh" >&2
  exit 1
fi

SKIP_UPDATE="${PRABAL_SKIP_APT_UPDATE:-0}"

echo "[+] Detecting Linux distribution and package manager..."

install_pacman() {
  echo "[+] Arch/Manjaro detected."

  if [[ "$SKIP_UPDATE" != "1" ]]; then
    pacman -Sy --noconfirm
  fi

  pacman -S --needed --noconfirm \
    base-devel \
    bash \
    ca-certificates \
    cmake \
    curl \
    git \
    iproute2 \
    jq \
    openssl \
    openbsd-netcat \
    nftables \
    pkgconf \
    python \
    python-pip \
    tcpdump \
    systemd
}

install_apt() {
  echo "[+] Debian/Ubuntu/Kali/Parrot detected."

  export DEBIAN_FRONTEND=noninteractive

  if [[ "$SKIP_UPDATE" != "1" ]]; then
    apt-get update
  fi

  apt-get install -y --no-install-recommends \
    bash \
    build-essential \
    ca-certificates \
    cmake \
    curl \
    git \
    iproute2 \
    jq \
    libssl-dev \
    netcat-openbsd \
    nftables \
    pkg-config \
    python3 \
    python3-pip \
    python3-venv \
    tcpdump \
    systemd
}

install_dnf_yum() {
  local PKG_MGR="$1"

  echo "[+] RHEL/Fedora/Rocky/Alma detected using $PKG_MGR."

  if [[ "$SKIP_UPDATE" != "1" ]]; then
    "$PKG_MGR" makecache || true
  fi

  "$PKG_MGR" install -y \
    bash \
    gcc \
    gcc-c++ \
    make \
    ca-certificates \
    cmake \
    curl \
    git \
    iproute \
    jq \
    openssl-devel \
    nmap-ncat \
    nftables \
    pkgconf-pkg-config \
    python3 \
    python3-pip \
    python3-devel \
    tcpdump \
    systemd
}

install_zypper() {
  echo "[+] openSUSE detected."

  if [[ "$SKIP_UPDATE" != "1" ]]; then
    zypper --non-interactive refresh
  fi

  zypper --non-interactive install --no-recommends \
    bash \
    gcc \
    gcc-c++ \
    make \
    ca-certificates \
    cmake \
    curl \
    git \
    iproute2 \
    jq \
    libopenssl-devel \
    netcat-openbsd \
    nftables \
    pkg-config \
    python3 \
    python3-pip \
    python3-devel \
    tcpdump \
    systemd
}

if command -v apt-get >/dev/null 2>&1; then
  install_apt
elif command -v dnf >/dev/null 2>&1; then
  install_dnf_yum dnf
elif command -v yum >/dev/null 2>&1; then
  install_dnf_yum yum
elif command -v pacman >/dev/null 2>&1; then
  install_pacman
elif command -v zypper >/dev/null 2>&1; then
  install_zypper
else
  echo "[!] ERROR: Unsupported package manager." >&2
  echo "[!] Supported package managers: apt-get, dnf, yum, pacman, zypper." >&2
  echo "[!] Alpine/OpenRC is not supported by this systemd-based release." >&2
  exit 1
fi

echo "[+] Dependencies installed successfully."
