# Prabal Urja Campaign — Overall Network Architecture

> The addresses in this document are exercise-planning addresses only. `195.0.0.0/8` is not RFC 1918 space and must remain completely isolated from production routing and the public internet.

```mermaid
flowchart LR
    RED[Red Team Enclave\n195.10.10.0/24] --> FW[Exercise Core Firewall]
    FW --> VDMZ[Vendor / OT Access Zone\n195.20.10.0/24]
    FW --> CTRL[Control Centre Zone\n195.30.10.0/24]
    FW --> HYDRO[Hydro Plant Control Zone\n195.40.10.0/24]
    FW --> SUB[Substation Zones\n195.50.10.0/24]
    FW --> PROC[Power Process Simulation\n195.60.10.0/24]
    FW --> SOC[Blue SOC Zone\n195.70.10.0/24]

    VDMZ --> S1[Scenario 1\nPU-OPCUA-GW-01\n195.20.10.21]
    HYDRO --> S2[Scenario 2\nPU-GOV-PLC-02\n195.40.10.41]
    SUB --> S3[Scenario 3\nPU-DNP3-RTU-01\n195.50.10.51]
    CTRL --> S4[Scenario 4\nPU-IEC104-SCADA-01\n195.30.10.31]
    SUB --> S5[Scenario 5\nPU-IEC61850-SS-01\n195.50.10.61]

    S1 -. engineering relationship .-> S2
    S2 -. operating stress .-> S3
    S3 -. switching consequence .-> S4
    S4 -. protection dependency .-> S5
    S2 --> PROC
    S3 --> PROC
    S4 --> PROC
    S5 --> PROC
    SOC -. monitoring .-> VDMZ
    SOC -. monitoring .-> CTRL
    SOC -. monitoring .-> HYDRO
    SOC -. monitoring .-> SUB
```

## ASCII fallback

```text
 Red Enclave            Vendor / OT Access             Hydro Plant Control
 195.10.10.0/24         195.20.10.0/24                 195.40.10.0/24
 [Red Workstation] ---> [S1 PU-OPCUA-GW-01]  -pivot->  [S2 PU-GOV-PLC-02]
                              |                               |
                              |                               v
                              |                         Process Simulator
                              |                         195.60.10.0/24
                              v                               ^
 Control Centre          [S4 IEC-104 SCADA] -----------------|
 195.30.10.0/24                 ^                             |
                                |                             |
 Substation Zone          [S3 DNP3 RTU] -----> [S5 IEC 61850 IEDs]
 195.50.10.0/24

 Blue SOC 195.70.10.0/24 receives mirrored traffic and host telemetry.
```

## Campaign sequence

1. Scenario 1 exposes the engineering relationship to `PU-GOV-PLC-02`.
2. Scenario 2 creates reduced generation and transmission margin.
3. Scenario 3 changes remote feeder topology through DNP3.
4. Scenario 4 coordinates control-centre switching through IEC-104.
5. Scenario 5 interferes with digital-substation protection through IEC 61850.
