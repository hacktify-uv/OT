# Attack and Pivot Path

## Scenario 1 path

```text
Red Workstation
    |
    | network discovery within authorised exercise scope
    v
PU-OPCUA-GW-01
    |
    | OPC UA endpoint and information-model discovery
    v
Unit-2 TelemetryGateway maintenance controls
    |
    | unauthorised maintenance state using a legitimate work-order reference
    v
Frozen operator telemetry + alarm suppression
    |
    | engineering metadata discovered in the same namespace
    v
PU-GOV-PLC-02 / Modbus-TCP relationship
    |
    +----> Scenario 2, after Scenario 2 is approved and deployed
```

## Why the pivot is justified

Industrial data gateways commonly contain engineering metadata that maps northbound telemetry tags to southbound controllers. Scenario 1 therefore exposes only the downstream asset identifier and interface type. It does not expose a password, a hidden CTF token, or the next host's runtime IP.

The range orchestrator maps `PU-GOV-PLC-02` to the Scenario 2 machine when that scenario is deployed. This preserves realistic discovery while allowing each scenario package to remain independently installable.

## Red-team boundary

Scenario 1 is complete when the maintenance override is accepted and the participant records the downstream controller relationship. Red must not scan or attack undeployed stages.
