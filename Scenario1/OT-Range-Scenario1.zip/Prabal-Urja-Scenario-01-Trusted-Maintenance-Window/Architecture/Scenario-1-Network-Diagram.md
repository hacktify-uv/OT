# Scenario 1 Network Diagram

## Administrative deployment view

```mermaid
flowchart LR
    R[Red Workstation\n195.10.10.x] -->|Exercise firewall| T[PU-OPCUA-GW-01\n195.20.10.21]
    B[Blue SOC\n195.70.10.x] -. mirrored traffic / investigation .-> T

    subgraph TGT[Ubuntu 22.04 or 24.04 Target]
      OPC[open62541 OPC UA Server\nTCP 4840]
      HMI[Prabal Urja Operator Console\nTCP 8088]
      CAP[tcpdump evidence capture]
      AUD[OPC UA audit log]
      PROC[actual process log]
      HMI -->|real OPC UA client session| OPC
      CAP -. observes .-> OPC
      OPC --> AUD
      OPC --> PROC
    end
```

## Runtime addressing

The setup script does not configure the network interface and does not embed `195.20.10.21` in code. The address is assigned by the exercise infrastructure. The services bind to their configured ports and the HMI uses loopback to reach the local OPC UA server.

## Intended communication matrix

| Source | Destination | Service | Expected purpose |
|---|---|---|---|
| Local HMI process | `127.0.0.1` | OPC UA/TCP 4840 | Continuous read-only telemetry |
| Approved engineering workstation | Scenario target | OPC UA/TCP 4840 | Time-bounded maintenance |
| Operators | Scenario target | HTTP/TCP 8088 | Read-only Unit-2 process display |
| Blue SOC sensor | mirrored exercise traffic | packet inspection | Detection and investigation |

A new remote OPC UA client, namespace-wide browse pattern, or write to maintenance controls outside an approved activity is anomalous.
