# Scenario Connectivity Contract

## Output produced by Scenario 1

The OPC UA engineering namespace contains:

- Asset: `PU-OPCUA-GW-01`
- Downstream controller: `PU-GOV-PLC-02`
- Southbound interface: `Modbus/TCP`
- Approved maintenance work order: `PU-MW-0427`

Only the controller identifier and protocol are intended to carry forward.

## Input expected by Scenario 2

When Scenario 2 is later approved, its deployment should register `PU-GOV-PLC-02` in the Hydro Plant Control Zone `195.40.10.0/24`. The orchestrator or exercise controller should provide routing from the compromised vendor-access position to the Scenario 2 network according to the campaign schedule.

## No hidden dependency

Scenario 1 does not require Scenario 2 to be online. The operator console, OPC UA process, success state, Blue Team investigation and reset are all self-contained.
