import asyncio
import os
from asyncua import Client, ua

NS_URI = "urn:prabal-urja:hydro:unit2"
BASE = "PrabalUrja/HydroPlant/Unit2/TelemetryGateway"

async def main():
    endpoint = f"opc.tcp://{os.environ['TARGET_IP']}:4840"

    async with Client(url=endpoint, timeout=5) as client:
        idx = await client.get_namespace_index(NS_URI)

        changes = [
            ("AlarmSuppression", False, ua.VariantType.Boolean),
            ("FreezeTelemetry", False, ua.VariantType.Boolean),
            ("MaintenanceMode", False, ua.VariantType.Boolean),
            ("MaintenanceTicket", "", ua.VariantType.String),
        ]

        for name, value, kind in changes:
            node = client.get_node(f"ns={idx};s={BASE}/{name}")
            await node.write_value(ua.Variant(value, kind))
            confirmed = await node.read_value()
            print(f"{name} -> {confirmed!r}")

asyncio.run(main())
