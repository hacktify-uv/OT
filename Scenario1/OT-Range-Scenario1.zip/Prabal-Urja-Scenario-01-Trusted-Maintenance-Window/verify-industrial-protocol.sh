#!/usr/bin/env bash
set -Eeuo pipefail
# This checks evidence supplied by a real deployed environment, not a text-only claim.
ROOT="$(cd "$(dirname "$0")" && pwd)"
EVIDENCE="${PRABAL_PROTOCOL_EVIDENCE:-$ROOT/protocol-evidence.pcapng}"
if [[ ! -s "$EVIDENCE" ]]; then
 echo "NOT VERIFIED: supply a packet capture via PRABAL_PROTOCOL_EVIDENCE" >&2; exit 2
fi
command -v tshark >/dev/null || { echo 'NOT VERIFIED: tshark missing' >&2; exit 2; }
tshark -r "$EVIDENCE" -Y 'opcua' -T fields -e frame.number 2>/dev/null | grep -q . || { echo 'NO OPC UA traffic' >&2; exit 1; }
echo 'PROTOCOL TRAFFIC DETECTED (functionality and access still require runtime testing)'
