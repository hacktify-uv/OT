# Blue Team Write-up — Scenario 1: The Trusted Maintenance Window

## 1. Defensive mission

The Blue Team must determine why Unit-2 operator telemetry appears stable while field observations indicate continuing process variation. The desired response is precise: preserve evidence, identify the unauthorised OPC UA activity, contain the source, restore trustworthy telemetry, harden the maintenance controls and validate that legitimate operations remain available.

Do not respond by shutting down the entire Ubuntu host or blocking all OT traffic.

## 2. Expected assets and services



| Asset | Purpose |
|---|---|
| `PU-OPCUA-GW-01` | Unit-2 engineering telemetry gateway |
| `prabal-opcua.service` | real open62541 OPC UA service |
| `prabal-hmi.service` | read-only Unit-2 operator console |
| `prabal-opcua-capture.service` | local rolling OPC UA packet capture |
| `/var/log/prabal-urja/opcua-audit.log` | maintenance-control audit events |
| `/var/log/prabal-urja/process-actual.log` | locally calculated actual process samples |

Default ports are 4840 and 8088, but always read `/etc/prabal-urja/scenario1.env` because the administrator may have changed them.

## 3. Initial detection and triage

### 3.1 Record incident time and analyst identity

```bash
date -u --iso-8601=seconds
whoami
hostname -f 2>/dev/null || hostname
```

Start an investigation log:

```bash
sudo install -d -m 0700 /var/tmp/prabal-s01-ir
sudo bash -c 'date -u --iso-8601=seconds > /var/tmp/prabal-s01-ir/analyst-notes.txt'
```

### 3.2 Confirm service availability

```bash
sudo systemctl --no-pager --full status \
  prabal-opcua.service \
  prabal-hmi.service \
  prabal-opcua-capture.service
```

```bash
sudo ss -plantu | tee /var/tmp/prabal-s01-ir/initial-sockets.txt
```

Run the package health check without changing state:

```bash
sudo /opt/prabal-urja/scenario1/venv/bin/python \
  /opt/prabal-urja/scenario1/tools/opcua_probe.py \
  --endpoint opc.tcp://127.0.0.1:4840 \
  | tee /var/tmp/prabal-s01-ir/opcua-health.json
```

### 3.3 Inspect the operator state

```bash
curl -sS http://127.0.0.1:8088/api/state \
  | jq . \
  | tee /var/tmp/prabal-s01-ir/hmi-state.json
```

Indicators requiring investigation include:

- `maintenance_mode: true`
- `freeze_telemetry: true`
- `alarm_suppression: true`
- `override_accepted: true`
- `telemetry_quality: UNCERTAIN_LAST_USABLE_VALUE`
- `scenario_state: UNAUTHORISED_MAINTENANCE_OVERRIDE`

## 4. Preserve evidence before containment

Use the provided collector:

```bash
sudo /opt/prabal-urja/scenario1/tools/collect_evidence.sh \
  /var/tmp/prabal-s01-evidence
```

The command prints the evidence directory and archive path. Copy the archive to the Blue Team evidence repository before modifying firewall rules or restarting services.

Verify the archive:

```bash
sha256sum -c /var/tmp/prabal-s01-evidence-*.tar.gz.sha256
```

Do not delete the live logs after collection.

## 5. Investigate OPC UA parameter changes

### 5.1 Review the dedicated audit trail

```bash
sudo grep -E \
  'SERVER_START|NODE_WRITE_DETECTED|OVERRIDE_ACTIVE|OVERRIDE_CLEARED' \
  /var/log/prabal-urja/opcua-audit.log \
  | tee /var/tmp/prabal-s01-ir/opcua-write-timeline.txt
```

A successful malicious sequence generally contains changes to:

```text
MaintenanceTicket
MaintenanceMode
FreezeTelemetry
AlarmSuppression
```

followed by:

```text
event=OVERRIDE_ACTIVE
```

Extract timestamps:

```bash
sudo awk '/NODE_WRITE_DETECTED|OVERRIDE_ACTIVE/ {print}' \
  /var/log/prabal-urja/opcua-audit.log
```

### 5.2 Review systemd journal data

```bash
sudo journalctl -u prabal-opcua.service \
  --since '2 hours ago' \
  --no-pager \
  | tee /var/tmp/prabal-s01-ir/opcua-journal.txt
```

```bash
sudo journalctl -u prabal-hmi.service \
  --since '2 hours ago' \
  --no-pager \
  | tee /var/tmp/prabal-s01-ir/hmi-journal.txt
```

Look for client connection activity near the first maintenance-node write and for interruptions in the normal HMI polling session.

### 5.3 Identify current remote sessions

```bash
sudo ss -tnp state established '( sport = :4840 )'
```

A legitimate local HMI session normally originates from loopback. A session from an unexpected exercise address is suspicious.

Do not rely only on current sockets because the attacker may disconnect after writing. Use the packet capture for historical attribution.

## 6. Analyse captured network evidence

List packet files:

```bash
sudo find /var/log/prabal-urja/pcap -maxdepth 1 -type f -printf '%TY-%Tm-%Td %TH:%TM:%TS %p\n' | sort
```

Basic connection review with tcpdump:

```bash
sudo tcpdump -nn -tttt -r /var/log/prabal-urja/pcap/opcua-evidence.pcap \
  'tcp port 4840' \
  | tee /var/tmp/prabal-s01-ir/opcua-packet-summary.txt
```

If the current capture is rotated, repeat for every matching file:

```bash
for pcap in /var/log/prabal-urja/pcap/opcua-evidence.pcap*; do
  echo "===== $pcap ====="
  sudo tcpdump -nn -tttt -r "$pcap" 'tcp port 4840'
done | tee /var/tmp/prabal-s01-ir/all-opcua-connections.txt
```

For protocol decoding, install or use a Blue forensic workstation with Wireshark/TShark and copy the evidence rather than installing unnecessary tools during the incident. Example:

```bash
tshark -r opcua-evidence.pcap -Y opcua | head -100
```

Investigative questions:

1. Which source IP opened a new OPC UA session?
2. Did it browse a large part of the namespace before writing?
3. Which packet sequence aligns with the first `NODE_WRITE_DETECTED` timestamp?
4. Was the local HMI session still active during the event?
5. Did the attacker use the same source for all writes?

Record the suspected source:

```bash
export ATTACKER_IP='<SUSPECTED_SOURCE_IP>'
printf 'Suspected source: %s\n' "$ATTACKER_IP" \
  | sudo tee -a /var/tmp/prabal-s01-ir/analyst-notes.txt
```

## 7. Prove that displayed telemetry is stale

Review actual local process samples:

```bash
sudo tail -30 /var/log/prabal-urja/process-actual.log \
  | tee /var/tmp/prabal-s01-ir/actual-process-tail.txt
```

During the override, the log records both:

- changing `actual_power_mw`; and
- a fixed `displayed_power_mw`.

Extract the relevant fields:

```bash
sudo awk '/PROCESS_SAMPLE/ {print $1, $4, $8, $9}' \
  /var/log/prabal-urja/process-actual.log \
  | tail -20
```

Compare with two HMI samples ten seconds apart:

```bash
curl -sS http://127.0.0.1:8088/api/state | jq . > /var/tmp/prabal-s01-ir/hmi-sample-1.json
sleep 10
curl -sS http://127.0.0.1:8088/api/state | jq . > /var/tmp/prabal-s01-ir/hmi-sample-2.json
jq '{active_power_mw,frequency_hz,telemetry_quality,override_accepted}' /var/tmp/prabal-s01-ir/hmi-sample-1.json
jq '{active_power_mw,frequency_hz,telemetry_quality,override_accepted}' /var/tmp/prabal-s01-ir/hmi-sample-2.json
```

This confirms a telemetry-integrity incident rather than a stopped physical process.

## 8. Contain the attacker without stopping legitimate operations

### 8.1 Apply a source-specific temporary block

Validate the suspected IP before using it. Then:

```bash
sudo nft list table inet prabal_s01 >/dev/null 2>&1 \
  || sudo nft add table inet prabal_s01

sudo nft list chain inet prabal_s01 input >/dev/null 2>&1 \
  || sudo nft 'add chain inet prabal_s01 input { type filter hook input priority -10; policy accept; }'

sudo nft add rule inet prabal_s01 input \
  ip saddr "$ATTACKER_IP" \
  tcp dport 4840 \
  counter drop \
  comment 'Prabal S01 temporary containment'
```

Review the rule:

```bash
sudo nft -a list chain inet prabal_s01 input
```

This preserves the local HMI connection and avoids a blanket OPC UA outage.

### 8.2 Confirm that services remain up

```bash
sudo systemctl is-active prabal-opcua.service prabal-hmi.service
curl -fsS http://127.0.0.1:8088/api/health | jq .
```

## 9. Eradicate the unsafe write configuration

The exercise server reads its write policy from:

```text
/etc/prabal-urja/scenario1.env
```

Record the current value:

```bash
sudo grep '^OPCUA_ALLOW_REMOTE_WRITE=' /etc/prabal-urja/scenario1.env
```

Change it to read-only:

```bash
sudo sed -i \
  's/^OPCUA_ALLOW_REMOTE_WRITE=.*/OPCUA_ALLOW_REMOTE_WRITE=0/' \
  /etc/prabal-urja/scenario1.env
```

Restarting the OPC UA service resets the volatile maintenance variables to safe defaults and recreates them without remote write permission:

```bash
sudo systemctl restart prabal-opcua.service
sleep 2
sudo systemctl restart prabal-hmi.service
```

Alternatively, after evidence preservation and attacker attribution, the packaged response helper performs the same controlled action:

```bash
sudo /opt/prabal-urja/scenario1/tools/apply_hardening.sh \
  --attacker-ip "$ATTACKER_IP"
```

Do not use both methods blindly; confirm the resulting rules and configuration.

## 10. Validate recovery

### 10.1 Service status

```bash
sudo systemctl --no-pager --full status prabal-opcua.service prabal-hmi.service
sudo ss -ltnp | grep -E ':4840|:8088'
```

### 10.2 Protocol-aware health

```bash
sudo /opt/prabal-urja/scenario1/venv/bin/python \
  /opt/prabal-urja/scenario1/tools/opcua_probe.py \
  --endpoint opc.tcp://127.0.0.1:4840
```

### 10.3 Operator state

```bash
curl -sS http://127.0.0.1:8088/api/state \
  | jq '{channel_state,telemetry_quality,maintenance_mode,freeze_telemetry,alarm_suppression,override_accepted,scenario_state}'
```

Expected safe state:

```json
{
  "channel_state": "ONLINE",
  "telemetry_quality": "GOOD",
  "maintenance_mode": false,
  "freeze_telemetry": false,
  "alarm_suppression": false,
  "override_accepted": false,
  "scenario_state": "NORMAL_OPERATION"
}
```

### 10.4 Confirm telemetry movement

```bash
curl -sS http://127.0.0.1:8088/api/state | jq '.active_power_mw,.frequency_hz'
sleep 8
curl -sS http://127.0.0.1:8088/api/state | jq '.active_power_mw,.frequency_hz'
```

The values should change.

### 10.5 Confirm remote write is denied

From an authorised Blue test workstation, create `verify_read_only.py`:

```python
import asyncio
import os
from asyncua import Client, ua

NS_URI = "urn:prabal-urja:hydro:unit2"
NODE = "PrabalUrja/HydroPlant/Unit2/TelemetryGateway/MaintenanceMode"

async def main():
    endpoint = f"opc.tcp://{os.environ['TARGET_IP']}:4840"
    async with Client(url=endpoint, timeout=5) as client:
        idx = await client.get_namespace_index(NS_URI)
        node = client.get_node(f"ns={idx};s={NODE}")
        try:
            await node.write_value(ua.Variant(True, ua.VariantType.Boolean))
        except Exception as exc:
            print(f"EXPECTED_DENIAL: {exc}")
            return
        raise SystemExit("FAIL: write unexpectedly succeeded")

asyncio.run(main())
```

Run it only after setting the target:

```bash
export TARGET_IP='<TARGET_IP>'
python verify_read_only.py
```

Expected result is an OPC UA write denial such as `BadNotWritable` or `BadUserAccessDenied`.

## 11. Longer-term hardening recommendations

The exercise remediation disables remote writes, but a production design should also include:

- remove SecurityPolicy `None` from operational endpoints;
- use signed and encrypted OPC UA sessions, preferably Basic256Sha256 or an organisation-approved policy;
- require certificate-based application trust and individual user authentication;
- restrict maintenance writes by role and node;
- enforce an approved engineering-workstation allowlist;
- expire work orders and validate them through an independent authorisation service;
- alert on namespace-wide browsing and new OPC UA clients;
- retain protocol-aware network telemetry;
- compare operator telemetry with independent field or historian sources;
- review all southbound controller relationships exposed by the gateway.

## 12. Scenario 2 risk assessment

The namespace identifies:

```text
PU-GOV-PLC-02
Modbus/TCP
```

This does not prove that Scenario 2 is compromised. It does show that an attacker who browsed the gateway learned the downstream controller relationship. Blue should therefore notify the Hydro Plant Control Zone owner and review any permitted flows from the vendor-access zone to the `195.40.10.0/24` exercise segment.

Do not scan or alter Scenario 2 until it is deployed and the exercise controller authorises that stage.

## 13. ATT&CK for ICS mapping

| Observation | Technique |
|---|---|
| New remote client and broad OPC UA browsing | T0846 — Remote System Discovery |
| OPC UA maintenance writes from an unapproved source | T1692.001 — Unauthorized Message: Command Message |
| Altered maintenance, freeze and alarm parameters | T0836 — Modify Parameter |
| Use of normal OPC UA communication rather than malware | T0869 — Standard Application Layer Protocol |

## 14. Reporting requirements

Complete:

- `Reports/INREP.md` when the incident is initially confirmed;
- `Reports/SITREP.md` after technical investigation and containment;
- evidence hashes and screenshots;
- exact source IP, first-seen time, affected nodes, containment rule and restoration time.

## 15. Common response errors

- Restarting the host before preserving the packet capture
- Blocking TCP 4840 for every source and breaking the local operator console
- Treating stable HMI values as proof that the process is stable
- Failing to compare actual-process logs with displayed telemetry
- Removing the attacker rule without first disabling unsafe writes
- Declaring recovery before testing that remote writes are denied
