# Scenario 1: directly patched source package

- Original source is included.
- Added independent PCAP-based protocol evidence script.
- Native protocol exchange and cross-scenario reachability **have not been verified on a running Ubuntu VM**.
