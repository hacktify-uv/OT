# Build and Validation Checklist

## Static checks performed on the package

- Bash syntax validation for `setup.sh`, `reset.sh`, `validate.sh` and helper scripts
- Python byte-code compilation for HMI and tools
- YAML parse validation for both TTP files
- Relative-path and executable-bit verification
- Package checksum generation

## Runtime checks performed by `validate.sh`

- `prabal-opcua.service` is active
- `prabal-hmi.service` is active
- `prabal-opcua-capture.service` is active
- OPC UA port is listening
- HMI port is listening
- real OPC UA session can read `ServerReady`
- HMI health endpoint reports an active OPC UA connection
- HMI webroot contains the expected Prabal Urja presentation

## Clean-server acceptance test

Run on both Ubuntu 22.04 and Ubuntu 24.04:

```bash
sudo bash setup.sh
sudo ./validate.sh
sudo ./reset.sh --preserve-evidence
```

Then validate Red and Blue procedures against the deployed target. This package has been statically validated in the artifact environment; final native runtime acceptance requires an Ubuntu VM because the artifact environment is not Ubuntu 22.04/24.04 and cannot start systemd services.
