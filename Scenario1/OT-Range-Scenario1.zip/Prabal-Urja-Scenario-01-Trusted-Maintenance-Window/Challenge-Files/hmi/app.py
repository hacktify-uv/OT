import asyncio
import logging
import os
import time
from pathlib import Path
from typing import Any

from asyncua import Client
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
OPCUA_ENDPOINT = os.getenv("OPCUA_ENDPOINT", "opc.tcp://127.0.0.1:4840")
NAMESPACE_URI = "urn:prabal-urja:hydro:unit2"
POLL_SECONDS = float(os.getenv("HMI_POLL_SECONDS", "1.0"))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s level=%(levelname)s component=prabal-hmi message=%(message)s",
)
logger = logging.getLogger("prabal-hmi")

app = FastAPI(title="Prabal Urja Unit-2 Operations Console", docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

STATE: dict[str, Any] = {
    "connected": False,
    "last_update_epoch": 0.0,
    "last_error": "initialising",
    "asset_id": "PU-OPCUA-GW-01",
    "active_power_mw": None,
    "reactive_power_mvar": None,
    "terminal_voltage_kv": None,
    "frequency_hz": None,
    "speed_rpm": None,
    "guide_vane_percent": None,
    "channel_state": "UNKNOWN",
    "telemetry_quality": "UNKNOWN",
    "maintenance_mode": False,
    "freeze_telemetry": False,
    "alarm_suppression": False,
    "maintenance_ticket": "",
    "override_accepted": False,
    "alarm_banner": "Telemetry unavailable",
    "scenario_state": "INITIALISING",
    "downstream_controller": "",
    "southbound_protocol": "",
    "operations_owner": "",
}

NODE_MAP = {
    "active_power_mw": "PrabalUrja/HydroPlant/Unit2/Generator/ActivePowerMW",
    "reactive_power_mvar": "PrabalUrja/HydroPlant/Unit2/Generator/ReactivePowerMVAR",
    "terminal_voltage_kv": "PrabalUrja/HydroPlant/Unit2/Generator/TerminalVoltageKV",
    "frequency_hz": "PrabalUrja/HydroPlant/Unit2/Generator/FrequencyHz",
    "speed_rpm": "PrabalUrja/HydroPlant/Unit2/Turbine/SpeedRPM",
    "guide_vane_percent": "PrabalUrja/HydroPlant/Unit2/Turbine/GuideVanePercent",
    "channel_state": "PrabalUrja/HydroPlant/Unit2/TelemetryGateway/ChannelState",
    "telemetry_quality": "PrabalUrja/HydroPlant/Unit2/TelemetryGateway/TelemetryQuality",
    "maintenance_mode": "PrabalUrja/HydroPlant/Unit2/TelemetryGateway/MaintenanceMode",
    "freeze_telemetry": "PrabalUrja/HydroPlant/Unit2/TelemetryGateway/FreezeTelemetry",
    "alarm_suppression": "PrabalUrja/HydroPlant/Unit2/TelemetryGateway/AlarmSuppression",
    "maintenance_ticket": "PrabalUrja/HydroPlant/Unit2/TelemetryGateway/MaintenanceTicket",
    "override_accepted": "PrabalUrja/HydroPlant/Unit2/TelemetryGateway/OverrideAccepted",
    "alarm_banner": "PrabalUrja/HydroPlant/Unit2/TelemetryGateway/AlarmBanner",
    "scenario_state": "PrabalUrja/HydroPlant/Unit2/Health/ScenarioState",
    "downstream_controller": "PrabalUrja/HydroPlant/Unit2/EngineeringMetadata/DownstreamController",
    "southbound_protocol": "PrabalUrja/HydroPlant/Unit2/EngineeringMetadata/SouthboundProtocol",
    "operations_owner": "PrabalUrja/HydroPlant/Unit2/EngineeringMetadata/OperationsOwner",
}


def json_safe(value: Any) -> Any:
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


async def opcua_poll_loop() -> None:
    while True:
        try:
            async with Client(url=OPCUA_ENDPOINT, timeout=4) as client:
                namespace_index = await client.get_namespace_index(NAMESPACE_URI)
                nodes = {
                    key: client.get_node(f"ns={namespace_index};s={node_id}")
                    for key, node_id in NODE_MAP.items()
                }
                logger.info("OPC UA session established endpoint=%s namespace=%s", OPCUA_ENDPOINT, namespace_index)
                while True:
                    values = await asyncio.gather(
                        *(node.read_value() for node in nodes.values()),
                        return_exceptions=True,
                    )
                    failed = [value for value in values if isinstance(value, Exception)]
                    if failed:
                        raise RuntimeError(f"OPC UA read failed: {failed[0]}")
                    for key, value in zip(nodes.keys(), values):
                        STATE[key] = json_safe(value)
                    STATE["connected"] = True
                    STATE["last_update_epoch"] = time.time()
                    STATE["last_error"] = ""
                    await asyncio.sleep(POLL_SECONDS)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001 - service loop must recover
            STATE["connected"] = False
            STATE["last_error"] = str(exc)
            logger.warning("OPC UA polling interrupted: %s", exc)
            await asyncio.sleep(2.0)


@app.on_event("startup")
async def startup_event() -> None:
    app.state.poll_task = asyncio.create_task(opcua_poll_loop())


@app.on_event("shutdown")
async def shutdown_event() -> None:
    task = getattr(app.state, "poll_task", None)
    if task:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass


@app.get("/")
async def index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/api/state")
async def state() -> dict[str, Any]:
    return dict(STATE)


@app.get("/api/health")
async def health() -> dict[str, Any]:
    age = time.time() - float(STATE["last_update_epoch"] or 0.0)
    if not STATE["connected"] or age > max(5.0, POLL_SECONDS * 4):
        raise HTTPException(
            status_code=503,
            detail={
                "status": "degraded",
                "opcua_connected": STATE["connected"],
                "last_update_age_seconds": round(age, 2),
                "error": STATE["last_error"],
            },
        )
    return {
        "status": "up",
        "opcua_connected": True,
        "last_update_age_seconds": round(age, 2),
        "asset_id": STATE["asset_id"],
        "scenario_state": STATE["scenario_state"],
    }
