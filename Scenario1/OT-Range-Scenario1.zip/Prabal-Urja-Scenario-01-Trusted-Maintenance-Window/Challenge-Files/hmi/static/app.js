const $ = (id) => document.getElementById(id);
const numeric = (value, digits = 2) => value === null || value === undefined ? "---" : Number(value).toFixed(digits);
const yesNo = (value) => value ? "YES" : "NO";

function setText(id, value) { $(id).textContent = value; }
function updateClock() {
  const now = new Date();
  setText("clock", now.toLocaleTimeString("en-IN", { timeZone: "Asia/Kolkata", hour12: false }) + " IST");
}

function render(data) {
  const badge = $("connectionBadge");
  badge.textContent = data.connected ? "DATA LINK ONLINE" : "DATA LINK OFFLINE";
  badge.className = `badge ${data.connected ? "badge-online" : "badge-offline"}`;

  setText("activePower", numeric(data.active_power_mw, 2));
  setText("reactivePower", numeric(data.reactive_power_mvar, 2));
  setText("terminalVoltage", numeric(data.terminal_voltage_kv, 3));
  setText("frequency", numeric(data.frequency_hz, 3));
  setText("speed", numeric(data.speed_rpm, 2));
  setText("guideVane", numeric(data.guide_vane_percent, 2));
  setText("powerInline", `${numeric(data.active_power_mw, 1)} MW`);
  setText("speedInline", `${numeric(data.speed_rpm, 1)} rpm`);

  setText("channelState", data.channel_state || "UNKNOWN");
  setText("qualityState", data.telemetry_quality || "UNKNOWN");
  setText("maintenanceState", data.maintenance_mode ? "ACTIVE" : "INACTIVE");
  setText("overrideState", data.override_accepted ? "ACCEPTED" : "NOT ACCEPTED");
  setText("ticketState", data.maintenance_ticket || "—");
  setText("alarmBanner", data.alarm_banner || "No information");
  setText("scenarioState", data.scenario_state || "UNKNOWN");
  setText("alarmSuppression", yesNo(data.alarm_suppression));
  setText("freezeTelemetry", yesNo(data.freeze_telemetry));
  setText("lastUpdate", data.last_update_epoch ? new Date(data.last_update_epoch * 1000).toLocaleString("en-IN") : "—");
  setText("operationsOwner", data.operations_owner || "—");
  setText("downstreamController", data.downstream_controller || "—");
  setText("southboundProtocol", data.southbound_protocol || "—");

  const alarm = $("alarmBanner");
  alarm.className = "alarm-message";
  if (data.override_accepted) alarm.classList.add("critical");
  else if (data.maintenance_mode || data.alarm_suppression) alarm.classList.add("warning");
}

async function poll() {
  try {
    const response = await fetch("/api/state", { cache: "no-store" });
    render(await response.json());
  } catch (error) {
    render({ connected: false });
  }
}

updateClock();
setInterval(updateClock, 1000);
poll();
setInterval(poll, 1000);
