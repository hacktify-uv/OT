#include <open62541/server.h>
#include <open62541/server_config_default.h>
#include <open62541/plugin/log_stdout.h>

#ifndef UA_NS0ID
#define UA_NS0ID(id) UA_NODEID_NUMERIC(0, UA_NS0ID_##id)
#endif

#include <errno.h>
#include <math.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <time.h>
#include <unistd.h>

#define NS_URI "urn:prabal-urja:hydro:unit2"
#define APPROVED_TICKET "PU-MW-0427"

static volatile UA_Boolean running = true;
static FILE *audit_fp = NULL;
static FILE *process_fp = NULL;
static UA_UInt16 ns_idx = 2;

static const char *NODE_ACTIVE_POWER = "PrabalUrja/HydroPlant/Unit2/Generator/ActivePowerMW";
static const char *NODE_REACTIVE_POWER = "PrabalUrja/HydroPlant/Unit2/Generator/ReactivePowerMVAR";
static const char *NODE_TERMINAL_VOLTAGE = "PrabalUrja/HydroPlant/Unit2/Generator/TerminalVoltageKV";
static const char *NODE_FREQUENCY = "PrabalUrja/HydroPlant/Unit2/Generator/FrequencyHz";
static const char *NODE_SPEED = "PrabalUrja/HydroPlant/Unit2/Turbine/SpeedRPM";
static const char *NODE_GUIDE_VANE = "PrabalUrja/HydroPlant/Unit2/Turbine/GuideVanePercent";
static const char *NODE_CHANNEL_STATE = "PrabalUrja/HydroPlant/Unit2/TelemetryGateway/ChannelState";
static const char *NODE_QUALITY = "PrabalUrja/HydroPlant/Unit2/TelemetryGateway/TelemetryQuality";
static const char *NODE_MAINT_MODE = "PrabalUrja/HydroPlant/Unit2/TelemetryGateway/MaintenanceMode";
static const char *NODE_FREEZE = "PrabalUrja/HydroPlant/Unit2/TelemetryGateway/FreezeTelemetry";
static const char *NODE_ALARM_SUPPRESS = "PrabalUrja/HydroPlant/Unit2/TelemetryGateway/AlarmSuppression";
static const char *NODE_TICKET = "PrabalUrja/HydroPlant/Unit2/TelemetryGateway/MaintenanceTicket";
static const char *NODE_OVERRIDE_ACCEPTED = "PrabalUrja/HydroPlant/Unit2/TelemetryGateway/OverrideAccepted";
static const char *NODE_ALARM_BANNER = "PrabalUrja/HydroPlant/Unit2/TelemetryGateway/AlarmBanner";
static const char *NODE_SERVER_READY = "PrabalUrja/HydroPlant/Unit2/Health/ServerReady";
static const char *NODE_SCENARIO_STATE = "PrabalUrja/HydroPlant/Unit2/Health/ScenarioState";

static void stop_handler(int sig) {
    (void)sig;
    running = false;
}

static void iso_time(char *buf, size_t len) {
    time_t now = time(NULL);
    struct tm tm_now;
    gmtime_r(&now, &tm_now);
    strftime(buf, len, "%Y-%m-%dT%H:%M:%SZ", &tm_now);
}

static void log_line(FILE *fp, const char *level, const char *event, const char *details) {
    if(!fp)
        return;
    char ts[32];
    iso_time(ts, sizeof(ts));
    fprintf(fp, "%s level=%s event=%s %s\n", ts, level, event, details ? details : "");
    fflush(fp);
}

static UA_NodeId nid(const char *id) {
    return UA_NODEID_STRING(ns_idx, (char *)id);
}

static UA_StatusCode add_object(UA_Server *server, const char *id, const char *display,
                                UA_NodeId parent, UA_NodeId reference) {
    UA_ObjectAttributes attr = UA_ObjectAttributes_default;
    attr.displayName = UA_LOCALIZEDTEXT((char *)"en-US", (char *)display);
    return UA_Server_addObjectNode(server, nid(id), parent, reference,
                                   UA_QUALIFIEDNAME(ns_idx, (char *)display),
                                   UA_NS0ID(BASEOBJECTTYPE), attr, NULL, NULL);
}

static UA_StatusCode add_double(UA_Server *server, const char *id, const char *display,
                                const char *parent_id, double value, UA_Boolean writable) {
    UA_VariableAttributes attr = UA_VariableAttributes_default;
    UA_Variant_setScalar(&attr.value, &value, &UA_TYPES[UA_TYPES_DOUBLE]);
    attr.dataType = UA_TYPES[UA_TYPES_DOUBLE].typeId;
    attr.displayName = UA_LOCALIZEDTEXT((char *)"en-US", (char *)display);
    attr.accessLevel = UA_ACCESSLEVELMASK_READ | (writable ? UA_ACCESSLEVELMASK_WRITE : 0);
    attr.userAccessLevel = attr.accessLevel;
    return UA_Server_addVariableNode(server, nid(id), nid(parent_id), UA_NS0ID(HASCOMPONENT),
                                     UA_QUALIFIEDNAME(ns_idx, (char *)display),
                                     UA_NS0ID(BASEDATAVARIABLETYPE), attr, NULL, NULL);
}

static UA_StatusCode add_bool(UA_Server *server, const char *id, const char *display,
                              const char *parent_id, UA_Boolean value, UA_Boolean writable) {
    UA_VariableAttributes attr = UA_VariableAttributes_default;
    UA_Variant_setScalar(&attr.value, &value, &UA_TYPES[UA_TYPES_BOOLEAN]);
    attr.dataType = UA_TYPES[UA_TYPES_BOOLEAN].typeId;
    attr.displayName = UA_LOCALIZEDTEXT((char *)"en-US", (char *)display);
    attr.accessLevel = UA_ACCESSLEVELMASK_READ | (writable ? UA_ACCESSLEVELMASK_WRITE : 0);
    attr.userAccessLevel = attr.accessLevel;
    return UA_Server_addVariableNode(server, nid(id), nid(parent_id), UA_NS0ID(HASCOMPONENT),
                                     UA_QUALIFIEDNAME(ns_idx, (char *)display),
                                     UA_NS0ID(BASEDATAVARIABLETYPE), attr, NULL, NULL);
}

static UA_StatusCode add_string(UA_Server *server, const char *id, const char *display,
                                const char *parent_id, const char *value, UA_Boolean writable) {
    UA_VariableAttributes attr = UA_VariableAttributes_default;
    UA_String text = UA_STRING((char *)value);
    UA_Variant_setScalar(&attr.value, &text, &UA_TYPES[UA_TYPES_STRING]);
    attr.dataType = UA_TYPES[UA_TYPES_STRING].typeId;
    attr.displayName = UA_LOCALIZEDTEXT((char *)"en-US", (char *)display);
    attr.accessLevel = UA_ACCESSLEVELMASK_READ | (writable ? UA_ACCESSLEVELMASK_WRITE : 0);
    attr.userAccessLevel = attr.accessLevel;
    return UA_Server_addVariableNode(server, nid(id), nid(parent_id), UA_NS0ID(HASCOMPONENT),
                                     UA_QUALIFIEDNAME(ns_idx, (char *)display),
                                     UA_NS0ID(BASEDATAVARIABLETYPE), attr, NULL, NULL);
}

static void write_double(UA_Server *server, const char *id, double value) {
    UA_Variant v;
    UA_Variant_init(&v);
    UA_Variant_setScalar(&v, &value, &UA_TYPES[UA_TYPES_DOUBLE]);
    (void)UA_Server_writeValue(server, nid(id), v);
}

static void write_bool(UA_Server *server, const char *id, UA_Boolean value) {
    UA_Variant v;
    UA_Variant_init(&v);
    UA_Variant_setScalar(&v, &value, &UA_TYPES[UA_TYPES_BOOLEAN]);
    (void)UA_Server_writeValue(server, nid(id), v);
}

static void write_string(UA_Server *server, const char *id, const char *value) {
    UA_String text = UA_STRING((char *)value);
    UA_Variant v;
    UA_Variant_init(&v);
    UA_Variant_setScalar(&v, &text, &UA_TYPES[UA_TYPES_STRING]);
    (void)UA_Server_writeValue(server, nid(id), v);
}

static UA_Boolean read_bool(UA_Server *server, const char *id) {
    UA_Variant v;
    UA_Variant_init(&v);
    UA_Boolean result = false;
    if(UA_Server_readValue(server, nid(id), &v) == UA_STATUSCODE_GOOD &&
       UA_Variant_hasScalarType(&v, &UA_TYPES[UA_TYPES_BOOLEAN])) {
        result = *(UA_Boolean *)v.data;
    }
    UA_Variant_clear(&v);
    return result;
}

static void read_string(UA_Server *server, const char *id, char *buf, size_t len) {
    if(len == 0)
        return;
    buf[0] = '\0';
    UA_Variant v;
    UA_Variant_init(&v);
    if(UA_Server_readValue(server, nid(id), &v) == UA_STATUSCODE_GOOD &&
       UA_Variant_hasScalarType(&v, &UA_TYPES[UA_TYPES_STRING])) {
        UA_String *s = (UA_String *)v.data;
        size_t n = s->length < (len - 1) ? s->length : (len - 1);
        memcpy(buf, s->data, n);
        buf[n] = '\0';
    }
    UA_Variant_clear(&v);
}

static int env_bool(const char *name, int fallback) {
    const char *v = getenv(name);
    if(!v || !*v)
        return fallback;
    return (!strcasecmp(v, "1") || !strcasecmp(v, "true") || !strcasecmp(v, "yes"));
}

static unsigned long monotonic_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (unsigned long)ts.tv_sec * 1000UL + (unsigned long)ts.tv_nsec / 1000000UL;
}

int main(void) {
    signal(SIGINT, stop_handler);
    signal(SIGTERM, stop_handler);

    const char *audit_path = getenv("PRABAL_AUDIT_LOG");
    const char *process_path = getenv("PRABAL_PROCESS_LOG");
    if(!audit_path) audit_path = "/var/log/prabal-urja/opcua-audit.log";
    if(!process_path) process_path = "/var/log/prabal-urja/process-actual.log";

    audit_fp = fopen(audit_path, "a");
    process_fp = fopen(process_path, "a");
    if(!audit_fp || !process_fp) {
        fprintf(stderr, "Unable to open log files: %s\n", strerror(errno));
        return EXIT_FAILURE;
    }

    unsigned long port_raw = 4840;
    const char *port_env = getenv("OPCUA_PORT");
    if(port_env && *port_env)
        port_raw = strtoul(port_env, NULL, 10);
    if(port_raw < 1024 || port_raw > 65535) {
        fprintf(stderr, "Invalid OPCUA_PORT\n");
        return EXIT_FAILURE;
    }
    UA_UInt16 port = (UA_UInt16)port_raw;
    UA_Boolean allow_write = env_bool("OPCUA_ALLOW_REMOTE_WRITE", 1) ? true : false;

    UA_ServerConfig config;
    memset(&config, 0, sizeof(config));

    UA_StatusCode rc = UA_ServerConfig_setMinimal(&config, port, NULL);
    if(rc != UA_STATUSCODE_GOOD) {
        fprintf(stderr, "UA_ServerConfig_setMinimal failed: 0x%08x\n", rc);
        UA_ServerConfig_clean(&config);
        return EXIT_FAILURE;
    }

    UA_Server *server = UA_Server_newWithConfig(&config);
    if(!server) {
        fprintf(stderr, "Unable to create OPC UA server\n");
        UA_ServerConfig_clean(&config);
        return EXIT_FAILURE;
    }

    ns_idx = UA_Server_addNamespace(server, NS_URI);

    const char *ROOT = "PrabalUrja";
    const char *PLANT = "PrabalUrja/HydroPlant";
    const char *UNIT = "PrabalUrja/HydroPlant/Unit2";
    const char *GEN = "PrabalUrja/HydroPlant/Unit2/Generator";
    const char *TURB = "PrabalUrja/HydroPlant/Unit2/Turbine";
    const char *TGW = "PrabalUrja/HydroPlant/Unit2/TelemetryGateway";
    const char *HEALTH = "PrabalUrja/HydroPlant/Unit2/Health";
    const char *ENG = "PrabalUrja/HydroPlant/Unit2/EngineeringMetadata";

    rc |= add_object(server, ROOT, "Prabal Urja", UA_NS0ID(OBJECTSFOLDER), UA_NS0ID(ORGANIZES));
    rc |= add_object(server, PLANT, "HydroPlant", nid(ROOT), UA_NS0ID(HASCOMPONENT));
    rc |= add_object(server, UNIT, "Unit2", nid(PLANT), UA_NS0ID(HASCOMPONENT));
    rc |= add_object(server, GEN, "Generator", nid(UNIT), UA_NS0ID(HASCOMPONENT));
    rc |= add_object(server, TURB, "Turbine", nid(UNIT), UA_NS0ID(HASCOMPONENT));
    rc |= add_object(server, TGW, "TelemetryGateway", nid(UNIT), UA_NS0ID(HASCOMPONENT));
    rc |= add_object(server, HEALTH, "Health", nid(UNIT), UA_NS0ID(HASCOMPONENT));
    rc |= add_object(server, ENG, "EngineeringMetadata", nid(UNIT), UA_NS0ID(HASCOMPONENT));

    rc |= add_double(server, NODE_ACTIVE_POWER, "ActivePowerMW", GEN, 118.4, false);
    rc |= add_double(server, NODE_REACTIVE_POWER, "ReactivePowerMVAR", GEN, 31.2, false);
    rc |= add_double(server, NODE_TERMINAL_VOLTAGE, "TerminalVoltageKV", GEN, 11.02, false);
    rc |= add_double(server, NODE_FREQUENCY, "FrequencyHz", GEN, 50.00, false);
    rc |= add_double(server, NODE_SPEED, "SpeedRPM", TURB, 300.0, false);
    rc |= add_double(server, NODE_GUIDE_VANE, "GuideVanePercent", TURB, 61.5, false);

    rc |= add_string(server, NODE_CHANNEL_STATE, "ChannelState", TGW, "ONLINE", false);
    rc |= add_string(server, NODE_QUALITY, "TelemetryQuality", TGW, "GOOD", false);
    rc |= add_bool(server, NODE_MAINT_MODE, "MaintenanceMode", TGW, false, allow_write);
    rc |= add_bool(server, NODE_FREEZE, "FreezeTelemetry", TGW, false, allow_write);
    rc |= add_bool(server, NODE_ALARM_SUPPRESS, "AlarmSuppression", TGW, false, allow_write);
    rc |= add_string(server, NODE_TICKET, "MaintenanceTicket", TGW, "", allow_write);
    rc |= add_bool(server, NODE_OVERRIDE_ACCEPTED, "OverrideAccepted", TGW, false, false);
    rc |= add_string(server, NODE_ALARM_BANNER, "AlarmBanner", TGW, "No Active Alarms", false);

    rc |= add_bool(server, NODE_SERVER_READY, "ServerReady", HEALTH, true, false);
    rc |= add_string(server, NODE_SCENARIO_STATE, "ScenarioState", HEALTH, "NORMAL_OPERATION", false);
    rc |= add_string(server, "PrabalUrja/HydroPlant/Unit2/Health/BuildId", "BuildId", HEALTH,
                     "PU-S01-OPEN62541-1.4.16", false);

    rc |= add_string(server, "PrabalUrja/HydroPlant/Unit2/EngineeringMetadata/AssetId", "AssetId", ENG,
                     "PU-OPCUA-GW-01", false);
    rc |= add_string(server, "PrabalUrja/HydroPlant/Unit2/EngineeringMetadata/LastApprovedWorkOrder",
                     "LastApprovedWorkOrder", ENG, APPROVED_TICKET, false);
    rc |= add_string(server, "PrabalUrja/HydroPlant/Unit2/EngineeringMetadata/DownstreamController",
                     "DownstreamController", ENG, "PU-GOV-PLC-02", false);
    rc |= add_string(server, "PrabalUrja/HydroPlant/Unit2/EngineeringMetadata/SouthboundProtocol",
                     "SouthboundProtocol", ENG, "Modbus/TCP", false);
    rc |= add_string(server, "PrabalUrja/HydroPlant/Unit2/EngineeringMetadata/OperationsOwner",
                     "OperationsOwner", ENG, "Ananya Rao - Shift Operations", false);
    rc |= add_string(server, "PrabalUrja/HydroPlant/Unit2/EngineeringMetadata/MaintenanceOwner",
                     "MaintenanceOwner", ENG, "Raghav Menon - Turbine Maintenance", false);

    if(rc != UA_STATUSCODE_GOOD) {
        fprintf(stderr, "Node model creation failed: 0x%08x\n", rc);
        UA_Server_delete(server);
        return EXIT_FAILURE;
    }

    char startup[256];
    snprintf(startup, sizeof(startup),
             "asset=PU-OPCUA-GW-01 port=%u namespace=%u security_policy=None anonymous_browse=true anonymous_write=%s",
             port, ns_idx, allow_write ? "true" : "false");
    log_line(audit_fp, "INFO", "SERVER_START", startup);

    rc = UA_Server_run_startup(server);
    if(rc != UA_STATUSCODE_GOOD) {
        fprintf(stderr, "UA_Server_run_startup failed: 0x%08x\n", rc);
        UA_Server_delete(server);
        return EXIT_FAILURE;
    }

    unsigned long start_ms = monotonic_ms();
    unsigned long last_update = 0;
    unsigned long last_process_log = 0;
    UA_Boolean old_maint = false, old_freeze = false, old_suppress = false, old_override = false;
    char old_ticket[128] = "";
    double frozen_power = 118.4, frozen_reactive = 31.2, frozen_voltage = 11.02;
    double frozen_frequency = 50.0, frozen_speed = 300.0, frozen_vane = 61.5;

    while(running) {
        UA_Server_run_iterate(server, false);
        unsigned long now = monotonic_ms();
        if(now - last_update < 200) {
            usleep(20000);
            continue;
        }
        last_update = now;

        UA_Boolean maint = read_bool(server, NODE_MAINT_MODE);
        UA_Boolean freeze = read_bool(server, NODE_FREEZE);
        UA_Boolean suppress = read_bool(server, NODE_ALARM_SUPPRESS);
        char ticket[128];
        read_string(server, NODE_TICKET, ticket, sizeof(ticket));

        if(maint != old_maint) {
            char d[128]; snprintf(d, sizeof(d), "node=MaintenanceMode old=%s new=%s",
                                  old_maint ? "true" : "false", maint ? "true" : "false");
            log_line(audit_fp, "WARN", "NODE_WRITE_DETECTED", d);
            old_maint = maint;
        }
        if(freeze != old_freeze) {
            char d[128]; snprintf(d, sizeof(d), "node=FreezeTelemetry old=%s new=%s",
                                  old_freeze ? "true" : "false", freeze ? "true" : "false");
            log_line(audit_fp, "WARN", "NODE_WRITE_DETECTED", d);
            old_freeze = freeze;
        }
        if(suppress != old_suppress) {
            char d[128]; snprintf(d, sizeof(d), "node=AlarmSuppression old=%s new=%s",
                                  old_suppress ? "true" : "false", suppress ? "true" : "false");
            log_line(audit_fp, "WARN", "NODE_WRITE_DETECTED", d);
            old_suppress = suppress;
        }
        if(strcmp(ticket, old_ticket) != 0) {
            char d[256]; snprintf(d, sizeof(d), "node=MaintenanceTicket old=\"%s\" new=\"%s\"",
                                  old_ticket, ticket);
            log_line(audit_fp, "WARN", "NODE_WRITE_DETECTED", d);
            strncpy(old_ticket, ticket, sizeof(old_ticket) - 1);
            old_ticket[sizeof(old_ticket) - 1] = '\0';
        }

        double t = (double)(now - start_ms) / 1000.0;
        double actual_power = 118.4 + 2.4 * sin(t / 12.0);
        double actual_reactive = 31.2 + 1.1 * sin(t / 17.0);
        double actual_voltage = 11.02 + 0.04 * sin(t / 14.0);
        double actual_frequency = 50.00 + 0.018 * sin(t / 9.0);
        double actual_speed = 300.0 + 0.08 * sin(t / 8.0);
        double actual_vane = 61.5 + 1.8 * sin(t / 13.0);

        UA_Boolean override_active = (maint && freeze && suppress && strcmp(ticket, APPROVED_TICKET) == 0);
        if(override_active && !old_override) {
            frozen_power = actual_power;
            frozen_reactive = actual_reactive;
            frozen_voltage = actual_voltage;
            frozen_frequency = actual_frequency;
            frozen_speed = actual_speed;
            frozen_vane = actual_vane;
            log_line(audit_fp, "CRITICAL", "OVERRIDE_ACTIVE",
                     "ticket=PU-MW-0427 channel=UNIT2_TELEMETRY effect=freeze_and_alarm_suppression");
        } else if(!override_active && old_override) {
            log_line(audit_fp, "INFO", "OVERRIDE_CLEARED", "channel=UNIT2_TELEMETRY");
        }
        old_override = override_active;

        write_bool(server, NODE_OVERRIDE_ACCEPTED, override_active);
        if(override_active) {
            write_double(server, NODE_ACTIVE_POWER, frozen_power);
            write_double(server, NODE_REACTIVE_POWER, frozen_reactive);
            write_double(server, NODE_TERMINAL_VOLTAGE, frozen_voltage);
            write_double(server, NODE_FREQUENCY, frozen_frequency);
            write_double(server, NODE_SPEED, frozen_speed);
            write_double(server, NODE_GUIDE_VANE, frozen_vane);
            write_string(server, NODE_CHANNEL_STATE, "MAINTENANCE_HOLD");
            write_string(server, NODE_QUALITY, "UNCERTAIN_LAST_USABLE_VALUE");
            write_string(server, NODE_ALARM_BANNER, "Alarms inhibited by approved maintenance override");
            write_string(server, NODE_SCENARIO_STATE, "UNAUTHORISED_MAINTENANCE_OVERRIDE");
        } else {
            write_double(server, NODE_ACTIVE_POWER, actual_power);
            write_double(server, NODE_REACTIVE_POWER, actual_reactive);
            write_double(server, NODE_TERMINAL_VOLTAGE, actual_voltage);
            write_double(server, NODE_FREQUENCY, actual_frequency);
            write_double(server, NODE_SPEED, actual_speed);
            write_double(server, NODE_GUIDE_VANE, actual_vane);
            write_string(server, NODE_CHANNEL_STATE, maint ? "MAINTENANCE_PENDING" : "ONLINE");
            write_string(server, NODE_QUALITY, "GOOD");
            write_string(server, NODE_ALARM_BANNER, suppress ? "Alarm suppression requested - not authorised" : "No Active Alarms");
            write_string(server, NODE_SCENARIO_STATE, "NORMAL_OPERATION");
        }

        if(now - last_process_log >= 5000) {
            char d[512];
            snprintf(d, sizeof(d),
                     "asset=PU-GEN-02 actual_power_mw=%.3f actual_reactive_mvar=%.3f actual_voltage_kv=%.3f actual_frequency_hz=%.4f displayed_power_mw=%.3f override=%s",
                     actual_power, actual_reactive, actual_voltage, actual_frequency,
                     override_active ? frozen_power : actual_power,
                     override_active ? "true" : "false");
            log_line(process_fp, "INFO", "PROCESS_SAMPLE", d);
            last_process_log = now;
        }
    }

    write_bool(server, NODE_SERVER_READY, false);
    log_line(audit_fp, "INFO", "SERVER_STOP", "asset=PU-OPCUA-GW-01");
    UA_Server_run_shutdown(server);
    UA_Server_delete(server);
    fclose(audit_fp);
    fclose(process_fp);
    return EXIT_SUCCESS;
}
