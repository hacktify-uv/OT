import sys
import types
import typing
import functools
import operator
from typing import get_origin, get_args

_orig_get_type_hints = typing.get_type_hints

def resolve_properties(v, module):
    if isinstance(v, property):
        class_name = v.fget.__name__
        real_type = getattr(module, class_name, None)
        return real_type if real_type is not None else v
    
    origin = get_origin(v)
    if origin is not None:
        args = get_args(v)
        if not args:
            return v
        resolved_args = tuple(resolve_properties(arg, module) for arg in args)
        if isinstance(v, types.UnionType):
            return functools.reduce(operator.or_, resolved_args)
        else:
            try:
                if len(resolved_args) == 1:
                    return origin[resolved_args[0]]
                return origin[resolved_args]
            except Exception:
                return v
    return v

def _patched_get_type_hints(obj, globalns=None, localns=None, include_extras=False):
    try:
        if sys.version_info >= (3, 9):
            hints = _orig_get_type_hints(obj, globalns=globalns, localns=localns, include_extras=include_extras)
        else:
            hints = _orig_get_type_hints(obj, globalns=globalns, localns=localns)
    except Exception:
        return {}

    res = {}
    module_name = getattr(obj, "__module__", None)
    module = sys.modules.get(module_name) if module_name else None
    
    for k, v in hints.items():
        if module:
            res[k] = resolve_properties(v, module)
        else:
            res[k] = v
    return res

typing.get_type_hints = _patched_get_type_hints
