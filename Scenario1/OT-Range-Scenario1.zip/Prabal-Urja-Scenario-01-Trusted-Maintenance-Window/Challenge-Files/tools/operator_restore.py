#!/usr/bin/env python3
import argparse
import asyncio
import sys

from asyncua import Client, ua

NS_URI = "urn:prabal-urja:hydro:unit2"
BASE = "PrabalUrja/HydroPlant/Unit2/TelemetryGateway"


async def restore(endpoint: str) -> None:
    async with Client(url=endpoint, timeout=5) as client:
        idx = await client.get_namespace_index(NS_URI)
        values = {
            "MaintenanceTicket": ua.Variant("", ua.VariantType.String),
            "AlarmSuppression": ua.Variant(False, ua.VariantType.Boolean),
            "FreezeTelemetry": ua.Variant(False, ua.VariantType.Boolean),
            "MaintenanceMode": ua.Variant(False, ua.VariantType.Boolean),
        }
        for name, value in values.items():
            await client.get_node(f"ns={idx};s={BASE}/{name}").write_value(value)
        accepted = await client.get_node(f"ns={idx};s={BASE}/OverrideAccepted").read_value()
        print(f"RESTORE_COMPLETE override_accepted={accepted}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Restore Unit-2 telemetry maintenance controls")
    parser.add_argument("--endpoint", default="opc.tcp://127.0.0.1:4840")
    args = parser.parse_args()
    try:
        asyncio.run(restore(args.endpoint))
        return 0
    except Exception as exc:  # noqa: BLE001
        print(f"RESTORE_FAILED: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
