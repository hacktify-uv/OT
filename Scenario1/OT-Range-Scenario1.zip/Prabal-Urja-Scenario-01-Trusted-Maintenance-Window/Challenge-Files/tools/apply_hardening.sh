#!/usr/bin/env bash
set -Eeuo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "Run as root." >&2
  exit 1
fi

ATTACKER_IP=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --attacker-ip)
      ATTACKER_IP="${2:-}"
      shift 2
      ;;
    *)
      echo "Unknown argument: $1" >&2
      exit 2
      ;;
  esac
done

ENV_FILE=/etc/prabal-urja/scenario1.env
[[ -f "$ENV_FILE" ]] || { echo "Missing $ENV_FILE" >&2; exit 1; }
# shellcheck disable=SC1091
source "$ENV_FILE"

# Restarting the server resets volatile maintenance values to their safe defaults.
sed -i 's/^OPCUA_ALLOW_REMOTE_WRITE=.*/OPCUA_ALLOW_REMOTE_WRITE=0/' "$ENV_FILE"

if [[ -n "$ATTACKER_IP" ]]; then
  if ! [[ "$ATTACKER_IP" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
    echo "Invalid IPv4 address: $ATTACKER_IP" >&2
    exit 2
  fi
  nft list table inet prabal_s01 >/dev/null 2>&1 || nft add table inet prabal_s01
  nft list chain inet prabal_s01 input >/dev/null 2>&1 || \
    nft 'add chain inet prabal_s01 input { type filter hook input priority -10; policy accept; }'
  if ! nft -a list chain inet prabal_s01 input | grep -Fq "ip saddr $ATTACKER_IP tcp dport"; then
    nft add rule inet prabal_s01 input ip saddr "$ATTACKER_IP" tcp dport "${OPCUA_PORT:-4840}" counter drop comment "Prabal S01 containment"
  fi
fi

systemctl restart prabal-opcua.service
systemctl restart prabal-hmi.service
sleep 3
/opt/prabal-urja/scenario1/venv/bin/python /opt/prabal-urja/scenario1/tools/opcua_probe.py --endpoint "opc.tcp://127.0.0.1:${OPCUA_PORT:-4840}"
echo "HARDENING_APPLIED remote_write=disabled attacker_ip=${ATTACKER_IP:-not-specified}"
