#!/usr/bin/env bash
set -Eeuo pipefail

OUT_BASE="${1:-/var/tmp/prabal-s01-evidence}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="${OUT_BASE}-${STAMP}"
mkdir -p "$OUT"
chmod 0700 "$OUT"

{
  echo "Collection UTC: $(date -u --iso-8601=seconds)"
  echo "Hostname: $(hostname -f 2>/dev/null || hostname)"
  echo "Kernel: $(uname -a)"
  echo "Primary IPv4: $(hostname -I 2>/dev/null | awk '{print $1}')"
} > "$OUT/collection-metadata.txt"

journalctl -u prabal-opcua.service --no-pager > "$OUT/prabal-opcua-journal.log" || true
journalctl -u prabal-hmi.service --no-pager > "$OUT/prabal-hmi-journal.log" || true
journalctl -u prabal-opcua-capture.service --no-pager > "$OUT/prabal-capture-journal.log" || true
cp -a /var/log/prabal-urja/opcua-audit.log "$OUT/" 2>/dev/null || true
cp -a /var/log/prabal-urja/process-actual.log "$OUT/" 2>/dev/null || true
cp -a /var/log/prabal-urja/pcap "$OUT/" 2>/dev/null || true
cp -a /etc/prabal-urja/scenario1.env "$OUT/" 2>/dev/null || true

ss -plantu > "$OUT/ss-plantu.txt" 2>&1 || true
ps auxww > "$OUT/process-list.txt" 2>&1 || true
nft list ruleset > "$OUT/nft-ruleset.txt" 2>&1 || true
ip address show > "$OUT/ip-address.txt" 2>&1 || true
ip route show table all > "$OUT/ip-routes.txt" 2>&1 || true

find "$OUT" -type f -print0 | sort -z | xargs -0 sha256sum > "$OUT/SHA256SUMS.txt"
tar -C "$(dirname "$OUT")" -czf "${OUT}.tar.gz" "$(basename "$OUT")"
sha256sum "${OUT}.tar.gz" > "${OUT}.tar.gz.sha256"

echo "EVIDENCE_DIR=$OUT"
echo "EVIDENCE_ARCHIVE=${OUT}.tar.gz"
