#!/usr/bin/env python3
import argparse
import asyncio
import json
import sys

from asyncua import Client

NS_URI = "urn:prabal-urja:hydro:unit2"
READY_NODE = "PrabalUrja/HydroPlant/Unit2/Health/ServerReady"
STATE_NODE = "PrabalUrja/HydroPlant/Unit2/Health/ScenarioState"
BUILD_NODE = "PrabalUrja/HydroPlant/Unit2/Health/BuildId"


async def run(endpoint: str, timeout: float) -> int:
    try:
        async with Client(url=endpoint, timeout=timeout) as client:
            idx = await client.get_namespace_index(NS_URI)
            ready = await client.get_node(f"ns={idx};s={READY_NODE}").read_value()
            state = await client.get_node(f"ns={idx};s={STATE_NODE}").read_value()
            build = await client.get_node(f"ns={idx};s={BUILD_NODE}").read_value()
            result = {
                "status": "up" if ready is True else "down",
                "endpoint": endpoint,
                "namespace_index": idx,
                "server_ready": bool(ready),
                "scenario_state": str(state),
                "build_id": str(build),
            }
            print(json.dumps(result, sort_keys=True))
            return 0 if ready is True else 1
    except Exception as exc:  # noqa: BLE001
        print(json.dumps({"status": "down", "endpoint": endpoint, "error": str(exc)}))
        return 1


def main() -> int:
    parser = argparse.ArgumentParser(description="Protocol-aware health probe for Prabal Urja OPC UA")
    parser.add_argument("--endpoint", default="opc.tcp://127.0.0.1:4840")
    parser.add_argument("--timeout", type=float, default=4.0)
    args = parser.parse_args()
    return asyncio.run(run(args.endpoint, args.timeout))


if __name__ == "__main__":
    sys.exit(main())
