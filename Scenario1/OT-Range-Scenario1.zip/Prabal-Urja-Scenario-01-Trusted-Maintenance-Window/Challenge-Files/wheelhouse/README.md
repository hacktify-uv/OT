# Optional Python Wheelhouse

The default setup downloads the pinned Python packages listed in
`../hmi/requirements.txt` from PyPI.

For an offline or controlled installation, populate this directory on an
internet-connected Ubuntu host before transferring the package:

```bash
python3 -m pip download \
  --dest Challenge-Files/wheelhouse \
  -r Challenge-Files/hmi/requirements.txt
```

When one or more wheel files are present, `setup.sh` automatically uses
`--no-index --find-links` and does not contact PyPI. Ensure the wheelhouse
contains all transitive dependencies for the target architecture and Python
version.
