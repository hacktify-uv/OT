import asyncio
import os
from asyncua import Client

NS_URI = "urn:prabal-urja:hydro:unit2"

async def walk(node, namespace_index, depth=0, max_depth=8):
    if depth > max_depth:
        return

    try:
        browse_name = await node.read_browse_name()
        display_name = await node.read_display_name()
        node_class = await node.read_node_class()
    except Exception as exc:
        print("  " * depth, node.nodeid, "<read error>", exc)
        return

    print(
        "  " * depth
        + f"{node.nodeid.to_string()} | {browse_name.Name} | {display_name.Text} | {node_class.name}"
    )

    for child in await node.get_children():
        if child.nodeid.NamespaceIndex == namespace_index:
            await walk(child, namespace_index, depth + 1, max_depth)

async def main():
    endpoint = f"opc.tcp://{os.environ['TARGET_IP']}:4840"
    async with Client(url=endpoint, timeout=5) as client:
        idx = await client.get_namespace_index(NS_URI)
        print(f"Namespace index: {idx}")
        await walk(client.nodes.objects, idx)

asyncio.run(main())
