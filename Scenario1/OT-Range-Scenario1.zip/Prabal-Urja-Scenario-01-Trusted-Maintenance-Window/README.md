# Prabal Urja Scenario 1 — The Trusted Maintenance Window

## Purpose

This package deploys the first stage of the Prabal Urja interconnected Red-vs-Blue power-sector campaign. It uses a real OPC UA server built with `open62541` and a native Linux operator console that reads the server through an OPC UA client session. The console is a scenario-specific operator display; it does not imitate or claim to be a commercial SCADA product. All industrial communication used by the exercise is real OPC UA rather than a cosmetic HTTP simulation.

The scenario intentionally exposes an unsafe maintenance configuration:

- OPC UA SecurityPolicy `None`
- anonymous namespace access
- anonymous write access to a limited maintenance control group
- operational acceptance based on a discoverable work-order reference instead of authenticated authorisation

The unsafe controls can freeze displayed Unit-2 telemetry and suppress the operator alarm banner. The underlying simulated process continues to change and is written to a separate local process log, creating evidence for Blue Team correlation.

## Supported systems

- Ubuntu Server 22.04 LTS Jammy
- Ubuntu Server 24.04 LTS Noble
- x86_64 or ARM64
- systemd-based cloud image
- Internet access during installation, unless the official `open62541` source and Python wheelhouse are packaged under `Challenge-Files/vendor/` and `Challenge-Files/wheelhouse/`

Docker is not used.

## Recommended VM sizing

- 2 vCPU
- 4 GB RAM
- 20 GB disk
- one isolated exercise interface

## Installation

```bash
cd Prabal-Urja-Scenario-01-Trusted-Maintenance-Window
sudo bash setup.sh
```

`setup.sh` calls the packaged `deps.sh`, builds the native OPC UA server,
installs the operator console, creates systemd services, starts the scenario,
and runs protocol-aware validation.

Optional environment variables:

```bash
sudo PRABAL_OPCUA_PORT=4840 \
     PRABAL_HMI_PORT=8088 \
     PRABAL_CAPTURE_INTERFACE=any \
     bash setup.sh
```

The installer does not assign or hardcode an IP address. Addressing is controlled by the cloud or network layer. The documentation uses `195.0.0.0/8` as requested for the isolated exercise plan.

## Installed services

| Service | Function | Default port |
|---|---|---:|
| `prabal-opcua.service` | Real open62541 OPC UA server | TCP 4840 |
| `prabal-hmi.service` | Unit-2 operator console and OPC UA client | TCP 8088 |
| `prabal-opcua-capture.service` | Rolling packet capture for exercise evidence | N/A |

## Important installed paths

```text
/opt/prabal-urja/scenario1/             application and tools
/etc/prabal-urja/scenario1.env          runtime configuration
/var/log/prabal-urja/opcua-audit.log    maintenance-node change audit
/var/log/prabal-urja/process-actual.log actual simulated process samples
/var/log/prabal-urja/pcap/              OPC UA packet captures
```

## Validation

```bash
sudo ./validate.sh
```

Validation requires all of the following:

1. systemd services are active;
2. expected ports are listening;
3. a protocol-aware OPC UA client can read the health node;
4. the HMI health endpoint confirms that it is receiving OPC UA data.

## Reset

```bash
sudo ./reset.sh
```

To archive current evidence before resetting:

```bash
sudo ./reset.sh --preserve-evidence
```

## Blue Team evidence collection

```bash
sudo /opt/prabal-urja/scenario1/tools/collect_evidence.sh
```

## Package boundaries

Only Scenario 1 is deployed by this package. Scenario 2 is represented only through legitimate engineering metadata that identifies the next downstream controller. Its host and service are not created here.
