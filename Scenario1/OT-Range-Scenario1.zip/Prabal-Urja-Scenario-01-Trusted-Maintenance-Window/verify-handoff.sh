#!/usr/bin/env bash
set -Eeuo pipefail
# Independent check of real network, NOT a challenge-completion trigger.
if [[ $# -lt 2 ]]; then echo "Usage: bash verify-handoff.sh <hostname-or-ip> <port>" >&2; exit 2; fi
host="$1"; port="$2"
if ! [[ "$port" =~ ^[0-9]+$ ]] || ((port<1 || port>65535)); then echo "Invalid port" >&2; exit 2; fi
getent ahostsv4 "$host" >/dev/null || { echo "HANDOFF FAILED: no DNS/host resolution for $host" >&2; exit 1; }
if timeout 5 bash -c 'echo > /dev/tcp/"$1"/"$2"' _ "$host" "$port" 2>/dev/null; then
 echo "NETWORK REACHABLE: $host:$port (TCP only; protocol and authorisation NOT verified)"
else
 echo "HANDOFF FAILED: $host:$port not reachable" >&2; exit 1
fi
