import asyncio
import os
from asyncua import Client, ua

NS_URI = "urn:prabal-urja:hydro:unit2"
BASE = "PrabalUrja/HydroPlant/Unit2"

async def write(client, idx, relative, value, variant_type):
    node = client.get_node(f"ns={idx};s={BASE}/{relative}")
    await node.write_value(ua.Variant(value, variant_type))
    confirmed = await node.read_value()
    print(f"{relative} -> {confirmed!r}")

async def main():
    endpoint = f"opc.tcp://{os.environ['TARGET_IP']}:4840"

    async with Client(url=endpoint, timeout=5) as client:
        idx = await client.get_namespace_index(NS_URI)

        await write(
            client,
            idx,
            "TelemetryGateway/MaintenanceTicket",
            "PU-MW-0427",
            ua.VariantType.String,
        )

        await write(
            client,
            idx,
            "TelemetryGateway/MaintenanceMode",
            True,
            ua.VariantType.Boolean,
        )

        await write(
            client,
            idx,
            "TelemetryGateway/FreezeTelemetry",
            True,
            ua.VariantType.Boolean,
        )

        await write(
            client,
            idx,
            "TelemetryGateway/AlarmSuppression",
            True,
            ua.VariantType.Boolean,
        )

        await asyncio.sleep(1)

        accepted = await client.get_node(
            f"ns={idx};s={BASE}/TelemetryGateway/OverrideAccepted"
        ).read_value()

        state = await client.get_node(
            f"ns={idx};s={BASE}/Health/ScenarioState"
        ).read_value()

        quality = await client.get_node(
            f"ns={idx};s={BASE}/TelemetryGateway/TelemetryQuality"
        ).read_value()

        print(f"OverrideAccepted={accepted}")
        print(f"ScenarioState={state}")
        print(f"TelemetryQuality={quality}")

asyncio.run(main())
