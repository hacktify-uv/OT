# SITREP Report (SITREP)

**Cyber Exercise — Operation GRID SENTINEL: PRABAL URJA**  
**Scenario:** S01 — The Trusted Maintenance Window  
**Version 1.0**

---

**Date:** [YYYY-MM-DD]  
**Time:** [Time of Detection in IST and UTC]  
**Incident ID:** SITREP-OT-RB01-S01  
**Classification:** TRAINING / CONTROLLED

---

## 1. Incident Overview

**Description:**

- Unauthorised OPC UA maintenance-control writes were detected on `PU-OPCUA-GW-01`.
- The Unit-2 operator console displayed frozen last-usable values while the local process model continued to vary.
- The maintenance sequence used a valid work-order reference but did not originate from an approved authenticated engineering session.
- Evidence is present in the OPC UA audit log, process log, systemd journal and rolling packet capture.

**Severity Level:** High

**Impact:**

- Loss of confidence in Unit-2 operator telemetry
- Alarm presentation suppressed or made misleading
- Exposure of the downstream `PU-GOV-PLC-02` / Modbus-TCP relationship
- Increased risk of follow-on activity in the Hydro Plant Control Zone
- No host crash, process-service outage or physical equipment damage in the exercise

**Affected System:** `PU-OPCUA-GW-01` — Prabal Urja Unit-2 Engineering Telemetry Gateway

**Current Operational State:** [Contained / Eradication in Progress / Recovered]

---

## 2. Incident Details

**Detection Method:**

Investigation correlated the following:

- `NODE_WRITE_DETECTED` and `OVERRIDE_ACTIVE` events in `/var/log/prabal-urja/opcua-audit.log`
- `UNCERTAIN_LAST_USABLE_VALUE` reported by the HMI
- changing actual process values with fixed displayed values in `/var/log/prabal-urja/process-actual.log`
- a non-loopback OPC UA client in packet or socket evidence

**Detection Commands:**

```bash
sudo grep -E 'NODE_WRITE_DETECTED|OVERRIDE_ACTIVE' /var/log/prabal-urja/opcua-audit.log
curl -sS http://127.0.0.1:8088/api/state | jq .
sudo tail -30 /var/log/prabal-urja/process-actual.log
sudo ss -tnp state established '( sport = :4840 )'
```

**Initial Detection Time:** [Timestamp]

**Estimated First Malicious Activity:** [Timestamp derived from pcap/audit]

**Attack Vector:** Anonymous OPC UA session using SecurityPolicy `None`, namespace discovery and unauthorised write operations to maintenance-control nodes

**Suspected Source:** `[ATTACKER_IP]`

**Affected Nodes:**

```text
TelemetryGateway/MaintenanceTicket
TelemetryGateway/MaintenanceMode
TelemetryGateway/FreezeTelemetry
TelemetryGateway/AlarmSuppression
```

---

## 3. Response Actions Taken

### Containment

- Preserved logs, packet captures, process samples, configuration and system state.
- Applied a source-specific nftables block for the suspected remote client.
- Kept local HMI-to-OPC UA communication operational.
- Notified the Hydro Plant Control Zone owner of the disclosed downstream asset relationship.

**Containment Time:** [Timestamp]

**Containment Evidence:**

```bash
sudo nft -a list chain inet prabal_s01 input
```

### Eradication

- Set `OPCUA_ALLOW_REMOTE_WRITE=0`.
- Restarted only the OPC UA and HMI services.
- Cleared volatile maintenance values through controlled service reinitialisation.
- Confirmed that a remote anonymous write receives `BadNotWritable` or `BadUserAccessDenied`.

**Eradication Time:** [Timestamp]

### Recovery

- Confirmed OPC UA health through a real health-node read.
- Confirmed HMI health and active OPC UA polling.
- Confirmed `TelemetryQuality=GOOD`.
- Confirmed telemetry values change over time.
- Confirmed no active unauthorised maintenance state.

**Recovery Time:** [Timestamp]

### Lessons Learned

- A valid maintenance ticket is not an authentication or authorisation mechanism.
- OPC UA endpoints require application trust, user identity, role-based node permissions and network allowlisting.
- Stable HMI values can represent frozen or replayed telemetry rather than a stable process.
- Independent process evidence is necessary for incident confirmation.
- IP- and port-only monitoring is insufficient; defenders need OPC UA session and write-operation visibility.

---

## 4. Technical Analysis

### Evidence

- `/var/log/prabal-urja/opcua-audit.log`
- `/var/log/prabal-urja/process-actual.log`
- `/var/log/prabal-urja/pcap/opcua-evidence.pcap*`
- `journalctl -u prabal-opcua.service`
- `journalctl -u prabal-hmi.service`
- `/etc/prabal-urja/scenario1.env`
- Blue evidence archive and SHA-256

### Indicators of Compromise / Abnormal Behaviour

- OPC UA session from an unapproved non-loopback client
- broad namespace browsing
- write operations to maintenance-control nodes
- use of work order `PU-MW-0427` outside an approved session
- `OVERRIDE_ACTIVE` event
- HMI state `UNAUTHORISED_MAINTENANCE_OVERRIDE`
- data quality `UNCERTAIN_LAST_USABLE_VALUE`

### Tactics, Techniques and Procedures

**MITRE ATT&CK for ICS: T1692.001 — Unauthorized Message: Command Message**  
The attacker transmitted OPC UA write operations that instructed the telemetry gateway to enter an unauthorised maintenance condition.

**MITRE ATT&CK for ICS: T0836 — Modify Parameter**  
The attacker changed maintenance, telemetry-freeze and alarm-suppression parameters to alter how Unit-2 conditions were presented.

**MITRE ATT&CK for ICS: T0869 — Standard Application Layer Protocol**  
The activity used legitimate OPC UA communication rather than a custom destructive service.

### Root Cause

- SecurityPolicy `None` exposed
- anonymous identity accepted
- selected maintenance nodes writable without user or application authorisation
- work-order identifier used as a logical prerequisite rather than independent approval
- insufficient network restriction around the engineering endpoint

### Mitigation Recommendations

- remove SecurityPolicy `None` from operational endpoints;
- require signed and encrypted sessions;
- implement application certificate trust and user authentication;
- enforce role-based node permissions;
- restrict engineering access to approved source systems;
- expire and independently authorise maintenance work orders;
- alert on new clients, namespace-wide browse activity and write operations;
- retain protocol-aware packet and application logs;
- regularly compare live HMI data with independent process sources.

---

## 5. Communication

**Internal Notification:**

- OT Security Operations: immediate incident coordination
- Prabal Urja Shift Operations: telemetry-integrity warning
- Turbine Maintenance: confirm approved work-order status
- Network Operations: source-specific containment support
- Exercise Controller: safety and progression decision
- Hydro Plant Control Zone owner: precautionary review of `PU-GOV-PLC-02`

**External Notification:**

- None for the training exercise unless directed by the exercise authority.
- In a real event, follow organisational and CERT-In reporting obligations applicable to the affected entity and impact.

**Updates:**

- Frequency: every 60 minutes until telemetry trust and access control are restored
- Channel: approved incident command channel and encrypted incident record

---

## 6. Additional Notes

Scenario 1 is connected to the larger campaign through engineering metadata identifying `PU-GOV-PLC-02` and Modbus/TCP. Scenario 2 must not be treated as compromised without independent evidence.

---

## 7. Submission

**Prepared By:** [Blue Team Analyst Name]  
**Incident Commander:** [Name]  
**Technical Reviewer:** [Name]

## 8. POC and Screenshots

Attach:

1. HMI during the telemetry hold
2. OPC UA audit timeline
3. actual versus displayed process values
4. packet evidence and attacker source
5. containment rule
6. restored HMI state
7. denied remote write after remediation
8. evidence archive checksum
