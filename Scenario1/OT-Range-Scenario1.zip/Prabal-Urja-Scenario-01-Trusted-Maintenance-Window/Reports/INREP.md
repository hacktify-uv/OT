# Incident Notification Report (INREP)

**Cyber Exercise — Operation GRID SENTINEL: PRABAL URJA**  
**Scenario:** S01 — The Trusted Maintenance Window  
**Version 1.0**

---

**Date:** [YYYY-MM-DD]  
**Time:** [Time of Incident in IST and UTC]  
**Report ID:** IN-OT-RB01-S01  
**Classification:** TRAINING / CONTROLLED

---

## 1. Current Situation

**Description:** An unauthorised maintenance state has been identified on the Prabal Urja Unit-2 engineering telemetry gateway, asset `PU-OPCUA-GW-01`. The operator console is receiving last-usable telemetry values while the locally simulated process continues to change. The incident is consistent with unauthorised OPC UA maintenance-node writes from a remote client.

**Threat Level:** High

**Operational Status:**

- Unit-2 generation simulation: Running
- OPC UA service: [Up / Down]
- Operator console: [Up / Down]
- Telemetry integrity: [Trusted / Suspect / Restored]
- Alarm presentation: [Normal / Suppressed / Restored]

**Areas of Concern:**

- Unauthenticated or unauthorised OPC UA client access
- Modification of `MaintenanceMode`, `FreezeTelemetry`, `AlarmSuppression`, or `MaintenanceTicket`
- False confidence caused by stable but stale operator values
- Disclosure of the downstream controller `PU-GOV-PLC-02` and its Modbus/TCP relationship
- Potential progression from the Vendor / OT Access Zone toward the Hydro Plant Control Zone

---

## 2. Threat Intelligence

**Sources:**

- OPC UA audit log: `/var/log/prabal-urja/opcua-audit.log`
- Actual process log: `/var/log/prabal-urja/process-actual.log`
- systemd journal: `journalctl -u prabal-opcua.service`
- HMI state: `http://127.0.0.1:8088/api/state`
- Packet captures: `/var/log/prabal-urja/pcap/opcua-evidence.pcap*`
- Active socket table: `ss -tnp state established '( sport = :4840 )'`

**Indicators of Compromise / Abnormal Behaviour:**

- Remote OPC UA session from `[ATTACKER_IP]`
- Broad namespace browsing outside an approved engineering task
- `NODE_WRITE_DETECTED` events for maintenance controls
- `OVERRIDE_ACTIVE` audit event
- `TelemetryQuality=UNCERTAIN_LAST_USABLE_VALUE`
- `ScenarioState=UNAUTHORISED_MAINTENANCE_OVERRIDE`
- Difference between changing `actual_power_mw` and fixed `displayed_power_mw`

**Log Entry Identified:**

```text
[Paste exact timestamped NODE_WRITE_DETECTED and OVERRIDE_ACTIVE entries]
```

**Initial Detection Source:** [HMI observation / SIEM / packet analytics / field report / audit review]

---

## 3. Vulnerability Identification

**Vulnerability:** Missing authentication and insufficient authorisation on OPC UA maintenance controls

**Affected Function:** Unit-2 `TelemetryGateway` maintenance-control nodes

**Affected Asset:** `PU-OPCUA-GW-01`

**Description:** The OPC UA endpoint permits anonymous namespace access and exposes selected maintenance variables with write permission. The server accepts a discoverable work-order reference as an operational prerequisite but does not verify the identity, role, source workstation, or independent approval of the writer. An unauthorised client can therefore activate a telemetry hold and alarm suppression without compromising the operating system.

**Related Weaknesses:**

- CWE-306 — Missing Authentication for Critical Function
- CWE-862 — Missing Authorization
- CWE-284 — Improper Access Control

**Patch Status:** [Not Started / Containment Applied / Remote Writes Disabled / Fully Remediated]

---

## 4. Security Operations

**Immediate Actions:**

1. Preserve logs, packet captures and current process state.
2. Identify the remote source through packet and socket evidence.
3. Apply a source-specific block for TCP 4840 without interrupting the local HMI client.
4. Disable remote maintenance writes in `/etc/prabal-urja/scenario1.env`.
5. Restart only the required services to clear volatile unsafe state.
6. Verify live telemetry movement and good data quality.
7. Notify the Hydro Plant Control Zone owner about disclosure of `PU-GOV-PLC-02`.

**Containment Rule:**

```bash
sudo nft add rule inet prabal_s01 input ip saddr <ATTACKER_IP> tcp dport 4840 counter drop comment 'Prabal S01 temporary containment'
```

**Configuration Remediation:**

```bash
sudo sed -i 's/^OPCUA_ALLOW_REMOTE_WRITE=.*/OPCUA_ALLOW_REMOTE_WRITE=0/' /etc/prabal-urja/scenario1.env
sudo systemctl restart prabal-opcua.service prabal-hmi.service
```

**Validation:**

```bash
sudo /opt/prabal-urja/scenario1/venv/bin/python \
  /opt/prabal-urja/scenario1/tools/opcua_probe.py \
  --endpoint opc.tcp://127.0.0.1:4840

curl -fsS http://127.0.0.1:8088/api/health | jq .
```

---

## 5. Additional Notes

This event is the first stage of the interconnected Prabal Urja exercise. The exposed engineering metadata identifies a downstream controller and protocol but does not by itself confirm compromise of Scenario 2.

**Connected service requiring precautionary review:**

- `PU-GOV-PLC-02`
- Hydro Plant Control Zone: `195.40.10.0/24`
- Southbound protocol: Modbus/TCP

**Safety Note:** Do not stop the entire target VM or block all OPC UA communication unless the exercise controller declares an emergency. The preferred action is evidence-led, source-specific containment.

---

## 6. POC and Evidence

Attach:

- Screenshot of operator console before and during the telemetry hold
- Audit entries showing maintenance-node writes
- Process-log comparison showing actual versus displayed values
- Packet evidence identifying the remote source
- nftables containment rule
- post-remediation write-denial evidence
- evidence archive SHA-256

**Evidence Archive:** `[path or evidence repository reference]`  
**SHA-256:** `[hash]`

---

**Prepared By:** [Blue Team Analyst Name]  
**Reviewed By:** [Incident Commander / Exercise Controller]  
**Next Update Due:** [Date and time]
