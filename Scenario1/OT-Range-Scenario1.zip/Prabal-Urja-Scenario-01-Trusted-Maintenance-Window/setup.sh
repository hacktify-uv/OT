#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="/var/log/prabal-urja-s01-setup.log"
INSTALL_DIR="/opt/prabal-urja/scenario1"
ENV_DIR="/etc/prabal-urja"
ENV_FILE="$ENV_DIR/scenario1.env"
LOG_DIR="/var/log/prabal-urja"
STATE_DIR="/var/lib/prabal-urja"
SERVICE_USER="prabalot"
SERVICE_GROUP="prabalot"

OPCUA_PORT="${PRABAL_OPCUA_PORT:-4840}"
HMI_PORT="${PRABAL_HMI_PORT:-8088}"
CAPTURE_INTERFACE="${PRABAL_CAPTURE_INTERFACE:-any}"
SKIP_APT_UPDATE="${PRABAL_SKIP_APT_UPDATE:-0}"

on_error() {
  local rc=$?
  echo "[!] Setup failed at line ${BASH_LINENO[0]} with exit code ${rc}." >&2
  echo "[!] Review ${LOG_FILE}." >&2
  exit "$rc"
}
trap on_error ERR

if [[ $EUID -ne 0 ]]; then
  echo "Run setup.sh as root: sudo bash setup.sh" >&2
  exit 1
fi

mkdir -p "$(dirname "$LOG_FILE")"
touch "$LOG_FILE"
chmod 0600 "$LOG_FILE"
exec > >(tee -a "$LOG_FILE") 2>&1

echo "[+] Prabal Urja Scenario 1 installation started at $(date -u --iso-8601=seconds)"

if [[ -r /etc/os-release ]]; then
  # shellcheck disable=SC1091
  source /etc/os-release
  echo "[+] Detected Linux Distribution: ${PRETTY_NAME:-${ID:-Unknown}}"
else
  echo "[!] WARNING: /etc/os-release missing. Proceeding on unknown Linux distribution..." >&2
fi

if ! command -v systemctl >/dev/null 2>&1 || [[ ! -d /run/systemd/system ]]; then
  echo "[!] ERROR: This Scenario 1 release requires systemd." >&2
  echo "[!] Supported examples: Ubuntu, Debian, Kali, Parrot, Fedora, RHEL, Rocky, AlmaLinux, Arch, Manjaro, openSUSE." >&2
  echo "[!] Not supported in this release: Alpine/OpenRC, non-systemd containers, minimal WSL without systemd." >&2
  echo "[!] To support Alpine/OpenRC, add OpenRC init scripts instead of systemd unit files." >&2
  exit 1
fi

for port in "$OPCUA_PORT" "$HMI_PORT"; do
  if ! [[ "$port" =~ ^[0-9]+$ ]] || (( port < 1024 || port > 65535 )); then
    echo "[!] ERROR: Invalid service port: $port" >&2
    exit 1
  fi
done

if [[ "$OPCUA_PORT" == "$HMI_PORT" ]]; then
  echo "[!] ERROR: OPC UA and HMI ports must be different." >&2
  exit 1
fi

PRABAL_SKIP_APT_UPDATE="$SKIP_APT_UPDATE" "$SCRIPT_DIR/deps.sh"

PYTHON_BIN="${PRABAL_PYTHON_BIN:-}"
if [[ -z "$PYTHON_BIN" ]]; then
  # Search standard system locations first to avoid user-level pyenv/conda installations
  for p in /usr/bin/python3 /usr/bin/python /bin/python3 /bin/python; do
    if [[ -x "$p" ]]; then
      PYTHON_BIN="$p"
      break
    fi
  done
fi
if [[ -z "$PYTHON_BIN" ]]; then
  PYTHON_BIN="$(command -v python3 || command -v python || true)"
fi

if [[ -z "$PYTHON_BIN" ]]; then
  echo "[!] ERROR: python3/python not found after dependency installation." >&2
  exit 1
fi

if [[ -x /usr/sbin/nologin ]]; then
  NOLOGIN_SHELL="/usr/sbin/nologin"
elif [[ -x /sbin/nologin ]]; then
  NOLOGIN_SHELL="/sbin/nologin"
elif [[ -x /bin/false ]]; then
  NOLOGIN_SHELL="/bin/false"
elif [[ -x /usr/bin/false ]]; then
  NOLOGIN_SHELL="/usr/bin/false"
else
  NOLOGIN_SHELL="/bin/false"
fi

if ! getent group "$SERVICE_GROUP" >/dev/null; then
  if command -v groupadd >/dev/null 2>&1; then
    groupadd -r "$SERVICE_GROUP" 2>/dev/null || groupadd --system "$SERVICE_GROUP"
  elif command -v addgroup >/dev/null 2>&1; then
    addgroup --system "$SERVICE_GROUP"
  else
    echo "[!] ERROR: No tool found to create system groups." >&2
    exit 1
  fi
fi

if ! id "$SERVICE_USER" >/dev/null 2>&1; then
  if command -v useradd >/dev/null 2>&1; then
    useradd -r -g "$SERVICE_GROUP" -d "$INSTALL_DIR" -s "$NOLOGIN_SHELL" "$SERVICE_USER" 2>/dev/null || \
    useradd --system --gid "$SERVICE_GROUP" --home-dir "$INSTALL_DIR" --shell "$NOLOGIN_SHELL" "$SERVICE_USER"
  elif command -v adduser >/dev/null 2>&1; then
    adduser --system --ingroup "$SERVICE_GROUP" --home "$INSTALL_DIR" --shell "$NOLOGIN_SHELL" "$SERVICE_USER"
  else
    echo "[!] ERROR: No tool found to create system users." >&2
    exit 1
  fi
fi

systemctl stop prabal-hmi.service prabal-opcua-capture.service prabal-opcua.service 2>/dev/null || true

install -d -m 0755 -o root -g root "$INSTALL_DIR"
install -d -m 0755 -o root -g root "$INSTALL_DIR/source" "$INSTALL_DIR/vendor" "$INSTALL_DIR/bin" "$INSTALL_DIR/tools"
install -d -m 0755 -o "$SERVICE_USER" -g "$SERVICE_GROUP" "$INSTALL_DIR/hmi"
install -d -m 0755 -o root -g root "$ENV_DIR"
install -d -m 0750 -o "$SERVICE_USER" -g "$SERVICE_GROUP" "$LOG_DIR" "$STATE_DIR"
install -d -m 0750 -o root -g "$SERVICE_GROUP" "$LOG_DIR/pcap"

rm -rf "$INSTALL_DIR/source" "$INSTALL_DIR/vendor" "$INSTALL_DIR/hmi" "$INSTALL_DIR/tools"

cp -a "$SCRIPT_DIR/Challenge-Files/source" "$INSTALL_DIR/source"
cp -a "$SCRIPT_DIR/Challenge-Files/vendor" "$INSTALL_DIR/vendor"
cp -a "$SCRIPT_DIR/Challenge-Files/hmi" "$INSTALL_DIR/hmi"
cp -a "$SCRIPT_DIR/Challenge-Files/tools" "$INSTALL_DIR/tools"

find "$INSTALL_DIR/tools" -type f -name '*.sh' -exec chmod 0755 {} +
find "$INSTALL_DIR/tools" -type f -name '*.py' -exec chmod 0755 {} +

cat > "$ENV_FILE" <<ENVEOF
# Prabal Urja Scenario 1 runtime configuration
OPCUA_PORT=$OPCUA_PORT
HMI_PORT=$HMI_PORT
OPCUA_ENDPOINT=opc.tcp://127.0.0.1:$OPCUA_PORT
OPCUA_ALLOW_REMOTE_WRITE=1
HMI_POLL_SECONDS=1.0
CAPTURE_INTERFACE=$CAPTURE_INTERFACE
PRABAL_AUDIT_LOG=$LOG_DIR/opcua-audit.log
PRABAL_PROCESS_LOG=$LOG_DIR/process-actual.log
ENVEOF

chmod 0640 "$ENV_FILE"
chown root:"$SERVICE_GROUP" "$ENV_FILE"

install -o "$SERVICE_USER" -g "$SERVICE_GROUP" -m 0640 /dev/null "$LOG_DIR/opcua-audit.log"
install -o "$SERVICE_USER" -g "$SERVICE_GROUP" -m 0640 /dev/null "$LOG_DIR/process-actual.log"

BUILD_DIR="$INSTALL_DIR/build"
rm -rf "$BUILD_DIR"

cmake -S "$INSTALL_DIR/source" -B "$BUILD_DIR" -DCMAKE_BUILD_TYPE=Release

cmake --build "$BUILD_DIR" \
  --target prabal-opcua-server \
  --parallel "$(getconf _NPROCESSORS_ONLN 2>/dev/null || nproc 2>/dev/null || echo 2)"

install -o root -g root -m 0755 "$BUILD_DIR/prabal-opcua-server" "$INSTALL_DIR/bin/prabal-opcua-server"

rm -rf "$INSTALL_DIR/venv"
"$PYTHON_BIN" -m venv "$INSTALL_DIR/venv"
"$INSTALL_DIR/venv/bin/python" -m pip install --upgrade pip setuptools wheel

WHEELHOUSE="$SCRIPT_DIR/Challenge-Files/wheelhouse"

if compgen -G "$WHEELHOUSE/*.whl" >/dev/null; then
  echo "[+] Installing Python dependencies from packaged wheelhouse."
  "$INSTALL_DIR/venv/bin/pip" install \
    --no-index \
    --find-links "$WHEELHOUSE" \
    -r "$INSTALL_DIR/hmi/requirements.txt"
else
  echo "[+] No packaged wheelhouse found; installing pinned Python dependencies from PyPI."
  "$INSTALL_DIR/venv/bin/pip" install --no-cache-dir -r "$INSTALL_DIR/hmi/requirements.txt"
fi

echo "[+] Applying Python 3.14+ PEP 649 compatibility patch to virtualenv..."
SITEDIR=$("$INSTALL_DIR/venv/bin/python" -c "import site; print(site.getsitepackages()[0])")
cp "$SCRIPT_DIR/Challenge-Files/sitecustomize.py" "$SITEDIR/sitecustomize.py"
chmod 0644 "$SITEDIR/sitecustomize.py"
chown root:root "$SITEDIR/sitecustomize.py"

chown -R root:root "$INSTALL_DIR/source" "$INSTALL_DIR/vendor" "$INSTALL_DIR/bin" "$INSTALL_DIR/tools" "$INSTALL_DIR/venv"
chown -R "$SERVICE_USER":"$SERVICE_GROUP" "$INSTALL_DIR/hmi"
chmod -R go-w "$INSTALL_DIR"

install -o root -g root -m 0644 "$SCRIPT_DIR/Challenge-Files/systemd/prabal-opcua.service" /etc/systemd/system/prabal-opcua.service
install -o root -g root -m 0644 "$SCRIPT_DIR/Challenge-Files/systemd/prabal-hmi.service" /etc/systemd/system/prabal-hmi.service
install -o root -g root -m 0644 "$SCRIPT_DIR/Challenge-Files/systemd/prabal-opcua-capture.service" /etc/systemd/system/prabal-opcua-capture.service

systemctl daemon-reload
systemctl enable --now prabal-opcua.service

for _ in {1..20}; do
  if ss -ltn 2>/dev/null | grep -Eq ":${OPCUA_PORT}[[:space:]]" || \
     netstat -ltn 2>/dev/null | grep -Eq ":${OPCUA_PORT}[[:space:]]"; then
    break
  fi
  sleep 1
done

systemctl enable --now prabal-hmi.service
systemctl enable --now prabal-opcua-capture.service

sleep 10

"$SCRIPT_DIR/validate.sh"

PRIMARY_IP="$(ip route get 1.1.1.1 2>/dev/null | grep -oP 'src \K\S+' || \
              hostname -I 2>/dev/null | awk '{print $1}' || \
              ip -4 addr show scope global 2>/dev/null | awk '/inet/ {print $2}' | cut -d/ -f1 | head -n1 || \
              echo '127.0.0.1')"

echo
printf '[+] HMI:    http://%s:%s/\n' "${PRIMARY_IP}" "$HMI_PORT"
printf '[+] OPC UA: opc.tcp://%s:%s\n' "${PRIMARY_IP}" "$OPCUA_PORT"

if [[ -n "$PRIMARY_IP" && "$PRIMARY_IP" != 195.* && "$PRIMARY_IP" != "127.0.0.1" ]]; then
  echo "[!] Documentation uses the isolated 195.0.0.0/8 exercise plan. This host currently has $PRIMARY_IP."
  echo "[!] Assign the correct exercise address at the infrastructure layer; challenge code does not hardcode an IP."
fi

echo "[+] Scenario 1 setup completed successfully."
