#!/usr/bin/env bash
set -Eeuo pipefail
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
if [[ "${1:-}" != '--installed' ]]; then
 python3 -m py_compile "$ROOT/Challenge-Files/hmi/operator_console.py" "$ROOT/Challenge-Files/model/protection_model.py"
 bash -n "$ROOT/setup.sh"; echo 'STATIC_VALIDATION:PASS'; exit 0
fi
systemctl is-active --quiet prabal-s05-mms.service
systemctl is-active --quiet prabal-s05-hmi.service
ss -ltn | awk '{print $4}' | grep -Eq '(^|:)102$'
/opt/prabal-urja/scenario5/bin/pu_s05_mms_client 127.0.0.1 102
curl -fsS http://127.0.0.1:8098/api/state | jq -e '.asset=="PU-DSS-IED-01" and .protocol=="IEC61850-MMS"'
echo 'S05_MMS_PROTOCOL_AND_STATE:PASS'
