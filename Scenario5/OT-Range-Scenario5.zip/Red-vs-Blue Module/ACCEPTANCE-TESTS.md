# Scenario 05: validation protocol

**No native Ubuntu compilation, live IEC 61850 MMS packet exchange, setting-group activation, or complete Red/Blue run has been demonstrated for this ZIP.** The source and static tests are supplied as an initial implementation.

## 1. Install on a new dedicated VM

Do not reuse the Scenario 03 VM or the Scenario 04 runtime. Obtain libIEC61850 v1.6.2.1 on the target and compile using `setup.sh`. The previous JSON-over-TCP102 emulator is intentionally absent.

```sh
sudo bash setup.sh
sudo bash validate.sh --installed
sudo journalctl -u prabal-s05-mms.service -n 60 --no-pager
```

## 2. Prove genuine MMS, not an HTTP or JSON substitute

Capture real MMS packets on TCP102 using Wireshark/tshark. With a separately built client or another standard IEC 61850 client, browse `PU-DSS-IED-01LD0`, confirm `PTOC1` and `LLN0.SGCB`, and read live status. These interactions and the SGCB attribute reference must be validated against the compiled protocol library; the native client in this package is a starting candidate.

```sh
/opt/prabal-urja/scenario5/bin/pu_s05_mms_client 127.0.0.1 102
```

## 3. Independent same-current protection test

The test current is instructor-controlled, not an attacker-provided API. In approved group 1, a 1300A test should trip (800A threshold). After a genuine MMS setting-group activation to group 2, the same 1300A test should not trip (1600A threshold). Before repeating, restore the server and audit the previous events.

```sh
sudo /opt/prabal-urja/scenario5/tools/instructor_fault_test.sh 1300
# Independently verify native MMS setting-group activation before the second test.
sudo /opt/prabal-urja/scenario5/tools/instructor_fault_test.sh 1300
```

Record actual MMS SetActSG response, group readback, IED event log and relay-state.json. The exact library API and data-model linkage are **UNVERIFIED** until Ubuntu execution.

## 4. Blue Team / scoring

Run the one-line TTP only after recording a fresh 1300A test and capture `UP` with group1 and `DOWN` with group2. Restore the approved group and breaker state without erasing audit files, rerun the independent test, and confirm `UP`. Do not claim physical protection testing: this is a simulated relay driven by instructor-controlled input.

## 5. Handoff

The IED name and engineering `.scd` must agree with Scenario 04's station register. This establishes a credible discovery link. There is no inherent routed link from Scenario 04 to TCP102.
