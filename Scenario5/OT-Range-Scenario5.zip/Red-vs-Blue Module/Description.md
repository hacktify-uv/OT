# Scenario 05: IEC 61850 Protection Setting-Group Abuse

The participant investigates a genuine IEC 61850 MMS IED, identifies its PTOC protection function and LLN0 Setting Group Control Block, and demonstrates that a commissioning-only high-threshold group can be activated without the required approval. An independent instructor-applied overcurrent stimulus tests relay behaviour. This is an intentionally vulnerable OT model, not a claim of a vendor CVE.
