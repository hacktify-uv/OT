# Prabal Urja Scenario 05 | Native IEC 61850 Protection Setting Groups

**Status:** deployment candidate. Native C compilation and MMS setting-group activation require live Ubuntu validation. No JSON-over-TCP/102 impersonation remains.

## Operational handoff
Scenario 4's published engineering file identifies `PU-DSS-IED-01`, `BAY01`, `PTOC1`, and an IEC 61850 MMS engineering service. The CTF platform assigns the independently launched S5 instance a floating IP. No direct S3/S4 network connection is claimed and neither earlier VM is modified.

## Native OT implementation
- `libIEC61850` creates an MMS server on TCP 102 with LLN0 SGCB containing two groups.
- `PTOC1` has an overcurrent pickup threshold of 800 A in approved group 1; the commissioning group 2 has 1600 A.
- An MMS SetActSG request is handled by an application callback. The vulnerable policy accepts group 2 without commissioning approval. Direct arbitrary SG data-attribute writes are explicitly denied, so the intended route is a native SGCB activation.
- Instructed current is supplied only through a root-owned local fixture, never an attacker API.
- At 1300 A, group 1 must trip whereas group 2 should not trip. The observable result is an independent protection-model response. Autoreclose does not affect the initial trip.
- Operator HMI on port 8098 and SCL engineering record read-only.

## Install
Run on its **own fresh Ubuntu 22.04/24.04 VM**, not Scenario 3 or Scenario 4. Internet is needed for `libIEC61850` source unless pre-staged:

```bash
sudo bash setup.sh
sudo bash validate.sh --installed
```

`setup.sh` obtains upstream library `v1.6.2.1`, compiles the native C binaries, and creates systemd services. This code has NOT been native-compiled in the current preparation environment, because the upstream source is not available locally.

## Independent engineering verification
From an authorised client host, use an IEC 61850 MMS engineering browser such as IEDScout or another compatible client. The package includes a separate standard-libIEC61850 C client for MMS read and SetActSG, but no custom Python API exploit script. Changing groups requires an actual MMS write and server callback.

The control group is `LLN0.SGCB` under the IED model `PU-DSS-IED-01LD0`; native client invocation after build:

```bash
./pu_s05_mms_client <target-ip> 102          # protocol read
./pu_s05_mms_client <target-ip> 102 2        # request SetActSG=2
```

This reference client verifies protocol use; every successful write and physical-model consequence must be captured from a live test. The exposed engineering record describes the equipment but not a hidden success endpoint.

## Independent instructor test

```bash
sudo /opt/prabal-urja/scenario5/tools/instructor_fault_test.sh 1300
```

Before group change, baseline must trip. After a confirmed group-2 MMS setting activation and a controlled reset, the same fault must fail to trip and the CTF should report `DOWN`. This is a **simulation** using native MMS control, not a tested vendor firmware vulnerability.

## Defence and recovery
Preserve the actual `prabal-s05-mms` journal and `/var/log/prabal-urja/scenario5/relay-events.jsonl` before restoring group 1. Re-test the same independent fault. The actual root cause is missing approval enforcement in the SGCB callback, not an OPC UA/Modbus/DNP3 authentication bypass.

## Known limitations
- No genuine GOOSE functionality is currently claimed or packaged.
- Native build and runtime validation are not yet performed. Do not publish a solved Red/Blue write-up until the real outputs are captured.
- No shared power-flow state connects independently launched VMs.

Reference: https://github.com/mz-automation/libiec61850
