#!/usr/bin/env bash
set -Eeuo pipefail
trap 'echo "INSTALL_FAILED at line $LINENO" >&2' ERR
[[ $EUID -eq 0 ]] || { echo 'Run with sudo bash setup.sh' >&2; exit 1; }
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
DEST=/opt/prabal-urja/scenario5
if [[ -e /opt/prabal-urja/scenario3 && "$DEST" == /opt/prabal-urja/scenario3 ]]; then exit 9; fi
bash "$ROOT/deps.sh"
getent group prabal-s05 >/dev/null || groupadd --system prabal-s05
id prabal-s05 >/dev/null 2>&1 || useradd --system --no-create-home --shell /usr/sbin/nologin -g prabal-s05 prabal-s05
install -d -m 0750 -o root -g prabal-s05 "$DEST"
cp -a "$ROOT/Challenge-Files/." "$DEST/"
find "$DEST" -type f -name '*.sh' -exec chmod 0755 {} +
chown -R root:prabal-s05 "$DEST"
chmod 0750 "$DEST"
install -d -m 0750 -o prabal-s05 -g prabal-s05 /var/lib/prabal-urja/scenario5
install -d -m 0750 -o prabal-s05 -g prabal-s05 /var/log/prabal-urja/scenario5
install -d -m 0750 -o root -g prabal-s05 /var/lib/prabal-urja/scenario5/instructor
printf '0\n' >/var/lib/prabal-urja/scenario5/instructor/current-amps
printf '0\n' >/var/lib/prabal-urja/scenario5/instructor/reset-trip
chown root:prabal-s05 /var/lib/prabal-urja/scenario5/instructor/*
chmod 0640 /var/lib/prabal-urja/scenario5/instructor/*
# Require a verified native upstream library, NOT the legacy JSON port-102 emulator.
LIBSRC=/usr/local/src/prabal-libiec61850
if [[ ! -d "$LIBSRC/src" ]]; then
  mkdir -p "$(dirname "$LIBSRC")"
  git clone --depth 1 --branch v1.6.2.1 https://github.com/mz-automation/libiec61850.git "$LIBSRC"
fi
cmake -S "$LIBSRC" -B "$LIBSRC/build" -DCMAKE_BUILD_TYPE=Release
cmake --build "$LIBSRC/build" -j"$(nproc)"
cmake --install "$LIBSRC/build"
ldconfig
INC=$(find /usr/local/include /usr/include "$LIBSRC" -name iec61850_server.h -printf '%h\n' 2>/dev/null | head -1)
CLIENTINC=$(find /usr/local/include /usr/include "$LIBSRC" -name iec61850_client.h -printf '%h\n' 2>/dev/null | head -1)
DYNINC=$(find /usr/local/include /usr/include "$LIBSRC" -name iec61850_dynamic_model.h -printf '%h\n' 2>/dev/null | head -1)
HALINC=$(find /usr/local/include /usr/include "$LIBSRC" -name hal_thread.h -printf '%h\n' 2>/dev/null | head -1)
MMSINC=$(find /usr/local/include /usr/include "$LIBSRC" -name mms_value.h -printf '%h\n' 2>/dev/null | head -1)
LIB=/usr/local/lib/libiec61850.so
[[ -n $INC && -n $CLIENTINC && -n $DYNINC && -n $HALINC && -n $MMSINC && -n $LIB ]] || { echo 'LIBIEC61850_HEADERS_OR_LIBRARY_MISSING' >&2; exit 1; }
mkdir -p "$DEST/bin"
LIBDIR=$(dirname "$LIB")
CFLAGS=(-std=c99 -O2 -Wall -Wextra -I"$INC" -I"$CLIENTINC" -I"$DYNINC" -I"$HALINC" -I"$MMSINC")
LDFLAGS=(-L"$LIBDIR" -Wl,-rpath,"$LIBDIR" -liec61850 -lpthread -lm)
gcc "${CFLAGS[@]}" "$DEST/native/pu_s05_ied_server.c" "${LDFLAGS[@]}" -o "$DEST/bin/pu_s05_ied_server"
gcc "${CFLAGS[@]}" "$DEST/native/pu_s05_mms_client.c" "${LDFLAGS[@]}" -o "$DEST/bin/pu_s05_mms_client"
chown root:prabal-s05 "$DEST/bin/"*;chmod 0750 "$DEST/bin/"*
for unit in "$DEST/systemd/"*.service; do install -m 0644 "$unit" "/etc/systemd/system/$(basename "$unit")"; done
systemctl daemon-reload
systemctl enable --now prabal-s05-mms.service prabal-s05-hmi.service
sleep 3
bash "$ROOT/validate.sh" --installed
printf 'S05_NATIVE_MMS_INSTALL:COMPLETE\n'
