#!/usr/bin/env python3
import json,mimetypes,sys,time
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
BASE=Path('/opt/prabal-urja/scenario5/engineering')
STATE=Path('/var/lib/prabal-urja/scenario5/relay-state.json')
class Handler(BaseHTTPRequestHandler):
 def log_message(self,fmt,*args):
  print('S05_HMI_ACCESS source='+self.client_address[0]+' '+(fmt%args),file=sys.stderr,flush=True)
 def reply(self,body,ctype='application/json',code=200):
  self.send_response(code);self.send_header('Content-Type',ctype);self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(body)
 def do_GET(self):
  if self.path in ('/api/state','/api/health'):
   try:
    st=json.loads(STATE.read_text());age=time.time()-st['epoch'];healthy=age<5
   except Exception:st={};healthy=False
   if self.path=='/api/health':return self.reply(json.dumps({'status':'UP' if healthy else 'DOWN','protocol':'IEC61850-MMS'}).encode(),code=200 if healthy else 503)
   return self.reply(json.dumps(st).encode(),code=200 if healthy else 503)
  if self.path=='/robots.txt':return self.reply(b'User-agent: *\nDisallow: /engineering/PU-DSS-IED-01.scd\n','text/plain')
  p=(BASE/self.path.removeprefix('/engineering/')).resolve() if self.path.startswith('/engineering/') else None
  if not p or BASE.resolve() not in p.parents or not p.is_file():return self.reply(b'not found','text/plain',404)
  return self.reply(p.read_bytes(),mimetypes.guess_type(p.name)[0] or 'application/octet-stream')
ThreadingHTTPServer(('0.0.0.0',8098),Handler).serve_forever()
