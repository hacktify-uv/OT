#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <signal.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>
#include "iec61850_server.h"
#include "iec61850_dynamic_model.h"
#include "mms_value.h"
#include "hal_thread.h"

/* Native libIEC61850 MMS server; no TCP/102 JSON protocol exists in this package. */
#define ROOT "/var/lib/prabal-urja/scenario5"
#define STATE ROOT "/relay-state.json"
#define INSTRUCTOR_CURRENT ROOT "/instructor/current-amps"
#define INSTRUCTOR_RESET ROOT "/instructor/reset-trip"
#define EVENT_LOG "/var/log/prabal-urja/scenario5/relay-events.jsonl"
static volatile sig_atomic_t running=1;
static volatile int active_group=1;
static float test_current=0.0f;
static float last_test_current=0.0f;
static int last_test_group=0;
static bool last_test_trip=false;
static bool prev_injected=false;
static bool breaker_closed=true;
static bool trip=false;
static IedServer server;
static DataAttribute *da_str,*da_op,*da_trip,*da_pos,*da_current,*da_threshold;
static float threshold(int group) { return (group==1)?800.0f:1600.0f; }
static void signal_stop(int sig) { (void)sig; running=0; }
static void event(const char* type, int value) {
    FILE *f=fopen(EVENT_LOG,"a"); if(!f) return;
    fprintf(f,"{\"epoch\":%lld,\"event\":\"%s\",\"active_group\":%d,\"value\":%d}\n",
       (long long)time(NULL),type,active_group,value);
    fclose(f);
}
static void write_state(void) {
    char tmp[256]; snprintf(tmp,sizeof(tmp),"%s.tmp.%d",STATE,(int)getpid());
    FILE *f=fopen(tmp,"w"); if(!f)return;
    fprintf(f,"{\"asset\":\"PU-DSS-IED-01\",\"protocol\":\"IEC61850-MMS\",\"active_setting_group\":%d,\"threshold_amps\":%.1f,\"test_current_amps\":%.1f,\"last_test_current_amps\":%.1f,\"last_test_group\":%d,\"last_test_trip\":%s,\"protection_trip\":%s,\"breaker_closed\":%s,\"epoch\":%lld}\n",
       active_group,threshold(active_group),test_current,last_test_current,last_test_group,last_test_trip?"true":"false",trip?"true":"false",breaker_closed?"true":"false",(long long)time(NULL));
    fflush(f);fsync(fileno(f));fclose(f);rename(tmp,STATE);
}
/* Intentionally weak engineering approval: no separate protection-commissioning signoff.
   The operation is still a genuine MMS SetActSG service handled by libIEC61850. */
static bool active_changed(void *parameter, SettingGroupControlBlock *sgcb,
                           uint8_t group, ClientConnection connection) {
    (void)parameter;(void)sgcb;(void)connection;
    if(group<1||group>2)return false;
    active_group=group;
    event("MMS_ACTIVE_SETTING_GROUP_ACCEPTED",group);
    return true;
}
static float read_current(void){
    FILE *f=fopen(INSTRUCTOR_CURRENT,"r");float amp=0.0f;
    if(f){if(fscanf(f,"%f",&amp)!=1)amp=0;fclose(f);}
    return amp>=0 && amp<20000?amp:0;
}
int main(void){
    signal(SIGINT,signal_stop);signal(SIGTERM,signal_stop);
    IedModel* model=IedModel_create("PU-DSS-IED-01");
    IedModel_setIedNameForDynamicModel(model,"PU-DSS-IED-01");
    LogicalDevice* ld=LogicalDevice_create("LD0",model);
    LogicalNode *lln0=LogicalNode_create("LLN0",ld);
    LogicalNode *ptoc=LogicalNode_create("PTOC1",ld);
    LogicalNode *ptrc=LogicalNode_create("PTRC1",ld);
    LogicalNode *xcbr=LogicalNode_create("XCBR1",ld);
    LogicalNode *mmxu=LogicalNode_create("MMXU1",ld);
    LogicalNode_create("RREC1",ld);
    SettingGroupControlBlock *sgcb=SettingGroupControlBlock_create(lln0,1,2);
    DataObject *str=DataObject_create("Str",(ModelNode*)ptoc,0);
    DataObject *op=DataObject_create("Op",(ModelNode*)ptoc,0);
    DataObject *tr=DataObject_create("Tr",(ModelNode*)ptrc,0);
    DataObject *pos=DataObject_create("Pos",(ModelNode*)xcbr,0);
    DataObject *amp=DataObject_create("A",(ModelNode*)mmxu,0);
    DataObject *mag=DataObject_create("mag",(ModelNode*)amp,0);
    DataObject *strval=DataObject_create("StrVal",(ModelNode*)ptoc,0);
    da_str=DataAttribute_create("stVal",(ModelNode*)str,IEC61850_BOOLEAN,IEC61850_FC_ST,0,0,0);
    da_op=DataAttribute_create("stVal",(ModelNode*)op,IEC61850_BOOLEAN,IEC61850_FC_ST,0,0,0);
    da_trip=DataAttribute_create("stVal",(ModelNode*)tr,IEC61850_BOOLEAN,IEC61850_FC_ST,0,0,0);
    da_pos=DataAttribute_create("stVal",(ModelNode*)pos,IEC61850_BOOLEAN,IEC61850_FC_ST,0,0,0);
    da_current=DataAttribute_create("f",(ModelNode*)mag,IEC61850_FLOAT32,IEC61850_FC_MX,0,0,0);
    da_threshold=DataAttribute_create("setMag",(ModelNode*)strval,IEC61850_FLOAT32,IEC61850_FC_SG,0,0,0);
    DataAttribute_setValue(da_str,MmsValue_newBoolean(false));
    DataAttribute_setValue(da_op,MmsValue_newBoolean(false));
    DataAttribute_setValue(da_trip,MmsValue_newBoolean(false));
    DataAttribute_setValue(da_pos,MmsValue_newBoolean(true));
    DataAttribute_setValue(da_current,MmsValue_newFloat(0));
    DataAttribute_setValue(da_threshold,MmsValue_newFloat(800));
    server=IedServer_create(model);
    IedServer_setWriteAccessPolicy(server,IEC61850_FC_SG,ACCESS_POLICY_DENY);
    IedServer_setActiveSettingGroupChangedHandler(server,sgcb,active_changed,NULL);
    IedServer_start(server,102);
    if(!IedServer_isRunning(server)){
       fputs("NATIVE_MMS_SERVER_START_FAILED\n",stderr);IedServer_destroy(server);IedModel_destroy(model);return 2;
    }
    puts("NATIVE_MMS_SERVER_READY port=102 asset=PU-DSS-IED-01 sgcb=LLN0.SGCB");fflush(stdout);
    int last_group=0;bool previous_trip=false;
    while(running){
       test_current=read_current();
       if(test_current>0 && !prev_injected){
          last_test_current=test_current;last_test_group=active_group;
          last_test_trip=(test_current>threshold(active_group));
          event("INSTRUCTOR_FAULT_TEST",(int)test_current);
       }
       prev_injected=test_current>0;
          if(test_current>threshold(active_group)&&breaker_closed){
          trip=true;breaker_closed=false;event("PTOC_OVER_CURRENT_TRIP",(int)test_current);
       }
       if(active_group!=last_group){
          event("ACTIVE_GROUP_CURRENT",active_group);last_group=active_group;
       }
       if(trip!=previous_trip)previous_trip=trip;
       IedServer_lockDataModel(server);
       IedServer_updateBooleanAttributeValue(server,da_str,test_current>threshold(active_group));
       IedServer_updateBooleanAttributeValue(server,da_op,trip);
       IedServer_updateBooleanAttributeValue(server,da_trip,trip);
       IedServer_updateBooleanAttributeValue(server,da_pos,breaker_closed);
       IedServer_updateFloatAttributeValue(server,da_current,test_current);
       IedServer_updateFloatAttributeValue(server,da_threshold,threshold(active_group));
       IedServer_unlockDataModel(server);
       write_state();
       Thread_sleep(250);
    }
    IedServer_stop(server);IedServer_destroy(server);IedModel_destroy(model);
    return 0;
}
