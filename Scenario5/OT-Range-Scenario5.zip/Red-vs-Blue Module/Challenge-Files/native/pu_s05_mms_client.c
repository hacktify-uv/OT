#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include "iec61850_client.h"
/* Generic MMS engineering client to read protection indications and exercise SetActSG. */
int main(int argc,char **argv){
 const char *host=argc>1?argv[1]:"127.0.0.1";
 int port=argc>2?atoi(argv[2]):102;
 IedClientError error=IED_ERROR_OK;
 IedConnection con=IedConnection_create();
 IedConnection_connect(con,&error,host,port);
 if(error!=IED_ERROR_OK){fprintf(stderr,"MMS_CONNECT_FAILED code=%d\n",error);IedConnection_destroy(con);return 2;}
 const char *root="PU-DSS-IED-01LD0/";
 char ref[160];
 snprintf(ref,sizeof(ref),"%sPTOC1.Op.stVal",root);
 bool operated=IedConnection_readBooleanValue(con,&error,ref,IEC61850_FC_ST);
 if(error!=IED_ERROR_OK){fprintf(stderr,"MMS_READ_FAILED code=%d reference=%s\n",error,ref);IedConnection_close(con);IedConnection_destroy(con);return 3;}
 printf("MMS_READ_OK asset=PU-DSS-IED-01 PTOC_Op=%s\n",operated?"TRUE":"FALSE");
 if(argc>3){
   int group=atoi(argv[3]);
   if(group!=1&&group!=2){fputs("GROUP_MUST_BE_1_OR_2\n",stderr);return 4;}
   snprintf(ref,sizeof(ref),"%sLLN0.SGCB.ActSG",root);
   IedConnection_writeUnsigned32Value(con,&error,ref,IEC61850_FC_SP,group);
   if(error!=IED_ERROR_OK){fprintf(stderr,"MMS_SET_ACTSG_FAILED code=%d reference=%s\n",error,ref);IedConnection_close(con);IedConnection_destroy(con);return 5;}
   printf("MMS_SET_ACTSG_ACK group=%d\n",group);
 }
 IedConnection_close(con);IedConnection_destroy(con);
 return 0;
}
