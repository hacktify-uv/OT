#!/usr/bin/env python3
"""Independent acceptance model. NOT the wire protocol and not an attacker API."""
def evaluate(group,current_amps):
 threshold={1:800.0,2:1600.0}[int(group)]
 trip=float(current_amps)>threshold
 return {'group':int(group),'threshold_amps':threshold,'current_amps':float(current_amps),'trip':trip,'breaker_closed':not trip}
if __name__=='__main__':
 import json
 for x in [1,2]:print(json.dumps(evaluate(x,1300)))
