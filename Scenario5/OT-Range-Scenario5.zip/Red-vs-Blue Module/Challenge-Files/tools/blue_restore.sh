#!/usr/bin/env bash
set -Eeuo pipefail
[[ $EUID -eq 0 ]] || exit 1
# Preserve existing audit; restart resets native SGCB active group to approved 1.
printf '0\n' > /var/lib/prabal-urja/scenario5/instructor/current-amps
systemctl restart prabal-s05-mms.service
sleep 2
/opt/prabal-urja/scenario5/bin/pu_s05_mms_client 127.0.0.1 102
