import json,subprocess,sys,time
from pathlib import Path
p=Path('/var/lib/prabal-urja/scenario5/relay-state.json')
try:
 s=json.loads(p.read_text());probe=subprocess.run(['/opt/prabal-urja/scenario5/bin/pu_s05_mms_client','127.0.0.1','102'],capture_output=True,timeout=8)
 okprobe=(probe.returncode==0 and b'MMS_READ_OK' in probe.stdout)
 if not okprobe:reason='NATIVE_MMS_PROBE_FAILED';up=False
 elif time.time()-float(s.get('epoch',0))>5:reason='IED_PROCESS_STALE';up=False
 elif s.get('last_test_current_amps',0)>800 and s.get('last_test_group')==2 and not s.get('last_test_trip'):reason='PROTECTION_RESPONSE_SUPPRESSED';up=False
 else:reason='PROTECTION_ACTIVE';up=True
except Exception:reason='IED_UNAVAILABLE';up=False
print('SERVICE_STATUS:'+('UP' if up else 'DOWN')+' | REASON:'+reason)
sys.exit(0 if up else 1)
