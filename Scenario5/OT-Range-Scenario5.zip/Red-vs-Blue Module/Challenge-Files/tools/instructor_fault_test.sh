#!/usr/bin/env bash
set -Eeuo pipefail
[[ $EUID -eq 0 ]] || { echo 'INSTRUCTOR_ONLY_REQUIRES_ROOT' >&2;exit 1; }
AMP=${1:?Current required in amps, e.g. 1300}
python3 - "$AMP" <<'PY_FAULT'
import sys
x=float(sys.argv[1]);assert 0 <= x <= 2000
PY_FAULT
printf '%s\n' "$AMP" > /var/lib/prabal-urja/scenario5/instructor/current-amps
sleep 3
cat /var/lib/prabal-urja/scenario5/relay-state.json
printf '0\n' > /var/lib/prabal-urja/scenario5/instructor/current-amps
