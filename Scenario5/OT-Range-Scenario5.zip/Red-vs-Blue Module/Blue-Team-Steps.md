# Blue Team evidence and recovery

1. Confirm genuine MMS activity via captures on TCP 102 and server logs; check `LLN0.SGCB.ActSG` and `PTOC1` objects.
2. Preserve the before/after native relay-state snapshots, `relay-events.jsonl`, and journal before restoration.
3. Use a genuine MMS engineering client to restore the active approved setting group, or use the instructor reset procedure after evidence preservation.
4. Independently inject the same 1300 A test and verify a PTOC trip and breaker opening.
5. Verify the CTF availability check returns `UP` and capture genuine MMS readback.
