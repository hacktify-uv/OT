#!/usr/bin/env python3
import importlib.util
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'Challenge-Files/model/protection_model.py'
s=importlib.util.spec_from_file_location('prot',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
assert m.evaluate(1,1300)=={'group':1,'threshold_amps':800.0,'current_amps':1300.0,'trip':True,'breaker_closed':False}
assert m.evaluate(2,1300)=={'group':2,'threshold_amps':1600.0,'current_amps':1300.0,'trip':False,'breaker_closed':True}
print('INDEPENDENT_PROTECTION_MODEL:PASS')
